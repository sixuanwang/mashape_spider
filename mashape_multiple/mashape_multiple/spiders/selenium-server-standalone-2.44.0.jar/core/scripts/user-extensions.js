// User extensions can be added here.
//
// Keep this file to avoid  mystifying "Invalid Character" error in IE
