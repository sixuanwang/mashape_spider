var e, m = this;
function p(a) {
  return void 0 !== a;
}
function aa(a) {
  a = a.split(".");
  for (var b = m, c;c = a.shift();) {
    if (null != b[c]) {
      b = b[c];
    } else {
      return null;
    }
  }
  return b;
}
function r() {
}
function ba(a) {
  a.mb = function() {
    return a.We ? a.We : a.We = new a;
  };
}
function ca(a) {
  var b = typeof a;
  if ("object" == b) {
    if (a) {
      if (a instanceof Array) {
        return "array";
      }
      if (a instanceof Object) {
        return b;
      }
      var c = Object.prototype.toString.call(a);
      if ("[object Window]" == c) {
        return "object";
      }
      if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) {
        return "array";
      }
      if ("[object Function]" == c || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) {
        return "function";
      }
    } else {
      return "null";
    }
  } else {
    if ("function" == b && "undefined" == typeof a.call) {
      return "object";
    }
  }
  return b;
}
function s(a) {
  return "array" == ca(a);
}
function da(a) {
  var b = ca(a);
  return "array" == b || "object" == b && "number" == typeof a.length;
}
function t(a) {
  return "string" == typeof a;
}
function fa(a) {
  return "number" == typeof a;
}
function u(a) {
  return "function" == ca(a);
}
function ga(a) {
  var b = typeof a;
  return "object" == b && null != a || "function" == b;
}
function ha(a) {
  return a[ia] || (a[ia] = ++ja);
}
var ia = "closure_uid_" + (1E9 * Math.random() >>> 0), ja = 0;
function ka(a, b, c) {
  return a.call.apply(a.bind, arguments);
}
function la(a, b, c) {
  if (!a) {
    throw Error();
  }
  if (2 < arguments.length) {
    var d = Array.prototype.slice.call(arguments, 2);
    return function() {
      var c = Array.prototype.slice.call(arguments);
      Array.prototype.unshift.apply(c, d);
      return a.apply(b, c);
    };
  }
  return function() {
    return a.apply(b, arguments);
  };
}
function v(a, b, c) {
  v = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ka : la;
  return v.apply(null, arguments);
}
function ma(a, b) {
  var c = Array.prototype.slice.call(arguments, 1);
  return function() {
    var b = c.slice();
    b.push.apply(b, arguments);
    return a.apply(this, b);
  };
}
var oa = Date.now || function() {
  return+new Date;
};
function w(a, b) {
  function c() {
  }
  c.prototype = b.prototype;
  a.c = b.prototype;
  a.prototype = new c;
  a.prototype.constructor = a;
  a.vh = function(a, c, g) {
    return b.prototype[c].apply(a, Array.prototype.slice.call(arguments, 2));
  };
}
;function pa(a, b) {
  this.code = a;
  this.state = qa[a] || ra;
  this.message = b || "";
  var c = this.state.replace(/((?:^|\s+)[a-z])/g, function(a) {
    return a.toUpperCase().replace(/^[\s\xa0]+/g, "");
  }), d = c.length - 5;
  if (0 > d || c.indexOf("Error", d) != d) {
    c += "Error";
  }
  this.name = c;
  c = Error(this.message);
  c.name = this.name;
  this.stack = c.stack || "";
}
w(pa, Error);
var ra = "unknown error", qa = {15:"element not selectable", 11:"element not visible", 31:"ime engine activation failed", 30:"ime not available", 24:"invalid cookie domain", 29:"invalid element coordinates", 12:"invalid element state", 32:"invalid selector", 51:"invalid selector", 52:"invalid selector", 17:"javascript error", 405:"unsupported operation", 34:"move target out of bounds", 27:"no such alert", 7:"no such element", 8:"no such frame", 23:"no such window", 28:"script timeout", 33:"session not created", 
10:"stale element reference", 0:"success", 21:"timeout", 25:"unable to set cookie", 26:"unexpected alert open"};
qa[13] = ra;
qa[9] = "unknown command";
pa.prototype.toString = function() {
  return this.name + ": " + this.message;
};
function sa(a) {
  var b = a.status;
  if (0 == b) {
    return a;
  }
  b = b || 13;
  a = a.value;
  if (!a || !ga(a)) {
    throw new pa(b, a + "");
  }
  throw new pa(b, a.message + "");
}
;function ta() {
  0 != ua && (va[ha(this)] = this);
  this.Db = this.Db;
  this.rb = this.rb;
}
var ua = 0, va = {};
ta.prototype.Db = !1;
ta.prototype.C = function() {
  if (!this.Db && (this.Db = !0, this.g(), 0 != ua)) {
    var a = ha(this);
    delete va[a];
  }
};
ta.prototype.g = function() {
  if (this.rb) {
    for (;this.rb.length;) {
      this.rb.shift()();
    }
  }
};
function wa(a) {
  a && "function" == typeof a.C && a.C();
}
;function xa(a) {
  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, xa);
  } else {
    var b = Error().stack;
    b && (this.stack = b);
  }
  a && (this.message = String(a));
}
w(xa, Error);
xa.prototype.name = "CustomError";
var ya;
function za(a, b) {
  for (var c = a.split("%s"), d = "", f = Array.prototype.slice.call(arguments, 1);f.length && 1 < c.length;) {
    d += c.shift() + f.shift();
  }
  return d + c.join("%s");
}
function Aa(a) {
  return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "");
}
function Ba(a) {
  if (!Ca.test(a)) {
    return a;
  }
  -1 != a.indexOf("&") && (a = a.replace(Da, "&amp;"));
  -1 != a.indexOf("<") && (a = a.replace(Ea, "&lt;"));
  -1 != a.indexOf(">") && (a = a.replace(Fa, "&gt;"));
  -1 != a.indexOf('"') && (a = a.replace(Ga, "&quot;"));
  -1 != a.indexOf("'") && (a = a.replace(Ha, "&#39;"));
  -1 != a.indexOf("\x00") && (a = a.replace(Ia, "&#0;"));
  return a;
}
var Da = /&/g, Ea = /</g, Fa = />/g, Ga = /"/g, Ha = /'/g, Ia = /\x00/g, Ca = /[\x00&<>"']/;
function Ja(a, b) {
  return Array(b + 1).join(a);
}
function Ka(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}
function La(a) {
  return String(a).replace(/\-([a-z])/g, function(a, c) {
    return c.toUpperCase();
  });
}
function Ma(a) {
  var b = t(void 0) ? "undefined".replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08") : "\\s";
  return a.replace(new RegExp("(^" + (b ? "|[" + b + "]+" : "") + ")([a-z])", "g"), function(a, b, f) {
    return b + f.toUpperCase();
  });
}
;function Na(a, b) {
  b.unshift(a);
  xa.call(this, za.apply(null, b));
  b.shift();
}
w(Na, xa);
Na.prototype.name = "AssertionError";
function Oa(a, b) {
  throw new Na("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
}
;function Pa() {
  var a = Qa;
  return a[a.length - 1];
}
var y = Array.prototype, Ra = y.indexOf ? function(a, b, c) {
  return y.indexOf.call(a, b, c);
} : function(a, b, c) {
  c = null == c ? 0 : 0 > c ? Math.max(0, a.length + c) : c;
  if (t(a)) {
    return t(b) && 1 == b.length ? a.indexOf(b, c) : -1;
  }
  for (;c < a.length;c++) {
    if (c in a && a[c] === b) {
      return c;
    }
  }
  return-1;
}, z = y.forEach ? function(a, b, c) {
  y.forEach.call(a, b, c);
} : function(a, b, c) {
  for (var d = a.length, f = t(a) ? a.split("") : a, g = 0;g < d;g++) {
    g in f && b.call(c, f[g], g, a);
  }
}, Sa = y.filter ? function(a, b, c) {
  return y.filter.call(a, b, c);
} : function(a, b, c) {
  for (var d = a.length, f = [], g = 0, h = t(a) ? a.split("") : a, k = 0;k < d;k++) {
    if (k in h) {
      var l = h[k];
      b.call(c, l, k, a) && (f[g++] = l);
    }
  }
  return f;
}, Ta = y.map ? function(a, b, c) {
  return y.map.call(a, b, c);
} : function(a, b, c) {
  for (var d = a.length, f = Array(d), g = t(a) ? a.split("") : a, h = 0;h < d;h++) {
    h in g && (f[h] = b.call(c, g[h], h, a));
  }
  return f;
}, Ua = y.some ? function(a, b, c) {
  return y.some.call(a, b, c);
} : function(a, b, c) {
  for (var d = a.length, f = t(a) ? a.split("") : a, g = 0;g < d;g++) {
    if (g in f && b.call(c, f[g], g, a)) {
      return!0;
    }
  }
  return!1;
}, Va = y.every ? function(a, b, c) {
  return y.every.call(a, b, c);
} : function(a, b, c) {
  for (var d = a.length, f = t(a) ? a.split("") : a, g = 0;g < d;g++) {
    if (g in f && !b.call(c, f[g], g, a)) {
      return!1;
    }
  }
  return!0;
};
function Wa(a, b) {
  return 0 <= Ra(a, b);
}
function Xa(a, b) {
  var c = Ra(a, b), d;
  (d = 0 <= c) && y.splice.call(a, c, 1);
  return d;
}
function Ya(a) {
  return y.concat.apply(y, arguments);
}
function Za(a) {
  var b = a.length;
  if (0 < b) {
    for (var c = Array(b), d = 0;d < b;d++) {
      c[d] = a[d];
    }
    return c;
  }
  return[];
}
function $a(a, b, c, d) {
  y.splice.apply(a, ab(arguments, 1));
}
function ab(a, b, c) {
  return 2 >= arguments.length ? y.slice.call(a, b) : y.slice.call(a, b, c);
}
;function bb(a, b) {
  for (var c in a) {
    b.call(void 0, a[c], c, a);
  }
}
function cb(a) {
  var b = [], c = 0, d;
  for (d in a) {
    b[c++] = a[d];
  }
  return b;
}
function db(a) {
  var b = [], c = 0, d;
  for (d in a) {
    b[c++] = d;
  }
  return b;
}
var eb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
function fb(a, b) {
  for (var c, d, f = 1;f < arguments.length;f++) {
    d = arguments[f];
    for (c in d) {
      a[c] = d[c];
    }
    for (var g = 0;g < eb.length;g++) {
      c = eb[g], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
}
function gb(a) {
  var b = arguments.length;
  if (1 == b && s(arguments[0])) {
    return gb.apply(null, arguments[0]);
  }
  if (b % 2) {
    throw Error("Uneven number of arguments");
  }
  for (var c = {}, d = 0;d < b;d += 2) {
    c[arguments[d]] = arguments[d + 1];
  }
  return c;
}
function hb(a) {
  var b = arguments.length;
  if (1 == b && s(arguments[0])) {
    return hb.apply(null, arguments[0]);
  }
  for (var c = {}, d = 0;d < b;d++) {
    c[arguments[d]] = !0;
  }
  return c;
}
;function ib(a) {
  if ("function" == typeof a.da) {
    return a.da();
  }
  if (t(a)) {
    return a.split("");
  }
  if (da(a)) {
    for (var b = [], c = a.length, d = 0;d < c;d++) {
      b.push(a[d]);
    }
    return b;
  }
  return cb(a);
}
function jb(a, b, c) {
  if ("function" == typeof a.forEach) {
    a.forEach(b, c);
  } else {
    if (da(a) || t(a)) {
      z(a, b, c);
    } else {
      var d;
      if ("function" == typeof a.nb) {
        d = a.nb();
      } else {
        if ("function" != typeof a.da) {
          if (da(a) || t(a)) {
            d = [];
            for (var f = a.length, g = 0;g < f;g++) {
              d.push(g);
            }
          } else {
            d = db(a);
          }
        } else {
          d = void 0;
        }
      }
      for (var f = ib(a), g = f.length, h = 0;h < g;h++) {
        b.call(c, f[h], d && d[h], a);
      }
    }
  }
}
;function kb(a, b) {
  this.S = {};
  this.w = [];
  this.I = 0;
  var c = arguments.length;
  if (1 < c) {
    if (c % 2) {
      throw Error("Uneven number of arguments");
    }
    for (var d = 0;d < c;d += 2) {
      this.set(arguments[d], arguments[d + 1]);
    }
  } else {
    a && this.yd(a);
  }
}
e = kb.prototype;
e.da = function() {
  lb(this);
  for (var a = [], b = 0;b < this.w.length;b++) {
    a.push(this.S[this.w[b]]);
  }
  return a;
};
e.nb = function() {
  lb(this);
  return this.w.concat();
};
e.Bb = function(a) {
  return mb(this.S, a);
};
e.clear = function() {
  this.S = {};
  this.I = this.w.length = 0;
};
e.remove = function(a) {
  return mb(this.S, a) ? (delete this.S[a], this.I--, this.w.length > 2 * this.I && lb(this), !0) : !1;
};
function lb(a) {
  if (a.I != a.w.length) {
    for (var b = 0, c = 0;b < a.w.length;) {
      var d = a.w[b];
      mb(a.S, d) && (a.w[c++] = d);
      b++;
    }
    a.w.length = c;
  }
  if (a.I != a.w.length) {
    for (var f = {}, c = b = 0;b < a.w.length;) {
      d = a.w[b], mb(f, d) || (a.w[c++] = d, f[d] = 1), b++;
    }
    a.w.length = c;
  }
}
e.get = function(a, b) {
  return mb(this.S, a) ? this.S[a] : b;
};
e.set = function(a, b) {
  mb(this.S, a) || (this.I++, this.w.push(a));
  this.S[a] = b;
};
e.yd = function(a) {
  var b;
  a instanceof kb ? (b = a.nb(), a = a.da()) : (b = db(a), a = cb(a));
  for (var c = 0;c < b.length;c++) {
    this.set(b[c], a[c]);
  }
};
e.forEach = function(a, b) {
  for (var c = this.nb(), d = 0;d < c.length;d++) {
    var f = c[d], g = this.get(f);
    a.call(b, g, f, this);
  }
};
e.clone = function() {
  return new kb(this);
};
function mb(a, b) {
  return Object.prototype.hasOwnProperty.call(a, b);
}
;var nb;
a: {
  var ob = m.navigator;
  if (ob) {
    var pb = ob.userAgent;
    if (pb) {
      nb = pb;
      break a;
    }
  }
  nb = "";
}
function qb(a) {
  return-1 != nb.indexOf(a);
}
;var rb;
function sb() {
  return m.navigator || null;
}
var tb = qb("Opera") || qb("OPR"), A = qb("Trident") || qb("MSIE"), B = qb("Gecko") && -1 == nb.toLowerCase().indexOf("webkit") && !(qb("Trident") || qb("MSIE")), D = -1 != nb.toLowerCase().indexOf("webkit"), ub = sb();
rb = -1 != (ub && ub.platform || "").indexOf("Mac");
var vb = !!sb() && -1 != (sb().appVersion || "").indexOf("X11");
function wb() {
  var a = m.document;
  return a ? a.documentMode : void 0;
}
var xb = function() {
  var a = "", b;
  if (tb && m.opera) {
    return a = m.opera.version, u(a) ? a() : a;
  }
  B ? b = /rv\:([^\);]+)(\)|;)/ : A ? b = /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/ : D && (b = /WebKit\/(\S+)/);
  b && (a = (a = b.exec(nb)) ? a[1] : "");
  return A && (b = wb(), b > parseFloat(a)) ? String(b) : a;
}(), yb = {};
function E(a) {
  var b;
  if (!(b = yb[a])) {
    b = 0;
    for (var c = Aa(String(xb)).split("."), d = Aa(String(a)).split("."), f = Math.max(c.length, d.length), g = 0;0 == b && g < f;g++) {
      var h = c[g] || "", k = d[g] || "", l = RegExp("(\\d*)(\\D*)", "g"), n = RegExp("(\\d*)(\\D*)", "g");
      do {
        var q = l.exec(h) || ["", "", ""], F = n.exec(k) || ["", "", ""];
        if (0 == q[0].length && 0 == F[0].length) {
          break;
        }
        b = Ka(0 == q[1].length ? 0 : parseInt(q[1], 10), 0 == F[1].length ? 0 : parseInt(F[1], 10)) || Ka(0 == q[2].length, 0 == F[2].length) || Ka(q[2], F[2]);
      } while (0 == b);
    }
    b = yb[a] = 0 <= b;
  }
  return b;
}
function zb(a) {
  return A && Ab >= a;
}
var Cb = m.document, Ab = Cb && A ? wb() || ("CSS1Compat" == Cb.compatMode ? parseInt(xb, 10) : 5) : void 0;
var Db = /^(?:([^:/?#.]+):)?(?:\/\/(?:([^/?#]*)@)?([^/#?]*?)(?::([0-9]+))?(?=[/#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#(.*))?$/;
function Eb(a) {
  if (Fb) {
    Fb = !1;
    var b = m.location;
    if (b) {
      var c = b.href;
      if (c && (c = (c = Eb(c)[3] || null) ? decodeURI(c) : c) && c != b.hostname) {
        throw Fb = !0, Error();
      }
    }
  }
  return a.match(Db);
}
var Fb = D;
function Gb(a, b) {
  var c;
  if (a instanceof Gb) {
    this.ia = p(b) ? b : a.ia, Hb(this, a.Za), c = a.zb, G(this), this.zb = c, c = a.Ia, G(this), this.Ia = c, Ib(this, a.Xb), c = a.fa, G(this), this.fa = c, Jb(this, a.sa.clone()), c = a.lb, G(this), this.lb = c;
  } else {
    if (a && (c = Eb(String(a)))) {
      this.ia = !!b;
      Hb(this, c[1] || "", !0);
      var d = c[2] || "";
      G(this);
      this.zb = Kb(d);
      d = c[3] || "";
      G(this);
      this.Ia = Kb(d, !0);
      Ib(this, c[4]);
      d = c[5] || "";
      G(this);
      this.fa = Kb(d, !0);
      Jb(this, c[6] || "", !0);
      c = c[7] || "";
      G(this);
      this.lb = Kb(c);
    } else {
      this.ia = !!b, this.sa = new Lb(null, 0, this.ia);
    }
  }
}
e = Gb.prototype;
e.Za = "";
e.zb = "";
e.Ia = "";
e.Xb = null;
e.fa = "";
e.lb = "";
e.Bg = !1;
e.ia = !1;
e.toString = function() {
  var a = [], b = this.Za;
  b && a.push(Mb(b, Nb, !0), ":");
  if (b = this.Ia) {
    a.push("//");
    var c = this.zb;
    c && a.push(Mb(c, Nb, !0), "@");
    a.push(encodeURIComponent(String(b)).replace(/%25([0-9a-fA-F]{2})/g, "%$1"));
    b = this.Xb;
    null != b && a.push(":", String(b));
  }
  if (b = this.fa) {
    this.Ia && "/" != b.charAt(0) && a.push("/"), a.push(Mb(b, "/" == b.charAt(0) ? Ob : Pb, !0));
  }
  (b = this.sa.toString()) && a.push("?", b);
  (b = this.lb) && a.push("#", Mb(b, Qb));
  return a.join("");
};
e.resolve = function(a) {
  var b = this.clone(), c = !!a.Za;
  c ? Hb(b, a.Za) : c = !!a.zb;
  if (c) {
    var d = a.zb;
    G(b);
    b.zb = d;
  } else {
    c = !!a.Ia;
  }
  c ? (d = a.Ia, G(b), b.Ia = d) : c = null != a.Xb;
  d = a.fa;
  if (c) {
    Ib(b, a.Xb);
  } else {
    if (c = !!a.fa) {
      if ("/" != d.charAt(0)) {
        if (this.Ia && !this.fa) {
          d = "/" + d;
        } else {
          var f = b.fa.lastIndexOf("/");
          -1 != f && (d = b.fa.substr(0, f + 1) + d);
        }
      }
      f = d;
      if (".." == f || "." == f) {
        d = "";
      } else {
        if (-1 != f.indexOf("./") || -1 != f.indexOf("/.")) {
          for (var d = 0 == f.lastIndexOf("/", 0), f = f.split("/"), g = [], h = 0;h < f.length;) {
            var k = f[h++];
            "." == k ? d && h == f.length && g.push("") : ".." == k ? ((1 < g.length || 1 == g.length && "" != g[0]) && g.pop(), d && h == f.length && g.push("")) : (g.push(k), d = !0);
          }
          d = g.join("/");
        } else {
          d = f;
        }
      }
    }
  }
  c ? (G(b), b.fa = d) : c = "" !== a.sa.toString();
  c ? Jb(b, Kb(a.sa.toString())) : c = !!a.lb;
  c && (a = a.lb, G(b), b.lb = a);
  return b;
};
e.clone = function() {
  return new Gb(this);
};
function Hb(a, b, c) {
  G(a);
  a.Za = c ? Kb(b, !0) : b;
  a.Za && (a.Za = a.Za.replace(/:$/, ""));
}
function Ib(a, b) {
  G(a);
  if (b) {
    b = Number(b);
    if (isNaN(b) || 0 > b) {
      throw Error("Bad port number " + b);
    }
    a.Xb = b;
  } else {
    a.Xb = null;
  }
}
function Jb(a, b, c) {
  G(a);
  b instanceof Lb ? (a.sa = b, a.sa.re(a.ia)) : (c || (b = Mb(b, Rb)), a.sa = new Lb(b, 0, a.ia));
}
function G(a) {
  if (a.Bg) {
    throw Error("Tried to modify a read-only Uri");
  }
}
e.re = function(a) {
  this.ia = a;
  this.sa && this.sa.re(a);
  return this;
};
function Kb(a, b) {
  return a ? b ? decodeURI(a) : decodeURIComponent(a) : "";
}
function Mb(a, b, c) {
  return t(a) ? (a = encodeURI(a).replace(b, Sb), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null;
}
function Sb(a) {
  a = a.charCodeAt(0);
  return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16);
}
var Nb = /[#\/\?@]/g, Pb = /[\#\?:]/g, Ob = /[\#\?]/g, Rb = /[\#\?@]/g, Qb = /#/g;
function Lb(a, b, c) {
  this.ba = a || null;
  this.ia = !!c;
}
function Tb(a) {
  if (!a.v && (a.v = new kb, a.I = 0, a.ba)) {
    for (var b = a.ba.split("&"), c = 0;c < b.length;c++) {
      var d = b[c].indexOf("="), f = null, g = null;
      0 <= d ? (f = b[c].substring(0, d), g = b[c].substring(d + 1)) : f = b[c];
      f = decodeURIComponent(f.replace(/\+/g, " "));
      f = Ub(a, f);
      a.add(f, g ? decodeURIComponent(g.replace(/\+/g, " ")) : "");
    }
  }
}
e = Lb.prototype;
e.v = null;
e.I = null;
e.add = function(a, b) {
  Tb(this);
  this.ba = null;
  a = Ub(this, a);
  var c = this.v.get(a);
  c || this.v.set(a, c = []);
  c.push(b);
  this.I++;
  return this;
};
e.remove = function(a) {
  Tb(this);
  a = Ub(this, a);
  return this.v.Bb(a) ? (this.ba = null, this.I -= this.v.get(a).length, this.v.remove(a)) : !1;
};
e.clear = function() {
  this.v = this.ba = null;
  this.I = 0;
};
e.Bb = function(a) {
  Tb(this);
  a = Ub(this, a);
  return this.v.Bb(a);
};
e.nb = function() {
  Tb(this);
  for (var a = this.v.da(), b = this.v.nb(), c = [], d = 0;d < b.length;d++) {
    for (var f = a[d], g = 0;g < f.length;g++) {
      c.push(b[d]);
    }
  }
  return c;
};
e.da = function(a) {
  Tb(this);
  var b = [];
  if (t(a)) {
    this.Bb(a) && (b = Ya(b, this.v.get(Ub(this, a))));
  } else {
    a = this.v.da();
    for (var c = 0;c < a.length;c++) {
      b = Ya(b, a[c]);
    }
  }
  return b;
};
e.set = function(a, b) {
  Tb(this);
  this.ba = null;
  a = Ub(this, a);
  this.Bb(a) && (this.I -= this.v.get(a).length);
  this.v.set(a, [b]);
  this.I++;
  return this;
};
e.get = function(a, b) {
  var c = a ? this.da(a) : [];
  return 0 < c.length ? String(c[0]) : b;
};
e.toString = function() {
  if (this.ba) {
    return this.ba;
  }
  if (!this.v) {
    return "";
  }
  for (var a = [], b = this.v.nb(), c = 0;c < b.length;c++) {
    for (var d = b[c], f = encodeURIComponent(String(d)), d = this.da(d), g = 0;g < d.length;g++) {
      var h = f;
      "" !== d[g] && (h += "=" + encodeURIComponent(String(d[g])));
      a.push(h);
    }
  }
  return this.ba = a.join("&");
};
e.clone = function() {
  var a = new Lb;
  a.ba = this.ba;
  this.v && (a.v = this.v.clone(), a.I = this.I);
  return a;
};
function Ub(a, b) {
  var c = String(b);
  a.ia && (c = c.toLowerCase());
  return c;
}
e.re = function(a) {
  a && !this.ia && (Tb(this), this.ba = null, this.v.forEach(function(a, c) {
    var d = c.toLowerCase();
    c != d && (this.remove(c), this.remove(d), 0 < a.length && (this.ba = null, this.v.set(Ub(this, d), Za(a)), this.I += a.length));
  }, this));
  this.ia = a;
};
e.extend = function(a) {
  for (var b = 0;b < arguments.length;b++) {
    jb(arguments[b], function(a, b) {
      this.add(b, a);
    }, this);
  }
};
function Vb(a) {
  this.S = new kb;
  a && this.yd(a);
}
function Wb(a) {
  var b = typeof a;
  return "object" == b && a || "function" == b ? "o" + ha(a) : b.substr(0, 1) + a;
}
e = Vb.prototype;
e.add = function(a) {
  this.S.set(Wb(a), a);
};
e.yd = function(a) {
  a = ib(a);
  for (var b = a.length, c = 0;c < b;c++) {
    this.add(a[c]);
  }
};
e.Ca = function(a) {
  a = ib(a);
  for (var b = a.length, c = 0;c < b;c++) {
    this.remove(a[c]);
  }
};
e.remove = function(a) {
  return this.S.remove(Wb(a));
};
e.clear = function() {
  this.S.clear();
};
e.contains = function(a) {
  return this.S.Bb(Wb(a));
};
e.Xe = function(a) {
  var b = new Vb;
  a = ib(a);
  for (var c = 0;c < a.length;c++) {
    var d = a[c];
    this.contains(d) && b.add(d);
  }
  return b;
};
e.da = function() {
  return this.S.da();
};
e.clone = function() {
  return new Vb(this);
};
function Xb(a) {
  var b;
  b || (b = Yb(a || arguments.callee.caller, []));
  return b;
}
function Yb(a, b) {
  var c = [];
  if (Wa(b, a)) {
    c.push("[...circular reference...]");
  } else {
    if (a && 50 > b.length) {
      c.push(Zb(a) + "(");
      for (var d = a.arguments, f = 0;d && f < d.length;f++) {
        0 < f && c.push(", ");
        var g;
        g = d[f];
        switch(typeof g) {
          case "object":
            g = g ? "object" : "null";
            break;
          case "string":
            break;
          case "number":
            g = String(g);
            break;
          case "boolean":
            g = g ? "true" : "false";
            break;
          case "function":
            g = (g = Zb(g)) ? g : "[fn]";
            break;
          default:
            g = typeof g;
        }
        40 < g.length && (g = g.substr(0, 40) + "...");
        c.push(g);
      }
      b.push(a);
      c.push(")\n");
      try {
        c.push(Yb(a.caller, b));
      } catch (h) {
        c.push("[exception trying to get caller]\n");
      }
    } else {
      a ? c.push("[...long stack...]") : c.push("[end]");
    }
  }
  return c.join("");
}
function Zb(a) {
  if ($b[a]) {
    return $b[a];
  }
  a = String(a);
  if (!$b[a]) {
    var b = /function ([^\(]+)/.exec(a);
    $b[a] = b ? b[1] : "[Anonymous]";
  }
  return $b[a];
}
var $b = {};
function ac(a, b, c, d, f) {
  this.reset(a, b, c, d, f);
}
ac.prototype.Md = null;
ac.prototype.Ld = null;
var bc = 0;
ac.prototype.reset = function(a, b, c, d, f) {
  "number" == typeof f || bc++;
  this.Ef = d || oa();
  this.ob = a;
  this.de = b;
  this.cf = c;
  delete this.Md;
  delete this.Ld;
};
ac.prototype.uf = function(a) {
  this.ob = a;
};
ac.prototype.vf = function(a) {
  this.de = a;
};
function cc(a) {
  this.qb = a;
  this.Kb = this.m = this.ob = this.A = null;
}
function dc(a, b) {
  this.name = a;
  this.value = b;
}
dc.prototype.toString = function() {
  return this.name;
};
var ec = new dc("SHOUT", 1200), fc = new dc("SEVERE", 1E3), gc = new dc("WARNING", 900), hc = new dc("INFO", 800), ic = new dc("CONFIG", 700);
e = cc.prototype;
e.getName = function() {
  return this.qb;
};
e.getParent = function() {
  return this.A;
};
e.Sd = function() {
  this.m || (this.m = {});
  return this.m;
};
e.uf = function(a) {
  this.ob = a;
};
function jc(a) {
  if (a.ob) {
    return a.ob;
  }
  if (a.A) {
    return jc(a.A);
  }
  Oa("Root logger has no level set.");
  return null;
}
e.log = function(a, b, c) {
  if (a.value >= jc(this).value) {
    for (u(b) && (b = b()), a = this.Me(a, b, c, cc.prototype.log), b = "log:" + a.de, m.console && (m.console.timeStamp ? m.console.timeStamp(b) : m.console.markTimeline && m.console.markTimeline(b)), m.msWriteProfilerMark && m.msWriteProfilerMark(b), b = this;b;) {
      c = b;
      var d = a;
      if (c.Kb) {
        for (var f = 0, g = void 0;g = c.Kb[f];f++) {
          g(d);
        }
      }
      b = b.getParent();
    }
  }
};
e.Me = function(a, b, c, d) {
  a = new ac(a, String(b), this.qb);
  if (c) {
    a.Md = c;
    var f;
    d = d || cc.prototype.Me;
    try {
      var g;
      var h = aa("window.location.href");
      if (t(c)) {
        g = {message:c, name:"Unknown error", lineNumber:"Not available", fileName:h, stack:"Not available"};
      } else {
        var k, l;
        b = !1;
        try {
          k = c.lineNumber || c.yh || "Not available";
        } catch (n) {
          k = "Not available", b = !0;
        }
        try {
          l = c.fileName || c.filename || c.sourceURL || m.$googDebugFname || h;
        } catch (q) {
          l = "Not available", b = !0;
        }
        g = !b && c.lineNumber && c.fileName && c.stack && c.message && c.name ? c : {message:c.message || "Not available", name:c.name || "UnknownError", lineNumber:k, fileName:l, stack:c.stack || "Not available"};
      }
      f = "Message: " + Ba(g.message) + '\nUrl: <a href="view-source:' + g.fileName + '" target="_new">' + g.fileName + "</a>\nLine: " + g.lineNumber + "\n\nBrowser stack:\n" + Ba(g.stack + "-> ") + "[end]\n\nJS stack traversal:\n" + Ba(Xb(d) + "-> ");
    } catch (F) {
      f = "Exception trying to expose exception! You win, we lose. " + F;
    }
    a.Ld = f;
  }
  return a;
};
e.info = function(a, b) {
  this.log(hc, a, b);
};
var kc = {}, lc = null;
function mc() {
  lc || (lc = new cc(""), kc[""] = lc, lc.uf(ic));
}
function nc(a) {
  mc();
  var b;
  if (!(b = kc[a])) {
    b = new cc(a);
    var c = a.lastIndexOf("."), d = a.substr(c + 1), c = nc(a.substr(0, c));
    c.Sd()[d] = b;
    b.A = c;
    kc[a] = b;
  }
  return b;
}
;function oc() {
  this.qf = oa();
}
var pc = new oc;
oc.prototype.set = function(a) {
  this.qf = a;
};
oc.prototype.reset = function() {
  this.set(oa());
};
oc.prototype.get = function() {
  return this.qf;
};
function qc(a) {
  this.gh = a || "";
  this.rh = pc;
}
e = qc.prototype;
e.ye = !0;
e.xf = !0;
e.oh = !0;
e.nh = !0;
e.zf = !1;
e.ph = !1;
function rc(a) {
  return 10 > a ? "0" + a : String(a);
}
function sc(a, b) {
  var c = (a.Ef - b) / 1E3, d = c.toFixed(3), f = 0;
  if (1 > c) {
    f = 2;
  } else {
    for (;100 > c;) {
      f++, c *= 10;
    }
  }
  for (;0 < f--;) {
    d = " " + d;
  }
  return d;
}
function tc(a) {
  qc.call(this, a);
}
w(tc, qc);
function uc() {
  this.pf = v(this.Nf, this);
  this.Xc = new tc;
  this.Xc.xf = !1;
  this.Xc.zf = !1;
  this.Ye = this.Xc.ye = !1;
  this.bf = "";
  this.cg = {};
}
function vc(a, b) {
  if (b != a.Ye) {
    var c;
    mc();
    c = lc;
    if (b) {
      var d = a.pf;
      c.Kb || (c.Kb = []);
      c.Kb.push(d);
    } else {
      (c = c.Kb) && Xa(c, a.pf);
    }
    a.Ye = b;
  }
}
uc.prototype.Nf = function(a) {
  if (!this.cg[a.cf]) {
    var b;
    b = this.Xc;
    var c = [];
    c.push(b.gh, " ");
    if (b.xf) {
      var d = new Date(a.Ef);
      c.push("[", rc(d.getFullYear() - 2E3) + rc(d.getMonth() + 1) + rc(d.getDate()) + " " + rc(d.getHours()) + ":" + rc(d.getMinutes()) + ":" + rc(d.getSeconds()) + "." + rc(Math.floor(d.getMilliseconds() / 10)), "] ");
    }
    b.oh && c.push("[", sc(a, b.rh.get()), "s] ");
    b.nh && c.push("[", a.cf, "] ");
    b.ph && c.push("[", a.ob.name, "] ");
    c.push(a.de);
    b.zf && a.Md && c.push("\n", a.Ld);
    b.ye && c.push("\n");
    b = c.join("");
    if (c = wc) {
      switch(a.ob) {
        case ec:
          xc(c, "info", b);
          break;
        case fc:
          xc(c, "error", b);
          break;
        case gc:
          xc(c, "warn", b);
          break;
        default:
          xc(c, "debug", b);
      }
    } else {
      this.bf += b;
    }
  }
};
var wc = m.console;
function xc(a, b, c) {
  if (a[b]) {
    a[b](c);
  } else {
    a.log(c);
  }
}
;var yc = !A || zb(9), zc = !A || zb(9), Ac = A && !E("9");
!D || E("528");
B && E("1.9b") || A && E("8") || tb && E("9.5") || D && E("528");
B && !E("8") || A && E("9");
function I(a, b) {
  this.type = a;
  this.currentTarget = this.target = b;
  this.defaultPrevented = this.sb = !1;
  this.sf = !0;
}
I.prototype.g = function() {
};
I.prototype.C = function() {
};
I.prototype.stopPropagation = function() {
  this.sb = !0;
};
I.prototype.preventDefault = function() {
  this.defaultPrevented = !0;
  this.sf = !1;
};
function Bc(a) {
  a.preventDefault();
}
;function Cc(a) {
  Cc[" "](a);
  return a;
}
Cc[" "] = r;
function J(a, b) {
  I.call(this, a ? a.type : "");
  this.relatedTarget = this.currentTarget = this.target = null;
  this.charCode = this.keyCode = this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
  this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
  this.state = null;
  this.je = !1;
  this.na = null;
  a && this.xc(a, b);
}
w(J, I);
var Dc = [1, 4, 2];
J.prototype.xc = function(a, b) {
  var c = this.type = a.type;
  this.target = a.target || a.srcElement;
  this.currentTarget = b;
  var d = a.relatedTarget;
  if (d) {
    if (B) {
      var f;
      a: {
        try {
          Cc(d.nodeName);
          f = !0;
          break a;
        } catch (g) {
        }
        f = !1;
      }
      f || (d = null);
    }
  } else {
    "mouseover" == c ? d = a.fromElement : "mouseout" == c && (d = a.toElement);
  }
  this.relatedTarget = d;
  this.offsetX = D || void 0 !== a.offsetX ? a.offsetX : a.layerX;
  this.offsetY = D || void 0 !== a.offsetY ? a.offsetY : a.layerY;
  this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX;
  this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY;
  this.screenX = a.screenX || 0;
  this.screenY = a.screenY || 0;
  this.button = a.button;
  this.keyCode = a.keyCode || 0;
  this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
  this.ctrlKey = a.ctrlKey;
  this.altKey = a.altKey;
  this.shiftKey = a.shiftKey;
  this.metaKey = a.metaKey;
  this.je = rb ? a.metaKey : a.ctrlKey;
  this.state = a.state;
  this.na = a;
  a.defaultPrevented && this.preventDefault();
};
function Ec(a) {
  return(yc ? 0 == a.na.button : "click" == a.type ? !0 : !!(a.na.button & Dc[0])) && !(D && rb && a.ctrlKey);
}
J.prototype.stopPropagation = function() {
  J.c.stopPropagation.call(this);
  this.na.stopPropagation ? this.na.stopPropagation() : this.na.cancelBubble = !0;
};
J.prototype.preventDefault = function() {
  J.c.preventDefault.call(this);
  var a = this.na;
  if (a.preventDefault) {
    a.preventDefault();
  } else {
    if (a.returnValue = !1, Ac) {
      try {
        if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) {
          a.keyCode = -1;
        }
      } catch (b) {
      }
    }
  }
};
J.prototype.g = function() {
};
var Fc = "closure_listenable_" + (1E6 * Math.random() | 0);
function Gc(a) {
  return!(!a || !a[Fc]);
}
var Hc = 0;
function Ic(a, b, c, d, f) {
  this.pb = a;
  this.rd = null;
  this.src = b;
  this.type = c;
  this.Sc = !!d;
  this.ad = f;
  this.key = ++Hc;
  this.Yb = this.Rc = !1;
}
function Jc(a) {
  a.Yb = !0;
  a.pb = null;
  a.rd = null;
  a.src = null;
  a.ad = null;
}
;function Kc(a) {
  this.src = a;
  this.G = {};
  this.Mc = 0;
}
Kc.prototype.add = function(a, b, c, d, f) {
  var g = a.toString();
  a = this.G[g];
  a || (a = this.G[g] = [], this.Mc++);
  var h = Lc(a, b, d, f);
  -1 < h ? (b = a[h], c || (b.Rc = !1)) : (b = new Ic(b, this.src, g, !!d, f), b.Rc = c, a.push(b));
  return b;
};
Kc.prototype.remove = function(a, b, c, d) {
  a = a.toString();
  if (!(a in this.G)) {
    return!1;
  }
  var f = this.G[a];
  b = Lc(f, b, c, d);
  return-1 < b ? (Jc(f[b]), y.splice.call(f, b, 1), 0 == f.length && (delete this.G[a], this.Mc--), !0) : !1;
};
function Mc(a, b) {
  var c = b.type;
  if (!(c in a.G)) {
    return!1;
  }
  var d = Xa(a.G[c], b);
  d && (Jc(b), 0 == a.G[c].length && (delete a.G[c], a.Mc--));
  return d;
}
Kc.prototype.Ca = function(a) {
  a = a && a.toString();
  var b = 0, c;
  for (c in this.G) {
    if (!a || c == a) {
      for (var d = this.G[c], f = 0;f < d.length;f++) {
        ++b, Jc(d[f]);
      }
      delete this.G[c];
      this.Mc--;
    }
  }
  return b;
};
Kc.prototype.oc = function(a, b, c, d) {
  a = this.G[a.toString()];
  var f = -1;
  a && (f = Lc(a, b, c, d));
  return-1 < f ? a[f] : null;
};
function Lc(a, b, c, d) {
  for (var f = 0;f < a.length;++f) {
    var g = a[f];
    if (!g.Yb && g.pb == b && g.Sc == !!c && g.ad == d) {
      return f;
    }
  }
  return-1;
}
;var Nc = "closure_lm_" + (1E6 * Math.random() | 0), Oc = {}, Pc = 0;
function K(a, b, c, d, f) {
  if (s(b)) {
    for (var g = 0;g < b.length;g++) {
      K(a, b[g], c, d, f);
    }
    return null;
  }
  c = Qc(c);
  return Gc(a) ? a.h(b, c, d, f) : Rc(a, b, c, !1, d, f);
}
function Rc(a, b, c, d, f, g) {
  if (!b) {
    throw Error("Invalid event type");
  }
  var h = !!f, k = Sc(a);
  k || (a[Nc] = k = new Kc(a));
  c = k.add(b, c, d, f, g);
  if (c.rd) {
    return c;
  }
  d = Tc();
  c.rd = d;
  d.src = a;
  d.pb = c;
  a.addEventListener ? a.addEventListener(b.toString(), d, h) : a.attachEvent(Uc(b.toString()), d);
  Pc++;
  return c;
}
function Tc() {
  var a = Vc, b = zc ? function(c) {
    return a.call(b.src, b.pb, c);
  } : function(c) {
    c = a.call(b.src, b.pb, c);
    if (!c) {
      return c;
    }
  };
  return b;
}
function Wc(a, b, c, d, f) {
  if (s(b)) {
    for (var g = 0;g < b.length;g++) {
      Wc(a, b[g], c, d, f);
    }
    return null;
  }
  c = Qc(c);
  return Gc(a) ? a.af(b, c, d, f) : Rc(a, b, c, !0, d, f);
}
function Xc(a, b, c, d, f) {
  if (s(b)) {
    for (var g = 0;g < b.length;g++) {
      Xc(a, b[g], c, d, f);
    }
  } else {
    c = Qc(c), Gc(a) ? a.$(b, c, d, f) : a && (a = Sc(a)) && (b = a.oc(b, c, !!d, f)) && Yc(b);
  }
}
function Yc(a) {
  if (fa(a) || !a || a.Yb) {
    return!1;
  }
  var b = a.src;
  if (Gc(b)) {
    return Mc(b.Ja, a);
  }
  var c = a.type, d = a.rd;
  b.removeEventListener ? b.removeEventListener(c, d, a.Sc) : b.detachEvent && b.detachEvent(Uc(c), d);
  Pc--;
  (c = Sc(b)) ? (Mc(c, a), 0 == c.Mc && (c.src = null, b[Nc] = null)) : Jc(a);
  return!0;
}
function Zc(a) {
  if (a) {
    if (Gc(a)) {
      a.sd(void 0);
    } else {
      if (a = Sc(a)) {
        var b = 0, c;
        for (c in a.G) {
          for (var d = a.G[c].concat(), f = 0;f < d.length;++f) {
            Yc(d[f]) && ++b;
          }
        }
      }
    }
  }
}
function Uc(a) {
  return a in Oc ? Oc[a] : Oc[a] = "on" + a;
}
function $c(a, b, c, d) {
  var f = 1;
  if (a = Sc(a)) {
    if (b = a.G[b.toString()]) {
      for (b = b.concat(), a = 0;a < b.length;a++) {
        var g = b[a];
        g && g.Sc == c && !g.Yb && (f &= !1 !== ad(g, d));
      }
    }
  }
  return Boolean(f);
}
function ad(a, b) {
  var c = a.pb, d = a.ad || a.src;
  a.Rc && Yc(a);
  return c.call(d, b);
}
function Vc(a, b) {
  if (a.Yb) {
    return!0;
  }
  if (!zc) {
    var c = b || aa("window.event"), d = new J(c, this), f = !0;
    if (!(0 > c.keyCode || void 0 != c.returnValue)) {
      a: {
        var g = !1;
        if (0 == c.keyCode) {
          try {
            c.keyCode = -1;
            break a;
          } catch (h) {
            g = !0;
          }
        }
        if (g || void 0 == c.returnValue) {
          c.returnValue = !0;
        }
      }
      c = [];
      for (g = d.currentTarget;g;g = g.parentNode) {
        c.push(g);
      }
      for (var g = a.type, k = c.length - 1;!d.sb && 0 <= k;k--) {
        d.currentTarget = c[k], f &= $c(c[k], g, !0, d);
      }
      for (k = 0;!d.sb && k < c.length;k++) {
        d.currentTarget = c[k], f &= $c(c[k], g, !1, d);
      }
    }
    return f;
  }
  return ad(a, new J(b, this));
}
function Sc(a) {
  a = a[Nc];
  return a instanceof Kc ? a : null;
}
var bd = "__closure_events_fn_" + (1E9 * Math.random() >>> 0);
function Qc(a) {
  if (u(a)) {
    return a;
  }
  a[bd] || (a[bd] = function(b) {
    return a.handleEvent(b);
  });
  return a[bd];
}
;function cd(a, b) {
  a && a.log(gc, b, void 0);
}
function dd(a, b) {
  a && a.info(b, void 0);
}
;var ed = !A || zb(9), fd = !B && !A || A && zb(9) || B && E("1.9.1"), gd = A && !E("9");
function L(a, b) {
  this.x = p(a) ? a : 0;
  this.y = p(b) ? b : 0;
}
e = L.prototype;
e.clone = function() {
  return new L(this.x, this.y);
};
e.toString = function() {
  return "(" + this.x + ", " + this.y + ")";
};
function hd(a, b) {
  return new L(a.x - b.x, a.y - b.y);
}
e.ceil = function() {
  this.x = Math.ceil(this.x);
  this.y = Math.ceil(this.y);
  return this;
};
e.floor = function() {
  this.x = Math.floor(this.x);
  this.y = Math.floor(this.y);
  return this;
};
e.round = function() {
  this.x = Math.round(this.x);
  this.y = Math.round(this.y);
  return this;
};
e.translate = function(a, b) {
  a instanceof L ? (this.x += a.x, this.y += a.y) : (this.x += a, fa(b) && (this.y += b));
  return this;
};
e.scale = function(a, b) {
  var c = fa(b) ? b : a;
  this.x *= a;
  this.y *= c;
  return this;
};
function id(a, b) {
  this.width = a;
  this.height = b;
}
e = id.prototype;
e.clone = function() {
  return new id(this.width, this.height);
};
e.toString = function() {
  return "(" + this.width + " x " + this.height + ")";
};
e.ceil = function() {
  this.width = Math.ceil(this.width);
  this.height = Math.ceil(this.height);
  return this;
};
e.floor = function() {
  this.width = Math.floor(this.width);
  this.height = Math.floor(this.height);
  return this;
};
e.round = function() {
  this.width = Math.round(this.width);
  this.height = Math.round(this.height);
  return this;
};
e.scale = function(a, b) {
  var c = fa(b) ? b : a;
  this.width *= a;
  this.height *= c;
  return this;
};
function M(a) {
  return a ? new jd(N(a)) : ya || (ya = new jd);
}
function kd(a, b) {
  bb(b, function(b, d) {
    "style" == d ? a.style.cssText = b : "class" == d ? a.className = b : "for" == d ? a.htmlFor = b : d in ld ? a.setAttribute(ld[d], b) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, b) : a[d] = b;
  });
}
var ld = {cellpadding:"cellPadding", cellspacing:"cellSpacing", colspan:"colSpan", frameborder:"frameBorder", height:"height", maxlength:"maxLength", role:"role", rowspan:"rowSpan", type:"type", usemap:"useMap", valign:"vAlign", width:"width"};
function md(a) {
  a = a.document;
  a = "CSS1Compat" == a.compatMode ? a.documentElement : a.body;
  return new id(a.clientWidth, a.clientHeight);
}
function nd(a) {
  return D || "CSS1Compat" != a.compatMode ? a.body || a.documentElement : a.documentElement;
}
function od(a) {
  return a ? a.parentWindow || a.defaultView : window;
}
function pd(a, b, c) {
  return qd(document, arguments);
}
function qd(a, b) {
  var c = b[0], d = b[1];
  if (!ed && d && (d.name || d.type)) {
    c = ["<", c];
    d.name && c.push(' name="', Ba(d.name), '"');
    if (d.type) {
      c.push(' type="', Ba(d.type), '"');
      var f = {};
      fb(f, d);
      delete f.type;
      d = f;
    }
    c.push(">");
    c = c.join("");
  }
  c = a.createElement(c);
  d && (t(d) ? c.className = d : s(d) ? c.className = d.join(" ") : kd(c, d));
  2 < b.length && rd(a, c, b, 2);
  return c;
}
function rd(a, b, c, d) {
  function f(c) {
    c && b.appendChild(t(c) ? a.createTextNode(c) : c);
  }
  for (;d < c.length;d++) {
    var g = c[d];
    !da(g) || ga(g) && 0 < g.nodeType ? f(g) : z(sd(g) ? Za(g) : g, f);
  }
}
function td(a, b) {
  rd(N(a), a, arguments, 1);
}
function ud(a) {
  for (var b;b = a.firstChild;) {
    a.removeChild(b);
  }
}
function vd(a) {
  return a && a.parentNode ? a.parentNode.removeChild(a) : null;
}
function P(a, b) {
  if (a.contains && 1 == b.nodeType) {
    return a == b || a.contains(b);
  }
  if ("undefined" != typeof a.compareDocumentPosition) {
    return a == b || Boolean(a.compareDocumentPosition(b) & 16);
  }
  for (;b && a != b;) {
    b = b.parentNode;
  }
  return b == a;
}
function N(a) {
  return 9 == a.nodeType ? a : a.ownerDocument || a.document;
}
function wd(a, b) {
  if ("textContent" in a) {
    a.textContent = b;
  } else {
    if (3 == a.nodeType) {
      a.data = b;
    } else {
      if (a.firstChild && 3 == a.firstChild.nodeType) {
        for (;a.lastChild != a.firstChild;) {
          a.removeChild(a.lastChild);
        }
        a.firstChild.data = b;
      } else {
        ud(a), a.appendChild(N(a).createTextNode(String(b)));
      }
    }
  }
}
var xd = {SCRIPT:1, STYLE:1, HEAD:1, IFRAME:1, OBJECT:1}, yd = {IMG:" ", BR:"\n"};
function zd(a, b) {
  b ? a.tabIndex = 0 : (a.tabIndex = -1, a.removeAttribute("tabIndex"));
}
function Ad(a) {
  a = a.getAttributeNode("tabindex");
  return null != a && a.specified;
}
function Bd(a) {
  a = a.tabIndex;
  return fa(a) && 0 <= a && 32768 > a;
}
function Cd(a) {
  var b = [];
  Dd(a, b, !1);
  return b.join("");
}
function Dd(a, b, c) {
  if (!(a.nodeName in xd)) {
    if (3 == a.nodeType) {
      c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
    } else {
      if (a.nodeName in yd) {
        b.push(yd[a.nodeName]);
      } else {
        for (a = a.firstChild;a;) {
          Dd(a, b, c), a = a.nextSibling;
        }
      }
    }
  }
}
function sd(a) {
  if (a && "number" == typeof a.length) {
    if (ga(a)) {
      return "function" == typeof a.item || "string" == typeof a.item;
    }
    if (u(a)) {
      return "function" == typeof a.item;
    }
  }
  return!1;
}
function jd(a) {
  this.o = a || m.document || document;
}
e = jd.prototype;
e.j = M;
function Ed(a) {
  return a.o;
}
e.a = function(a) {
  return t(a) ? this.o.getElementById(a) : a;
};
e.b = function(a, b, c) {
  return qd(this.o, arguments);
};
e.createElement = function(a) {
  return this.o.createElement(a);
};
e.createTextNode = function(a) {
  return this.o.createTextNode(String(a));
};
function Fd(a) {
  return "CSS1Compat" == a.o.compatMode;
}
function Gd(a) {
  a = a.o;
  return a.parentWindow || a.defaultView;
}
function Hd(a) {
  var b = a.o;
  a = nd(b);
  b = b.parentWindow || b.defaultView;
  return A && E("10") && b.pageYOffset != a.scrollTop ? new L(a.scrollLeft, a.scrollTop) : new L(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop);
}
e.Rd = function(a) {
  var b;
  a: {
    a = a || this.o;
    try {
      b = a && a.activeElement;
      break a;
    } catch (c) {
    }
    b = null;
  }
  return b;
};
e.appendChild = function(a, b) {
  a.appendChild(b);
};
e.append = td;
e.canHaveChildren = function(a) {
  if (1 != a.nodeType) {
    return!1;
  }
  switch(a.tagName) {
    case "APPLET":
    ;
    case "AREA":
    ;
    case "BASE":
    ;
    case "BR":
    ;
    case "COL":
    ;
    case "COMMAND":
    ;
    case "EMBED":
    ;
    case "FRAME":
    ;
    case "HR":
    ;
    case "IMG":
    ;
    case "INPUT":
    ;
    case "IFRAME":
    ;
    case "ISINDEX":
    ;
    case "KEYGEN":
    ;
    case "LINK":
    ;
    case "NOFRAMES":
    ;
    case "NOSCRIPT":
    ;
    case "META":
    ;
    case "OBJECT":
    ;
    case "PARAM":
    ;
    case "SCRIPT":
    ;
    case "SOURCE":
    ;
    case "STYLE":
    ;
    case "TRACK":
    ;
    case "WBR":
      return!1;
  }
  return!0;
};
e.removeNode = vd;
e.Sd = function(a) {
  return fd && void 0 != a.children ? a.children : Sa(a.childNodes, function(a) {
    return 1 == a.nodeType;
  });
};
e.contains = P;
e.lh = wd;
e.Ka = function(a) {
  var b;
  (b = "A" == a.tagName || "INPUT" == a.tagName || "TEXTAREA" == a.tagName || "SELECT" == a.tagName || "BUTTON" == a.tagName ? !a.disabled && (!Ad(a) || Bd(a)) : Ad(a) && Bd(a)) && A ? (a = u(a.getBoundingClientRect) ? a.getBoundingClientRect() : {height:a.offsetHeight, width:a.offsetWidth}, a = null != a && 0 < a.height && 0 < a.width) : a = b;
  return a;
};
function Id() {
  return D ? "Webkit" : B ? "Moz" : A ? "ms" : tb ? "O" : null;
}
;function Q(a, b, c, d) {
  this.top = a;
  this.right = b;
  this.bottom = c;
  this.left = d;
}
e = Q.prototype;
e.clone = function() {
  return new Q(this.top, this.right, this.bottom, this.left);
};
e.toString = function() {
  return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)";
};
e.contains = function(a) {
  return this && a ? a instanceof Q ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1;
};
e.expand = function(a, b, c, d) {
  ga(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += b, this.bottom += c, this.left -= d);
  return this;
};
function Jd(a, b) {
  var c = b.x < a.left ? b.x - a.left : b.x > a.right ? b.x - a.right : 0, d = b.y < a.top ? b.y - a.top : b.y > a.bottom ? b.y - a.bottom : 0;
  return Math.sqrt(c * c + d * d);
}
e.ceil = function() {
  this.top = Math.ceil(this.top);
  this.right = Math.ceil(this.right);
  this.bottom = Math.ceil(this.bottom);
  this.left = Math.ceil(this.left);
  return this;
};
e.floor = function() {
  this.top = Math.floor(this.top);
  this.right = Math.floor(this.right);
  this.bottom = Math.floor(this.bottom);
  this.left = Math.floor(this.left);
  return this;
};
e.round = function() {
  this.top = Math.round(this.top);
  this.right = Math.round(this.right);
  this.bottom = Math.round(this.bottom);
  this.left = Math.round(this.left);
  return this;
};
e.translate = function(a, b) {
  a instanceof L ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (this.left += a, this.right += a, fa(b) && (this.top += b, this.bottom += b));
  return this;
};
e.scale = function(a, b) {
  var c = fa(b) ? b : a;
  this.left *= a;
  this.right *= a;
  this.top *= c;
  this.bottom *= c;
  return this;
};
function Kd(a, b, c, d) {
  this.left = a;
  this.top = b;
  this.width = c;
  this.height = d;
}
e = Kd.prototype;
e.clone = function() {
  return new Kd(this.left, this.top, this.width, this.height);
};
function Ld(a) {
  return new Q(a.top, a.left + a.width, a.top + a.height, a.left);
}
e.toString = function() {
  return "(" + this.left + ", " + this.top + " - " + this.width + "w x " + this.height + "h)";
};
e.Xe = function(a) {
  var b = Math.max(this.left, a.left), c = Math.min(this.left + this.width, a.left + a.width);
  if (b <= c) {
    var d = Math.max(this.top, a.top);
    a = Math.min(this.top + this.height, a.top + a.height);
    if (d <= a) {
      return this.left = b, this.top = d, this.width = c - b, this.height = a - d, !0;
    }
  }
  return!1;
};
e.contains = function(a) {
  return a instanceof Kd ? this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height : a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height;
};
e.ceil = function() {
  this.left = Math.ceil(this.left);
  this.top = Math.ceil(this.top);
  this.width = Math.ceil(this.width);
  this.height = Math.ceil(this.height);
  return this;
};
e.floor = function() {
  this.left = Math.floor(this.left);
  this.top = Math.floor(this.top);
  this.width = Math.floor(this.width);
  this.height = Math.floor(this.height);
  return this;
};
e.round = function() {
  this.left = Math.round(this.left);
  this.top = Math.round(this.top);
  this.width = Math.round(this.width);
  this.height = Math.round(this.height);
  return this;
};
e.translate = function(a, b) {
  a instanceof L ? (this.left += a.x, this.top += a.y) : (this.left += a, fa(b) && (this.top += b));
  return this;
};
e.scale = function(a, b) {
  var c = fa(b) ? b : a;
  this.left *= a;
  this.width *= a;
  this.top *= c;
  this.height *= c;
  return this;
};
function Md(a, b, c) {
  if (t(b)) {
    (b = Nd(a, b)) && (a.style[b] = c);
  } else {
    for (var d in b) {
      c = a;
      var f = b[d], g = Nd(c, d);
      g && (c.style[g] = f);
    }
  }
}
function Nd(a, b) {
  var c = La(b);
  if (void 0 === a.style[c]) {
    var d = Id() + Ma(c);
    if (void 0 !== a.style[d]) {
      return d;
    }
  }
  return c;
}
function R(a, b) {
  var c = N(a);
  return c.defaultView && c.defaultView.getComputedStyle && (c = c.defaultView.getComputedStyle(a, null)) ? c[b] || c.getPropertyValue(b) || "" : "";
}
function Od(a, b) {
  return R(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b];
}
function Pd(a) {
  return Od(a, "position");
}
function Qd(a, b, c) {
  var d, f = B && (rb || vb) && E("1.9");
  b instanceof L ? (d = b.x, b = b.y) : (d = b, b = c);
  a.style.left = Rd(d, f);
  a.style.top = Rd(b, f);
}
function Sd(a) {
  a = a ? N(a) : document;
  return!A || zb(9) || Fd(M(a)) ? a.documentElement : a.body;
}
function Td(a) {
  var b;
  try {
    b = a.getBoundingClientRect();
  } catch (c) {
    return{left:0, top:0, right:0, bottom:0};
  }
  A && a.ownerDocument.body && (a = a.ownerDocument, b.left -= a.documentElement.clientLeft + a.body.clientLeft, b.top -= a.documentElement.clientTop + a.body.clientTop);
  return b;
}
function Ud(a) {
  if (A && !zb(8)) {
    return a.offsetParent;
  }
  var b = N(a), c = Od(a, "position"), d = "fixed" == c || "absolute" == c;
  for (a = a.parentNode;a && a != b;a = a.parentNode) {
    if (c = Od(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) {
      return a;
    }
  }
  return null;
}
function Vd(a) {
  for (var b = new Q(0, Infinity, Infinity, 0), c = M(a), d = c.o.body, f = c.o.documentElement, g = nd(c.o);a = Ud(a);) {
    if (!(A && 0 == a.clientWidth || D && 0 == a.clientHeight && a == d) && a != d && a != f && "visible" != Od(a, "overflow")) {
      var h = Wd(a), k;
      k = a;
      if (B && !E("1.9")) {
        var l = parseFloat(R(k, "borderLeftWidth"));
        if (Xd(k)) {
          var n = k.offsetWidth - k.clientWidth - l - parseFloat(R(k, "borderRightWidth")), l = l + n
        }
        k = new L(l, parseFloat(R(k, "borderTopWidth")));
      } else {
        k = new L(k.clientLeft, k.clientTop);
      }
      h.x += k.x;
      h.y += k.y;
      b.top = Math.max(b.top, h.y);
      b.right = Math.min(b.right, h.x + a.clientWidth);
      b.bottom = Math.min(b.bottom, h.y + a.clientHeight);
      b.left = Math.max(b.left, h.x);
    }
  }
  d = g.scrollLeft;
  g = g.scrollTop;
  b.left = Math.max(b.left, d);
  b.top = Math.max(b.top, g);
  c = md(Gd(c) || window);
  b.right = Math.min(b.right, d + c.width);
  b.bottom = Math.min(b.bottom, g + c.height);
  return 0 <= b.top && 0 <= b.left && b.bottom > b.top && b.right > b.left ? b : null;
}
function Wd(a) {
  var b, c = N(a), d = Od(a, "position"), f = B && c.getBoxObjectFor && !a.getBoundingClientRect && "absolute" == d && (b = c.getBoxObjectFor(a)) && (0 > b.screenX || 0 > b.screenY), g = new L(0, 0), h = Sd(c);
  if (a == h) {
    return g;
  }
  if (a.getBoundingClientRect) {
    b = Td(a), a = Hd(M(c)), g.x = b.left + a.x, g.y = b.top + a.y;
  } else {
    if (c.getBoxObjectFor && !f) {
      b = c.getBoxObjectFor(a), a = c.getBoxObjectFor(h), g.x = b.screenX - a.screenX, g.y = b.screenY - a.screenY;
    } else {
      b = a;
      do {
        g.x += b.offsetLeft;
        g.y += b.offsetTop;
        b != a && (g.x += b.clientLeft || 0, g.y += b.clientTop || 0);
        if (D && "fixed" == Pd(b)) {
          g.x += c.body.scrollLeft;
          g.y += c.body.scrollTop;
          break;
        }
        b = b.offsetParent;
      } while (b && b != a);
      if (tb || D && "absolute" == d) {
        g.y -= c.body.offsetTop;
      }
      for (b = a;(b = Ud(b)) && b != c.body && b != h;) {
        g.x -= b.scrollLeft, tb && "TR" == b.tagName || (g.y -= b.scrollTop);
      }
    }
  }
  return g;
}
function Yd(a, b, c) {
  if (b instanceof id) {
    c = b.height, b = b.width;
  } else {
    if (void 0 == c) {
      throw Error("missing height argument");
    }
  }
  a.style.width = Rd(b, !0);
  a.style.height = Rd(c, !0);
}
function Rd(a, b) {
  "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
  return a;
}
function Zd(a) {
  var b = $d;
  if ("none" != Od(a, "display")) {
    return b(a);
  }
  var c = a.style, d = c.display, f = c.visibility, g = c.position;
  c.visibility = "hidden";
  c.position = "absolute";
  c.display = "inline";
  a = b(a);
  c.display = d;
  c.position = g;
  c.visibility = f;
  return a;
}
function $d(a) {
  var b = a.offsetWidth, c = a.offsetHeight, d = D && !b && !c;
  return p(b) && !d || !a.getBoundingClientRect ? new id(b, c) : (a = Td(a), new id(a.right - a.left, a.bottom - a.top));
}
function ae(a) {
  var b = Wd(a);
  a = Zd(a);
  return new Kd(b.x, b.y, a.width, a.height);
}
function be(a, b) {
  var c = a.style;
  "opacity" in c ? c.opacity = b : "MozOpacity" in c ? c.MozOpacity = b : "filter" in c && (c.filter = "" === b ? "" : "alpha(opacity=" + 100 * b + ")");
}
function S(a, b) {
  a.style.display = b ? "" : "none";
}
function Xd(a) {
  return "rtl" == Od(a, "direction");
}
var ce = B ? "MozUserSelect" : D ? "WebkitUserSelect" : null;
function de(a, b, c) {
  c = c ? null : a.getElementsByTagName("*");
  if (ce) {
    if (b = b ? "none" : "", a.style[ce] = b, c) {
      a = 0;
      for (var d;d = c[a];a++) {
        d.style[ce] = b;
      }
    }
  } else {
    if (A || tb) {
      if (b = b ? "on" : "", a.setAttribute("unselectable", b), c) {
        for (a = 0;d = c[a];a++) {
          d.setAttribute("unselectable", b);
        }
      }
    }
  }
}
function ee(a, b) {
  if (/^\d+px?$/.test(b)) {
    return parseInt(b, 10);
  }
  var c = a.style.left, d = a.runtimeStyle.left;
  a.runtimeStyle.left = a.currentStyle.left;
  a.style.left = b;
  var f = a.style.pixelLeft;
  a.style.left = c;
  a.runtimeStyle.left = d;
  return f;
}
function fe(a, b) {
  var c = a.currentStyle ? a.currentStyle[b] : null;
  return c ? ee(a, c) : 0;
}
var ge = {thin:2, medium:4, thick:6};
function he(a, b) {
  if ("none" == (a.currentStyle ? a.currentStyle[b + "Style"] : null)) {
    return 0;
  }
  var c = a.currentStyle ? a.currentStyle[b + "Width"] : null;
  return c in ge ? ge[c] : ee(a, c);
}
function ie(a) {
  if (A && !zb(9)) {
    var b = he(a, "borderLeft"), c = he(a, "borderRight"), d = he(a, "borderTop");
    a = he(a, "borderBottom");
    return new Q(d, c, a, b);
  }
  b = R(a, "borderLeftWidth");
  c = R(a, "borderRightWidth");
  d = R(a, "borderTopWidth");
  a = R(a, "borderBottomWidth");
  return new Q(parseFloat(d), parseFloat(c), parseFloat(a), parseFloat(b));
}
var je = /matrix\([0-9\.\-]+, [0-9\.\-]+, [0-9\.\-]+, [0-9\.\-]+, ([0-9\.\-]+)p?x?, ([0-9\.\-]+)p?x?\)/;
function ke(a) {
  ta.call(this);
  this.Y = a;
  this.w = {};
}
w(ke, ta);
var le = [];
e = ke.prototype;
e.h = function(a, b, c, d) {
  s(b) || (b && (le[0] = b.toString()), b = le);
  for (var f = 0;f < b.length;f++) {
    var g = K(a, b[f], c || this.handleEvent, d || !1, this.Y || this);
    if (!g) {
      break;
    }
    this.w[g.key] = g;
  }
  return this;
};
e.af = function(a, b, c, d) {
  return me(this, a, b, c, d);
};
function me(a, b, c, d, f, g) {
  if (s(c)) {
    for (var h = 0;h < c.length;h++) {
      me(a, b, c[h], d, f, g);
    }
  } else {
    b = Wc(b, c, d || a.handleEvent, f, g || a.Y || a);
    if (!b) {
      return a;
    }
    a.w[b.key] = b;
  }
  return a;
}
e.$ = function(a, b, c, d, f) {
  if (s(b)) {
    for (var g = 0;g < b.length;g++) {
      this.$(a, b[g], c, d, f);
    }
  } else {
    c = c || this.handleEvent, f = f || this.Y || this, c = Qc(c), d = !!d, b = Gc(a) ? a.oc(b, c, d, f) : a ? (a = Sc(a)) ? a.oc(b, c, d, f) : null : null, b && (Yc(b), delete this.w[b.key]);
  }
  return this;
};
e.Ca = function() {
  bb(this.w, Yc);
  this.w = {};
};
e.g = function() {
  ke.c.g.call(this);
  this.Ca();
};
e.handleEvent = function() {
  throw Error("EventHandler.handleEvent not implemented");
};
function T() {
  ta.call(this);
  this.Ja = new Kc(this);
  this.Lf = this;
  this.od = null;
}
w(T, ta);
T.prototype[Fc] = !0;
e = T.prototype;
e.se = function(a) {
  this.od = a;
};
e.addEventListener = function(a, b, c, d) {
  K(this, a, b, c, d);
};
e.removeEventListener = function(a, b, c, d) {
  Xc(this, a, b, c, d);
};
e.dispatchEvent = function(a) {
  var b, c = this.od;
  if (c) {
    for (b = [];c;c = c.od) {
      b.push(c);
    }
  }
  var c = this.Lf, d = a.type || a;
  if (t(a)) {
    a = new I(a, c);
  } else {
    if (a instanceof I) {
      a.target = a.target || c;
    } else {
      var f = a;
      a = new I(d, c);
      fb(a, f);
    }
  }
  var f = !0, g;
  if (b) {
    for (var h = b.length - 1;!a.sb && 0 <= h;h--) {
      g = a.currentTarget = b[h], f = ne(g, d, !0, a) && f;
    }
  }
  a.sb || (g = a.currentTarget = c, f = ne(g, d, !0, a) && f, a.sb || (f = ne(g, d, !1, a) && f));
  if (b) {
    for (h = 0;!a.sb && h < b.length;h++) {
      g = a.currentTarget = b[h], f = ne(g, d, !1, a) && f;
    }
  }
  return f;
};
e.g = function() {
  T.c.g.call(this);
  this.sd();
  this.od = null;
};
e.h = function(a, b, c, d) {
  return this.Ja.add(String(a), b, !1, c, d);
};
e.af = function(a, b, c, d) {
  return this.Ja.add(String(a), b, !0, c, d);
};
e.$ = function(a, b, c, d) {
  return this.Ja.remove(String(a), b, c, d);
};
e.sd = function(a) {
  return this.Ja ? this.Ja.Ca(a) : 0;
};
function ne(a, b, c, d) {
  b = a.Ja.G[String(b)];
  if (!b) {
    return!0;
  }
  b = b.concat();
  for (var f = !0, g = 0;g < b.length;++g) {
    var h = b[g];
    if (h && !h.Yb && h.Sc == c) {
      var k = h.pb, l = h.ad || h.src;
      h.Rc && Mc(a.Ja, h);
      f = !1 !== k.call(l, d) && f;
    }
  }
  return f && 0 != d.sf;
}
e.oc = function(a, b, c, d) {
  return this.Ja.oc(String(a), b, c, d);
};
function oe() {
}
ba(oe);
oe.prototype.Kg = 0;
function U(a) {
  T.call(this);
  this.ga = a || M();
  this.tb = pe;
  this.Pb = null;
  this.t = !1;
  this.e = null;
  this.Ta = void 0;
  this.Qa = this.m = this.A = null;
  this.uh = !1;
}
w(U, T);
U.prototype.yg = oe.mb();
var pe = null;
function qe(a, b) {
  switch(a) {
    case 1:
      return b ? "disable" : "enable";
    case 2:
      return b ? "highlight" : "unhighlight";
    case 4:
      return b ? "activate" : "deactivate";
    case 8:
      return b ? "select" : "unselect";
    case 16:
      return b ? "check" : "uncheck";
    case 32:
      return b ? "focus" : "blur";
    case 64:
      return b ? "open" : "close";
  }
  throw Error("Invalid component state");
}
e = U.prototype;
e.J = function() {
  return this.Pb || (this.Pb = ":" + (this.yg.Kg++).toString(36));
};
e.a = function() {
  return this.e;
};
e.W = function() {
  this.Ta || (this.Ta = new ke(this));
  return this.Ta;
};
e.Fc = function(a) {
  if (this == a) {
    throw Error("Unable to set parent component");
  }
  if (a && this.A && this.Pb && re(this.A, this.Pb) && this.A != a) {
    throw Error("Unable to set parent component");
  }
  this.A = a;
  U.c.se.call(this, a);
};
e.getParent = function() {
  return this.A;
};
e.se = function(a) {
  if (this.A && this.A != a) {
    throw Error("Method not supported");
  }
  U.c.se.call(this, a);
};
e.j = function() {
  return this.ga;
};
e.b = function() {
  this.e = this.ga.createElement("div");
};
e.Da = function(a) {
  se(this, a);
};
function se(a, b, c) {
  if (a.t) {
    throw Error("Component already rendered");
  }
  a.e || a.b();
  b ? b.insertBefore(a.e, c || null) : a.ga.o.body.appendChild(a.e);
  a.A && !a.A.t || a.L();
}
e.L = function() {
  this.t = !0;
  te(this, function(a) {
    !a.t && a.a() && a.L();
  });
};
e.ca = function() {
  te(this, function(a) {
    a.t && a.ca();
  });
  this.Ta && this.Ta.Ca();
  this.t = !1;
};
e.g = function() {
  this.t && this.ca();
  this.Ta && (this.Ta.C(), delete this.Ta);
  te(this, function(a) {
    a.C();
  });
  !this.uh && this.e && vd(this.e);
  this.A = this.e = this.Qa = this.m = null;
  U.c.g.call(this);
};
e.U = function(a, b) {
  this.Pc(a, ue(this), b);
};
e.Pc = function(a, b, c) {
  if (a.t && (c || !this.t)) {
    throw Error("Component already rendered");
  }
  if (0 > b || b > ue(this)) {
    throw Error("Child component index out of bounds");
  }
  this.Qa && this.m || (this.Qa = {}, this.m = []);
  if (a.getParent() == this) {
    var d = a.J();
    this.Qa[d] = a;
    Xa(this.m, a);
  } else {
    var d = this.Qa, f = a.J();
    if (f in d) {
      throw Error('The object already contains the key "' + f + '"');
    }
    d[f] = a;
  }
  a.Fc(this);
  $a(this.m, b, 0, a);
  a.t && this.t && a.getParent() == this ? (c = this.ha(), c.insertBefore(a.a(), c.childNodes[b] || null)) : c ? (this.e || this.b(), b = W(this, b + 1), se(a, this.ha(), b ? b.e : null)) : this.t && !a.t && a.e && a.e.parentNode && 1 == a.e.parentNode.nodeType && a.L();
};
e.ha = function() {
  return this.e;
};
function ve(a) {
  null == a.tb && (a.tb = Xd(a.t ? a.e : a.ga.o.body));
  return a.tb;
}
e.ac = function(a) {
  if (this.t) {
    throw Error("Component already rendered");
  }
  this.tb = a;
};
function ue(a) {
  return a.m ? a.m.length : 0;
}
function re(a, b) {
  var c;
  a.Qa && b ? (c = a.Qa, c = (b in c ? c[b] : void 0) || null) : c = null;
  return c;
}
function W(a, b) {
  return a.m ? a.m[b] || null : null;
}
function te(a, b, c) {
  a.m && z(a.m, b, c);
}
function we(a, b) {
  return a.m && b ? Ra(a.m, b) : -1;
}
e.removeChild = function(a, b) {
  if (a) {
    var c = t(a) ? a : a.J();
    a = re(this, c);
    if (c && a) {
      var d = this.Qa;
      c in d && delete d[c];
      Xa(this.m, a);
      b && (a.ca(), a.e && vd(a.e));
      a.Fc(null);
    }
  }
  if (!a) {
    throw Error("Child is not in parent component");
  }
  return a;
};
function xe() {
  U.call(this);
}
w(xe, U);
e = xe.prototype;
e.fe = null;
e.g = function() {
  Zc(this.a());
  Yc(this.fe);
  this.fe = null;
  xe.c.g.call(this);
};
e.b = function() {
  var a = this.j().b("DIV", "banner");
  Md(a, "position", "absolute");
  Md(a, "top", "0");
  K(a, "click", v(this.k, this, !1));
  this.e = a;
  this.ud();
  this.fe = K(ye(this), "resize", this.ud, !1, this);
};
e.k = function(a) {
  S(this.a(), a);
  this.ud();
};
e.vf = function(a) {
  this.j().lh(this.a(), a);
  this.ud();
};
function ye(a) {
  a = Ed(a.j());
  return od(a) || window;
}
e.ud = function() {
  if (!this.a().style.display) {
    var a = ye(this), b = Hd(this.j()).x, c = Zd(this.a()), a = Math.max(b + md(a || window).width / 2 - c.width / 2, 0);
    Qd(this.a(), a, 0);
  }
};
function ze(a, b, c) {
  I.call(this, a, b);
  this.data = c;
}
w(ze, I);
var Ae;
function Be(a, b) {
  b ? a.setAttribute("role", b) : a.removeAttribute("role");
}
function Ce(a, b, c) {
  s(c) && (c = c.join(" "));
  var d = "aria-" + b;
  "" === c || void 0 == c ? (Ae || (Ae = {atomic:!1, autocomplete:"none", dropeffect:"none", haspopup:!1, live:"off", multiline:!1, multiselectable:!1, orientation:"vertical", readonly:!1, relevant:"additions text", required:!1, sort:"none", busy:!1, disabled:!1, hidden:!1, invalid:"false"}), c = Ae, b in c ? a.setAttribute(d, c[b]) : a.removeAttribute(d)) : a.setAttribute(d, c);
}
;function De(a) {
  if (a.classList) {
    return a.classList;
  }
  a = a.className;
  return t(a) && a.match(/\S+/g) || [];
}
function Ee(a, b) {
  return a.classList ? a.classList.contains(b) : Wa(De(a), b);
}
function Fe(a, b) {
  a.classList ? a.classList.add(b) : Ee(a, b) || (a.className += 0 < a.className.length ? " " + b : b);
}
function Ge(a, b) {
  if (a.classList) {
    z(b, function(b) {
      Fe(a, b);
    });
  } else {
    var c = {};
    z(De(a), function(a) {
      c[a] = !0;
    });
    z(b, function(a) {
      c[a] = !0;
    });
    a.className = "";
    for (var d in c) {
      a.className += 0 < a.className.length ? " " + d : d;
    }
  }
}
function He(a, b) {
  a.classList ? a.classList.remove(b) : Ee(a, b) && (a.className = Sa(De(a), function(a) {
    return a != b;
  }).join(" "));
}
function Ie(a, b) {
  a.classList ? z(b, function(b) {
    He(a, b);
  }) : a.className = Sa(De(a), function(a) {
    return!Wa(b, a);
  }).join(" ");
}
;hb("area base br col command embed hr img input keygen link meta param source track wbr".split(" "));
function Je() {
  this.le = "";
  this.Kf = Ke;
  this.Yf = null;
}
Je.prototype.toString = function() {
  return "SafeHtml{" + this.le + "}";
};
function Le(a) {
  if (a instanceof Je && a.constructor === Je && a.Kf === Ke) {
    return a.le;
  }
  Oa("expected object of type SafeHtml, got '" + a + "'");
  return "type_error:SafeHtml";
}
hb("action", "cite", "data", "formaction", "href", "manifest", "poster", "src");
hb("link", "script", "style");
var Ke = {};
function Me(a, b) {
  var c = new Je;
  c.le = a;
  c.Yf = b;
  return c;
}
var Ne = Me("", 0);
function Oe(a, b, c, d, f) {
  if (!(A || D && E("525"))) {
    return!0;
  }
  if (rb && f) {
    return Pe(a);
  }
  if (f && !d) {
    return!1;
  }
  fa(b) && (b = Qe(b));
  if (!c && (17 == b || 18 == b || rb && 91 == b)) {
    return!1;
  }
  if (D && d && c) {
    switch(a) {
      case 220:
      ;
      case 219:
      ;
      case 221:
      ;
      case 192:
      ;
      case 186:
      ;
      case 189:
      ;
      case 187:
      ;
      case 188:
      ;
      case 190:
      ;
      case 191:
      ;
      case 192:
      ;
      case 222:
        return!1;
    }
  }
  if (A && d && b == a) {
    return!1;
  }
  switch(a) {
    case 13:
      return!0;
    case 27:
      return!D;
  }
  return Pe(a);
}
function Pe(a) {
  if (48 <= a && 57 >= a || 96 <= a && 106 >= a || 65 <= a && 90 >= a || D && 0 == a) {
    return!0;
  }
  switch(a) {
    case 32:
    ;
    case 63:
    ;
    case 107:
    ;
    case 109:
    ;
    case 110:
    ;
    case 111:
    ;
    case 186:
    ;
    case 59:
    ;
    case 189:
    ;
    case 187:
    ;
    case 61:
    ;
    case 188:
    ;
    case 190:
    ;
    case 191:
    ;
    case 192:
    ;
    case 222:
    ;
    case 219:
    ;
    case 220:
    ;
    case 221:
      return!0;
    default:
      return!1;
  }
}
function Qe(a) {
  if (B) {
    a = Re(a);
  } else {
    if (rb && D) {
      a: {
        switch(a) {
          case 93:
            a = 91;
            break a;
        }
      }
    }
  }
  return a;
}
function Re(a) {
  switch(a) {
    case 61:
      return 187;
    case 59:
      return 186;
    case 173:
      return 189;
    case 224:
      return 91;
    case 0:
      return 224;
    default:
      return a;
  }
}
;function Se(a, b, c) {
  T.call(this);
  this.target = a;
  this.handle = b || a;
  this.jd = c || new Kd(NaN, NaN, NaN, NaN);
  this.o = N(a);
  this.D = new ke(this);
  a = ma(wa, this.D);
  this.rb || (this.rb = []);
  this.rb.push(p(void 0) ? v(a, void 0) : a);
  K(this.handle, ["touchstart", "mousedown"], this.Bf, !1, this);
}
w(Se, T);
var Te = A || B && E("1.9.3");
e = Se.prototype;
e.clientX = 0;
e.clientY = 0;
e.screenX = 0;
e.screenY = 0;
e.Cf = 0;
e.Df = 0;
e.deltaX = 0;
e.deltaY = 0;
e.ma = !0;
e.gb = !1;
e.Ue = 0;
e.zg = !1;
e.ve = !1;
e.W = function() {
  return this.D;
};
e.la = function(a) {
  this.ma = a;
};
e.g = function() {
  Se.c.g.call(this);
  Xc(this.handle, ["touchstart", "mousedown"], this.Bf, !1, this);
  this.D.Ca();
  Te && this.o.releaseCapture();
  this.handle = this.target = null;
};
function Ue(a) {
  p(a.tb) || (a.tb = Xd(a.target));
  return a.tb;
}
e.Bf = function(a) {
  var b = "mousedown" == a.type;
  if (!this.ma || this.gb || b && !Ec(a)) {
    this.dispatchEvent("earlycancel");
  } else {
    Ve(a);
    if (0 == this.Ue) {
      if (this.dispatchEvent(new We("start", this, a.clientX, a.clientY))) {
        this.gb = !0, a.preventDefault();
      } else {
        return;
      }
    } else {
      a.preventDefault();
    }
    var b = this.o, c = b.documentElement, d = !Te;
    this.D.h(b, ["touchmove", "mousemove"], this.pg, d);
    this.D.h(b, ["touchend", "mouseup"], this.Wc, d);
    Te ? (c.setCapture(!1), this.D.h(c, "losecapture", this.Wc)) : this.D.h(od(b), "blur", this.Wc);
    A && this.zg && this.D.h(b, "dragstart", Bc);
    this.jh && this.D.h(this.jh, "scroll", this.Wg, d);
    this.clientX = this.Cf = a.clientX;
    this.clientY = this.Df = a.clientY;
    this.screenX = a.screenX;
    this.screenY = a.screenY;
    this.ve ? (a = this.target, b = a.offsetLeft, c = a.offsetParent, c || "fixed" != Pd(a) || (c = N(a).documentElement), c ? (B ? (d = ie(c), b += d.left) : zb(8) && !zb(9) && (d = ie(c), b -= d.left), a = Xd(c) ? c.clientWidth - (b + a.offsetWidth) : b) : a = b) : a = this.target.offsetLeft;
    this.deltaX = a;
    this.deltaY = this.target.offsetTop;
    this.he = Hd(M(this.o));
    oa();
  }
};
e.Wc = function(a) {
  this.D.Ca();
  Te && this.o.releaseCapture();
  if (this.gb) {
    Ve(a);
    this.gb = !1;
    var b = Xe(this, this.deltaX), c = Ye(this, this.deltaY);
    this.dispatchEvent(new We("end", this, a.clientX, a.clientY, 0, b, c));
  } else {
    this.dispatchEvent("earlycancel");
  }
};
function Ve(a) {
  var b = a.type;
  "touchstart" == b || "touchmove" == b ? a.xc(a.na.targetTouches[0], a.currentTarget) : "touchend" != b && "touchcancel" != b || a.xc(a.na.changedTouches[0], a.currentTarget);
}
e.pg = function(a) {
  if (this.ma) {
    Ve(a);
    var b = (this.ve && Ue(this) ? -1 : 1) * (a.clientX - this.clientX), c = a.clientY - this.clientY;
    this.clientX = a.clientX;
    this.clientY = a.clientY;
    this.screenX = a.screenX;
    this.screenY = a.screenY;
    if (!this.gb) {
      var d = this.Cf - this.clientX, f = this.Df - this.clientY;
      if (d * d + f * f > this.Ue) {
        if (this.dispatchEvent(new We("start", this, a.clientX, a.clientY))) {
          this.gb = !0;
        } else {
          this.Db || this.Wc(a);
          return;
        }
      }
    }
    c = Ze(this, b, c);
    b = c.x;
    c = c.y;
    this.gb && this.dispatchEvent(new We("beforedrag", this, a.clientX, a.clientY, 0, b, c)) && ($e(this, a, b, c), a.preventDefault());
  }
};
function Ze(a, b, c) {
  var d = Hd(M(a.o));
  b += d.x - a.he.x;
  c += d.y - a.he.y;
  a.he = d;
  a.deltaX += b;
  a.deltaY += c;
  b = Xe(a, a.deltaX);
  a = Ye(a, a.deltaY);
  return new L(b, a);
}
e.Wg = function(a) {
  var b = Ze(this, 0, 0);
  a.clientX = this.clientX;
  a.clientY = this.clientY;
  $e(this, a, b.x, b.y);
};
function $e(a, b, c, d) {
  a.ve && Ue(a) ? a.target.style.right = c + "px" : a.target.style.left = c + "px";
  a.target.style.top = d + "px";
  a.dispatchEvent(new We("drag", a, b.clientX, b.clientY, 0, c, d));
}
function Xe(a, b) {
  var c = a.jd, d = isNaN(c.left) ? null : c.left, c = isNaN(c.width) ? 0 : c.width;
  return Math.min(null != d ? d + c : Infinity, Math.max(null != d ? d : -Infinity, b));
}
function Ye(a, b) {
  var c = a.jd, d = isNaN(c.top) ? null : c.top, c = isNaN(c.height) ? 0 : c.height;
  return Math.min(null != d ? d + c : Infinity, Math.max(null != d ? d : -Infinity, b));
}
function We(a, b, c, d, f, g, h) {
  I.call(this, a);
  this.clientX = c;
  this.clientY = d;
  this.left = p(g) ? g : b.deltaX;
  this.top = p(h) ? h : b.deltaY;
}
w(We, I);
function af(a, b, c) {
  if (u(a)) {
    c && (a = v(a, c));
  } else {
    if (a && "function" == typeof a.handleEvent) {
      a = v(a.handleEvent, a);
    } else {
      throw Error("Invalid listener argument");
    }
  }
  return 2147483647 < b ? -1 : m.setTimeout(a, b || 0);
}
;function bf(a) {
  T.call(this);
  this.e = a;
  a = A ? "focusout" : "blur";
  this.Fg = K(this.e, A ? "focusin" : "focus", this, !A);
  this.Gg = K(this.e, a, this, !A);
}
w(bf, T);
bf.prototype.handleEvent = function(a) {
  var b = new J(a.na);
  b.type = "focusin" == a.type || "focus" == a.type ? "focusin" : "focusout";
  this.dispatchEvent(b);
};
bf.prototype.g = function() {
  bf.c.g.call(this);
  Yc(this.Fg);
  Yc(this.Gg);
  delete this.e;
};
function cf(a, b) {
  T.call(this);
  this.Y = new ke(this);
  this.pe(a || null);
  b && (this.dc = b);
}
w(cf, T);
e = cf.prototype;
e.e = null;
e.Rf = !0;
e.Ae = null;
e.Be = null;
e.Qb = !1;
e.mh = !1;
e.be = -1;
e.xg = !1;
e.ag = !0;
e.dc = "toggle_display";
e.a = function() {
  return this.e;
};
e.pe = function(a) {
  if (this.Qb) {
    throw Error("Can not change this state of the popup while showing.");
  }
  this.e = a;
};
e.W = function() {
  return this.Y;
};
e.n = function() {
  return this.Qb;
};
e.k = function(a) {
  this.Hc && this.Hc.stop();
  this.vc && this.vc.stop();
  a ? this.te() : this.Nb();
};
e.Z = r;
e.te = function() {
  if (!this.Qb && this.ee()) {
    if (!this.e) {
      throw Error("Caller must call setElement before trying to show the popup");
    }
    this.Z();
    var a = N(this.e);
    this.xg && this.Y.h(a, "keydown", this.Sg, !0);
    if (this.Rf) {
      if (this.Y.h(a, "mousedown", this.hf, !0), A) {
        var b;
        try {
          b = a.activeElement;
        } catch (c) {
        }
        for (;b && "IFRAME" == b.nodeName;) {
          try {
            var d = b.contentDocument || b.contentWindow.document;
          } catch (f) {
            break;
          }
          a = d;
          b = a.activeElement;
        }
        this.Y.h(a, "mousedown", this.hf, !0);
        this.Y.h(a, "deactivate", this.gf);
      } else {
        this.Y.h(a, "blur", this.gf);
      }
    }
    "toggle_display" == this.dc ? (this.e.style.visibility = "visible", S(this.e, !0)) : "move_offscreen" == this.dc && this.Z();
    this.Qb = !0;
    this.be = oa();
    this.Hc ? (Wc(this.Hc, "end", this.Xa, !1, this), this.Hc.play()) : this.Xa();
  }
};
e.Nb = function(a) {
  if (!this.Qb || !this.dispatchEvent({type:"beforehide", target:a})) {
    return!1;
  }
  this.Y && this.Y.Ca();
  this.Qb = !1;
  oa();
  this.vc ? (Wc(this.vc, "end", ma(this.Ee, a), !1, this), this.vc.play()) : this.Ee(a);
  return!0;
};
e.Ee = function(a) {
  "toggle_display" == this.dc ? this.mh ? af(this.Te, 0, this) : this.Te() : "move_offscreen" == this.dc && (this.e.style.top = "-10000px");
  this.Ac(a);
};
e.Te = function() {
  this.e.style.visibility = "hidden";
  S(this.e, !1);
};
e.ee = function() {
  return this.dispatchEvent("beforeshow");
};
e.Xa = function() {
  this.dispatchEvent("show");
};
e.Ac = function(a) {
  this.dispatchEvent({type:"hide", target:a});
};
e.hf = function(a) {
  a = a.target;
  P(this.e, a) || df(this, a) || this.Be && !P(this.Be, a) || 150 > oa() - this.be || this.Nb(a);
};
e.Sg = function(a) {
  27 == a.keyCode && this.Nb(a.target) && (a.preventDefault(), a.stopPropagation());
};
e.gf = function(a) {
  if (this.ag) {
    var b = N(this.e);
    if ("undefined" != typeof document.activeElement) {
      if (a = b.activeElement, !a || P(this.e, a) || "BODY" == a.tagName) {
        return;
      }
    } else {
      if (a.target != b) {
        return;
      }
    }
    150 > oa() - this.be || this.Nb();
  }
};
function df(a, b) {
  return Ua(a.Ae || [], function(a) {
    return b === a || P(a, b);
  });
}
e.g = function() {
  cf.c.g.call(this);
  this.Y.C();
  wa(this.Hc);
  wa(this.vc);
  delete this.e;
  delete this.Y;
  delete this.Ae;
};
function ef(a, b) {
  U.call(this, b);
  this.th = !!a;
  this.Sb = null;
}
w(ef, U);
e = ef.prototype;
e.Pd = null;
e.P = !1;
e.aa = null;
e.Q = null;
e.ua = null;
e.Fd = !1;
e.V = function() {
  return "goog-modalpopup";
};
e.Yc = function() {
  return this.aa;
};
e.b = function() {
  ef.c.b.call(this);
  var a = this.a(), b = Aa(this.V()).split(" ");
  Ge(a, b);
  zd(a, !0);
  S(a, !1);
  this.th && !this.Q && (this.Q = this.j().b("iframe", {frameborder:0, style:"border:0;vertical-align:bottom;", src:'javascript:""'}), this.Q.className = this.V() + "-bg", S(this.Q, !1), be(this.Q, 0));
  this.aa || (this.aa = this.j().b("div", this.V() + "-bg"), S(this.aa, !1));
  this.ua || (this.ua = this.j().createElement("span"), S(this.ua, !1), zd(this.ua, !0), this.ua.style.position = "absolute");
};
e.rf = function() {
  this.Fd = !1;
};
e.L = function() {
  if (this.Q) {
    var a = this.a();
    a.parentNode && a.parentNode.insertBefore(this.Q, a);
  }
  a = this.a();
  a.parentNode && a.parentNode.insertBefore(this.aa, a);
  ef.c.L.call(this);
  a = this.a();
  a.parentNode && a.parentNode.insertBefore(this.ua, a.nextSibling);
  this.Pd = new bf(Ed(this.j()));
  this.W().h(this.Pd, "focusin", this.Tg);
  ff(this, !1);
};
e.ca = function() {
  this.n() && this.k(!1);
  wa(this.Pd);
  ef.c.ca.call(this);
  vd(this.Q);
  vd(this.aa);
  vd(this.ua);
};
e.k = function(a) {
  a != this.P && (this.Wb && this.Wb.stop(), this.gc && this.gc.stop(), this.Vb && this.Vb.stop(), this.fc && this.fc.stop(), this.t && ff(this, a), a ? this.te() : this.Nb());
};
function ff(a, b) {
  if (b) {
    a.Lb || (a.Lb = []);
    for (var c = a.j(), c = c.Sd(c.o.body), d = 0;d < c.length;d++) {
      var f = c[d], g;
      if (g = f != a.e) {
        g = f.getAttribute("aria-hidden"), g = !(null == g || void 0 == g ? 0 : String(g));
      }
      g && (Ce(f, "hidden", !0), a.Lb.push(f));
    }
  } else {
    if (a.Lb) {
      for (d = 0;d < a.Lb.length;d++) {
        a.Lb[d].removeAttribute("aria-hidden");
      }
      a.Lb = null;
    }
  }
}
e.te = function() {
  if (this.dispatchEvent("beforeshow")) {
    try {
      this.Sb = Ed(this.j()).activeElement;
    } catch (a) {
    }
    this.me();
    this.Z();
    this.W().h(Gd(this.j()), "resize", this.me);
    gf(this, !0);
    this.focus();
    this.P = !0;
    this.Wb && this.gc ? (Wc(this.Wb, "end", this.nd, !1, this), this.gc.play(), this.Wb.play()) : this.nd();
  }
};
e.Nb = function() {
  if (this.dispatchEvent("beforehide")) {
    this.W().$(Gd(this.j()), "resize", this.me);
    this.P = !1;
    this.Vb && this.fc ? (Wc(this.Vb, "end", this.md, !1, this), this.fc.play(), this.Vb.play()) : this.md();
    a: {
      try {
        var a = this.j(), b = a.o.body, c = a.o.activeElement || b;
        if (!this.Sb || this.Sb == b) {
          this.Sb = null;
          break a;
        }
        (c == b || a.contains(this.a(), c)) && this.Sb.focus();
      } catch (d) {
      }
      this.Sb = null;
    }
  }
};
function gf(a, b) {
  a.Q && S(a.Q, b);
  a.aa && S(a.aa, b);
  S(a.a(), b);
  S(a.ua, b);
}
e.nd = function() {
  this.dispatchEvent("show");
};
e.md = function() {
  gf(this, !1);
  this.dispatchEvent("hide");
};
e.n = function() {
  return this.P;
};
e.focus = function() {
  this.Le();
};
e.me = function() {
  this.Q && S(this.Q, !1);
  this.aa && S(this.aa, !1);
  var a = Ed(this.j()), b = md(od(a) || window || window), c = Math.max(b.width, Math.max(a.body.scrollWidth, a.documentElement.scrollWidth)), a = Math.max(b.height, Math.max(a.body.scrollHeight, a.documentElement.scrollHeight));
  this.Q && (S(this.Q, !0), Yd(this.Q, c, a));
  this.aa && (S(this.aa, !0), Yd(this.aa, c, a));
};
e.Z = function() {
  var a = Ed(this.j()), b = od(a) || window;
  if ("fixed" == Pd(this.a())) {
    var c = a = 0
  } else {
    c = Hd(this.j()), a = c.x, c = c.y;
  }
  var d = Zd(this.a()), b = md(b || window), a = Math.max(a + b.width / 2 - d.width / 2, 0), c = Math.max(c + b.height / 2 - d.height / 2, 0);
  Qd(this.a(), a, c);
  Qd(this.ua, a, c);
};
e.Tg = function(a) {
  this.Fd ? this.rf() : a.target == this.ua && af(this.Le, 0, this);
};
e.Le = function() {
  try {
    A && Ed(this.j()).body.focus(), this.a().focus();
  } catch (a) {
  }
};
e.g = function() {
  wa(this.Wb);
  this.Wb = null;
  wa(this.Vb);
  this.Vb = null;
  wa(this.gc);
  this.gc = null;
  wa(this.fc);
  this.fc = null;
  ef.c.g.call(this);
};
function X(a, b, c) {
  ef.call(this, b, c);
  this.Ha = a || "modal-dialog";
  this.wa = Y(Y(new hf, jf, !0), kf, !1, !0);
}
w(X, ef);
e = X.prototype;
e.bg = !0;
e.Qe = !0;
e.ff = !0;
e.$f = !0;
e.Ed = .5;
e.Gf = "";
e.ya = null;
e.Ra = null;
e.Zf = !1;
e.cc = null;
e.yb = null;
e.Ff = null;
e.Na = null;
e.hc = null;
e.va = null;
e.qd = "dialog";
e.V = function() {
  return this.Ha;
};
function lf(a, b) {
  a.Gf = b;
  a.yb && wd(a.yb, b);
}
e.vb = function(a) {
  this.ya = a = Me(a, null);
  this.hc && (this.hc.innerHTML = Le(a));
};
e.nc = function() {
  return null != this.ya ? Le(this.ya) : "";
};
e.ha = function() {
  this.a() || this.Da();
  return this.hc;
};
e.Yc = function() {
  this.a() || this.Da();
  return X.c.Yc.call(this);
};
function mf(a, b) {
  var c = Aa(a.Ha + "-title-draggable").split(" ");
  a.a() && (b ? Ge(a.cc, c) : Ie(a.cc, c));
  b && !a.Ra ? (a.Ra = new Se(a.a(), a.cc), Ge(a.cc, c), K(a.Ra, "start", a.kh, !1, a)) : !b && a.Ra && (a.Ra.C(), a.Ra = null);
}
e.b = function() {
  X.c.b.call(this);
  var a = this.a(), b = this.j();
  this.cc = b.b("div", this.Ha + "-title", this.yb = b.b("span", {className:this.Ha + "-title-text", id:this.J()}, this.Gf), this.Na = b.b("span", this.Ha + "-title-close"));
  td(a, this.cc, this.hc = b.b("div", this.Ha + "-content"), this.va = b.b("div", this.Ha + "-buttons"));
  Be(this.yb, "heading");
  Be(this.Na, "button");
  zd(this.Na, !0);
  Ce(this.Na, "label", nf);
  this.Ff = this.yb.id;
  Be(a, this.qd);
  Ce(a, "labelledby", this.Ff || "");
  this.ya && (this.hc.innerHTML = Le(this.ya));
  S(this.Na, this.Qe);
  this.wa && (a = this.wa, a.e = this.va, a.Da());
  S(this.va, !!this.wa);
  this.Ed = this.Ed;
  this.a() && (a = this.Yc()) && be(a, this.Ed);
};
e.L = function() {
  X.c.L.call(this);
  this.W().h(this.a(), "keydown", this.jf).h(this.a(), "keypress", this.jf);
  this.W().h(this.va, "click", this.Ng);
  mf(this, this.$f);
  this.W().h(this.Na, "click", this.Yg);
  var a = this.a();
  Be(a, this.qd);
  "" !== this.yb.id && Ce(a, "labelledby", this.yb.id);
  if (!this.ff) {
    this.ff = !1;
    if (this.t) {
      var a = this.j(), b = this.Yc();
      a.removeNode(this.Q);
      a.removeNode(b);
    }
    this.n() && ff(this, !1);
  }
};
e.ca = function() {
  this.n() && this.k(!1);
  mf(this, !1);
  X.c.ca.call(this);
};
e.k = function(a) {
  a != this.n() && (this.t || this.Da(), X.c.k.call(this, a));
};
e.nd = function() {
  X.c.nd.call(this);
  this.dispatchEvent(of);
};
e.md = function() {
  X.c.md.call(this);
  this.dispatchEvent(pf);
  this.Zf && this.C();
};
e.kh = function() {
  var a = Ed(this.j()), b = md(od(a) || window || window), c = Math.max(a.body.scrollWidth, b.width), a = Math.max(a.body.scrollHeight, b.height), d = Zd(this.a());
  "fixed" == Pd(this.a()) ? (b = new Kd(0, 0, Math.max(0, b.width - d.width), Math.max(0, b.height - d.height)), this.Ra.jd = b || new Kd(NaN, NaN, NaN, NaN)) : this.Ra.jd = new Kd(0, 0, c - d.width, a - d.height) || new Kd(NaN, NaN, NaN, NaN);
};
e.Yg = function() {
  qf(this);
};
function qf(a) {
  if (a.Qe) {
    var b = a.wa, c = b && b.Id;
    c ? (b = b.get(c), a.dispatchEvent(new rf(c, b)) && a.k(!1)) : a.k(!1);
  }
}
e.g = function() {
  this.va = this.Na = null;
  X.c.g.call(this);
};
e.Ng = function(a) {
  a: {
    for (a = a.target;null != a && a != this.va;) {
      if ("BUTTON" == a.tagName) {
        break a;
      }
      a = a.parentNode;
    }
    a = null;
  }
  if (a && !a.disabled) {
    a = a.name;
    var b = this.wa.get(a);
    this.dispatchEvent(new rf(a, b)) && this.k(!1);
  }
};
e.jf = function(a) {
  var b = !1, c = !1, d = this.wa, f = a.target;
  if ("keydown" == a.type) {
    if (this.bg && 27 == a.keyCode) {
      var g = d && d.Id, f = "SELECT" == f.tagName && !f.disabled;
      g && !f ? (c = !0, b = d.get(g), b = this.dispatchEvent(new rf(g, b))) : f || (b = !0);
    } else {
      if (9 == a.keyCode && a.shiftKey && f == this.a()) {
        this.Fd = !0;
        try {
          this.ua.focus();
        } catch (h) {
        }
        af(this.rf, 0, this);
      }
    }
  } else {
    if (13 == a.keyCode) {
      if ("BUTTON" == f.tagName && !f.disabled) {
        g = f.name;
      } else {
        if (f == this.Na) {
          qf(this);
        } else {
          if (d) {
            var k = d.Kd, l;
            if (l = k) {
              a: {
                l = d.e.getElementsByTagName("BUTTON");
                for (var n = 0, q;q = l[n];n++) {
                  if (q.name == k || q.id == k) {
                    l = q;
                    break a;
                  }
                }
                l = null;
              }
            }
            f = ("TEXTAREA" == f.tagName || "SELECT" == f.tagName || "A" == f.tagName) && !f.disabled;
            !l || l.disabled || f || (g = k);
          }
        }
      }
      g && d && (c = !0, b = this.dispatchEvent(new rf(g, String(d.get(g)))));
    } else {
      f == this.Na && 32 == a.keyCode && qf(this);
    }
  }
  if (b || c) {
    a.stopPropagation(), a.preventDefault();
  }
  b && this.k(!1);
};
function rf(a, b) {
  this.type = sf;
  this.key = a;
  this.caption = b;
}
w(rf, I);
var sf = "dialogselect", pf = "afterhide", of = "aftershow";
function hf(a) {
  this.ga = a || M();
  kb.call(this);
}
w(hf, kb);
e = hf.prototype;
e.Ha = "goog-buttonset";
e.Kd = null;
e.e = null;
e.Id = null;
e.set = function(a, b, c, d) {
  kb.prototype.set.call(this, a, b);
  c && (this.Kd = a);
  d && (this.Id = a);
  return this;
};
function Y(a, b, c, d) {
  return a.set(b.key, b.caption, c, d);
}
e.Da = function() {
  if (this.e) {
    this.e.innerHTML = Le(Ne);
    var a = M(this.e);
    this.forEach(function(b, c) {
      var d = a.b("button", {name:c}, b);
      c == this.Kd && (d.className = this.Ha + "-default");
      this.e.appendChild(d);
    }, this);
  }
};
e.a = function() {
  return this.e;
};
e.j = function() {
  return this.ga;
};
var nf = "Close", jf = {key:"ok", caption:"OK"}, kf = {key:"cancel", caption:"Cancel"}, tf = {key:"yes", caption:"Yes"}, uf = {key:"no", caption:"No"}, vf = {key:"save", caption:"Save"}, wf = {key:"continue", caption:"Continue"};
"undefined" != typeof document && (Y(new hf, jf, !0, !0), Y(Y(new hf, jf, !0), kf, !1, !0), Y(Y(new hf, tf, !0), uf, !1, !0), Y(Y(Y(new hf, tf), uf, !0), kf, !1, !0), Y(Y(Y(new hf, wf), vf), kf, !0, !0));
function xf() {
  X.call(this, void 0, !0);
  this.wa = Y(new hf, jf, !0, !0);
  if (this.va) {
    if (this.wa) {
      var a = this.wa;
      a.e = this.va;
      a.Da();
    } else {
      this.va.innerHTML = Le(Ne);
    }
    S(this.va, !!this.wa);
  }
  this.N(yf);
}
w(xf, X);
var yf = 0;
xf.prototype.F = yf;
xf.prototype.g = function() {
  delete this.F;
  xf.c.g.call(this);
};
xf.prototype.N = function(a) {
  this.F = a;
  switch(a) {
    case 1:
      lf(this, "Screenshot");
      break;
    default:
      lf(this, "Taking Screenshot..."), this.vb("");
  }
};
function zf() {
  U.call(this);
}
w(zf, U);
zf.prototype.b = function() {
  this.e = this.j().b("DIV", "server-info");
  Af(this);
};
function Af(a, b, c, d) {
  var f = [];
  b && f.push(b);
  c && f.push("v" + c);
  d && f.push("r" + d);
  wd(a.a(), f.length ? f.join("\u00a0\u00a0|\u00a0\u00a0") : "Server info unavailable");
}
;function Bf(a, b) {
  T.call(this);
  a && this.ec(a, b);
}
w(Bf, T);
e = Bf.prototype;
e.e = null;
e.gd = null;
e.$d = null;
e.hd = null;
e.ea = -1;
e.Wa = -1;
e.Bd = !1;
var Cf = {3:13, 12:144, 63232:38, 63233:40, 63234:37, 63235:39, 63236:112, 63237:113, 63238:114, 63239:115, 63240:116, 63241:117, 63242:118, 63243:119, 63244:120, 63245:121, 63246:122, 63247:123, 63248:44, 63272:46, 63273:36, 63275:35, 63276:33, 63277:34, 63289:144, 63302:45}, Df = {Up:38, Down:40, Left:37, Right:39, Enter:13, F1:112, F2:113, F3:114, F4:115, F5:116, F6:117, F7:118, F8:119, F9:120, F10:121, F11:122, F12:123, "U+007F":46, Home:36, End:35, PageUp:33, PageDown:34, Insert:45}, Ef = A || 
D && E("525"), Ff = rb && B;
e = Bf.prototype;
e.ng = function(a) {
  D && (17 == this.ea && !a.ctrlKey || 18 == this.ea && !a.altKey || rb && 91 == this.ea && !a.metaKey) && (this.Wa = this.ea = -1);
  -1 == this.ea && (a.ctrlKey && 17 != a.keyCode ? this.ea = 17 : a.altKey && 18 != a.keyCode ? this.ea = 18 : a.metaKey && 91 != a.keyCode && (this.ea = 91));
  Ef && !Oe(a.keyCode, this.ea, a.shiftKey, a.ctrlKey, a.altKey) ? this.handleEvent(a) : (this.Wa = Qe(a.keyCode), Ff && (this.Bd = a.altKey));
};
e.og = function(a) {
  this.Wa = this.ea = -1;
  this.Bd = a.altKey;
};
e.handleEvent = function(a) {
  var b = a.na, c, d, f = b.altKey;
  A && "keypress" == a.type ? (c = this.Wa, d = 13 != c && 27 != c ? b.keyCode : 0) : D && "keypress" == a.type ? (c = this.Wa, d = 0 <= b.charCode && 63232 > b.charCode && Pe(c) ? b.charCode : 0) : tb ? (c = this.Wa, d = Pe(c) ? b.keyCode : 0) : (c = b.keyCode || this.Wa, d = b.charCode || 0, Ff && (f = this.Bd), rb && 63 == d && 224 == c && (c = 191));
  var g = c = Qe(c), h = b.keyIdentifier;
  c ? 63232 <= c && c in Cf ? g = Cf[c] : 25 == c && a.shiftKey && (g = 9) : h && h in Df && (g = Df[h]);
  a = g == this.ea;
  this.ea = g;
  b = new Gf(g, d, a, b);
  b.altKey = f;
  this.dispatchEvent(b);
};
e.a = function() {
  return this.e;
};
e.ec = function(a, b) {
  this.hd && this.detach();
  this.e = a;
  this.gd = K(this.e, "keypress", this, b);
  this.$d = K(this.e, "keydown", this.ng, b, this);
  this.hd = K(this.e, "keyup", this.og, b, this);
};
e.detach = function() {
  this.gd && (Yc(this.gd), Yc(this.$d), Yc(this.hd), this.hd = this.$d = this.gd = null);
  this.e = null;
  this.Wa = this.ea = -1;
};
e.g = function() {
  Bf.c.g.call(this);
  this.detach();
};
function Gf(a, b, c, d) {
  J.call(this, d);
  this.type = "key";
  this.keyCode = a;
  this.charCode = b;
  this.repeat = c;
}
w(Gf, J);
function Hf() {
}
var If;
ba(Hf);
var Jf = {button:"pressed", checkbox:"checked", menuitem:"selected", menuitemcheckbox:"checked", menuitemradio:"checked", radio:"checked", tab:"selected", treeitem:"selected"};
e = Hf.prototype;
e.Eb = function() {
};
e.b = function(a) {
  var b = a.j().b("div", this.Fb(a).join(" "), a.nc());
  a.n() || Ce(b, "hidden", !a.n());
  a.isEnabled() || this.Oa(b, 1, !a.isEnabled());
  a.O & 8 && this.Oa(b, 8, !!(a.F & 8));
  a.O & 16 && this.Oa(b, 16, !!(a.F & 16));
  a.O & 64 && this.Oa(b, 64, !!(a.F & 64));
  return b;
};
e.ha = function(a) {
  return a;
};
e.kc = function(a, b, c) {
  if (a = a.a ? a.a() : a) {
    var d = [b];
    A && !E("7") && (d = Kf(De(a), b), d.push(b));
    (c ? Ge : Ie)(a, d);
  }
};
e.cd = function(a) {
  ve(a) && this.ac(a.a(), !0);
  a.isEnabled() && this.$b(a, a.n());
};
e.wd = function(a, b) {
  de(a, !b, !A && !tb);
};
e.ac = function(a, b) {
  this.kc(a, this.V() + "-rtl", b);
};
e.Ka = function(a) {
  var b;
  return a.O & 32 && (b = a.M()) ? Ad(b) && Bd(b) : !1;
};
e.$b = function(a, b) {
  var c;
  if (a.O & 32 && (c = a.M())) {
    if (!b && a.F & 32) {
      try {
        c.blur();
      } catch (d) {
      }
      a.F & 32 && a.qc(null);
    }
    (Ad(c) && Bd(c)) != b && zd(c, b);
  }
};
e.k = function(a, b) {
  S(a, b);
  a && Ce(a, "hidden", !b);
};
e.N = function(a, b, c) {
  var d = a.a();
  if (d) {
    var f = Lf(this, b);
    f && this.kc(a, f, c);
    this.Oa(d, b, c);
  }
};
e.Oa = function(a, b, c) {
  If || (If = {1:"disabled", 8:"selected", 16:"checked", 64:"expanded"});
  b = If[b];
  var d = a.getAttribute("role") || null;
  d && (d = Jf[d] || b, b = "checked" == b || "selected" == b ? d : b);
  b && Ce(a, b, c);
};
e.vb = function(a, b) {
  var c = this.ha(a);
  if (c && (ud(c), b)) {
    if (t(b)) {
      wd(c, b);
    } else {
      var d = function(a) {
        if (a) {
          var b = N(c);
          c.appendChild(t(a) ? b.createTextNode(a) : a);
        }
      };
      s(b) ? z(b, d) : !da(b) || "nodeType" in b ? d(b) : z(Za(b), d);
    }
  }
};
e.M = function(a) {
  return a.a();
};
e.V = function() {
  return "goog-control";
};
e.Fb = function(a) {
  var b = this.V(), c = [b], d = this.V();
  d != b && c.push(d);
  b = a.pc();
  for (d = [];b;) {
    var f = b & -b;
    d.push(Lf(this, f));
    b &= ~f;
  }
  c.push.apply(c, d);
  (a = a.za) && c.push.apply(c, a);
  A && !E("7") && c.push.apply(c, Kf(c));
  return c;
};
function Kf(a, b) {
  var c = [];
  b && (a = a.concat([b]));
  z([], function(d) {
    !Va(d, ma(Wa, a)) || b && !Wa(d, b) || c.push(d.join("_"));
  });
  return c;
}
function Lf(a, b) {
  if (!a.De) {
    var c = a.V();
    c.replace(/\xa0|\s/g, " ");
    a.De = {1:c + "-disabled", 2:c + "-hover", 4:c + "-active", 8:c + "-selected", 16:c + "-checked", 32:c + "-focused", 64:c + "-open"};
  }
  return a.De[b];
}
;function Mf(a, b) {
  if (!a) {
    throw Error("Invalid class name " + a);
  }
  if (!u(b)) {
    throw Error("Invalid decorator function " + b);
  }
}
var Nf = {};
function Z(a, b, c) {
  U.call(this, c);
  if (!b) {
    b = this.constructor;
    for (var d;b;) {
      d = ha(b);
      if (d = Nf[d]) {
        break;
      }
      b = b.c ? b.c.constructor : null;
    }
    b = d ? u(d.mb) ? d.mb() : new d : null;
  }
  this.l = b;
  this.ya = p(a) ? a : null;
}
w(Z, U);
e = Z.prototype;
e.ya = null;
e.F = 0;
e.O = 39;
e.Dd = 255;
e.wb = 0;
e.P = !0;
e.za = null;
e.Vd = !0;
e.Ad = !1;
e.qd = null;
function Of(a, b) {
  a.t && b != a.Vd && Pf(a, b);
  a.Vd = b;
}
e.M = function() {
  return this.l.M(this);
};
e.Zc = function() {
  return this.ja || (this.ja = new Bf);
};
e.kc = function(a, b) {
  b ? a && (this.za ? Wa(this.za, a) || this.za.push(a) : this.za = [a], this.l.kc(this, a, !0)) : a && this.za && Xa(this.za, a) && (0 == this.za.length && (this.za = null), this.l.kc(this, a, !1));
};
e.b = function() {
  var a = this.l.b(this);
  this.e = a;
  var b = this.qd || this.l.Eb();
  if (b) {
    var c = a.getAttribute("role") || null;
    b != c && Be(a, b);
  }
  this.Ad || this.l.wd(a, !1);
  this.n() || this.l.k(a, !1);
};
e.ha = function() {
  return this.l.ha(this.a());
};
e.L = function() {
  Z.c.L.call(this);
  this.l.cd(this);
  if (this.O & -2 && (this.Vd && Pf(this, !0), this.O & 32)) {
    var a = this.M();
    if (a) {
      var b = this.Zc();
      b.ec(a);
      this.W().h(b, "key", this.Va).h(a, "focus", this.Ua).h(a, "blur", this.qc);
    }
  }
};
function Pf(a, b) {
  var c = a.W(), d = a.a();
  b ? (c.h(d, "mouseover", a.Jb).h(d, "mousedown", a.tc).h(d, "mouseup", a.Xd).h(d, "mouseout", a.Wd), a.rc != r && c.h(d, "contextmenu", a.rc), A && c.h(d, "dblclick", a.Ne)) : (c.$(d, "mouseover", a.Jb).$(d, "mousedown", a.tc).$(d, "mouseup", a.Xd).$(d, "mouseout", a.Wd), a.rc != r && c.$(d, "contextmenu", a.rc), A && c.$(d, "dblclick", a.Ne));
}
e.ca = function() {
  Z.c.ca.call(this);
  this.ja && this.ja.detach();
  this.n() && this.isEnabled() && this.l.$b(this, !1);
};
e.g = function() {
  Z.c.g.call(this);
  this.ja && (this.ja.C(), delete this.ja);
  delete this.l;
  this.za = this.ya = null;
};
e.nc = function() {
  return this.ya;
};
e.vb = function(a) {
  this.l.vb(this.a(), a);
  this.ya = a;
};
function Qf(a) {
  a = a.nc();
  if (!a) {
    return "";
  }
  if (!t(a)) {
    if (s(a)) {
      a = Ta(a, Cd).join("");
    } else {
      if (gd && "innerText" in a) {
        a = a.innerText.replace(/(\r\n|\r|\n)/g, "\n");
      } else {
        var b = [];
        Dd(a, b, !0);
        a = b.join("");
      }
      a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
      a = a.replace(/\u200B/g, "");
      gd || (a = a.replace(/ +/g, " "));
      " " != a && (a = a.replace(/^\s*/, ""));
    }
  }
  return a.replace(/[\t\r\n ]+/g, " ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g, "");
}
e.ac = function(a) {
  Z.c.ac.call(this, a);
  var b = this.a();
  b && this.l.ac(b, a);
};
e.wd = function(a) {
  this.Ad = a;
  var b = this.a();
  b && this.l.wd(b, a);
};
e.n = function() {
  return this.P;
};
e.k = function(a, b) {
  if (b || this.P != a && this.dispatchEvent(a ? "show" : "hide")) {
    var c = this.a();
    c && this.l.k(c, a);
    this.isEnabled() && this.l.$b(this, a);
    this.P = a;
    return!0;
  }
  return!1;
};
e.isEnabled = function() {
  return!(this.F & 1);
};
e.la = function(a) {
  var b = this.getParent();
  b && "function" == typeof b.isEnabled && !b.isEnabled() || !Rf(this, 1, !a) || (a || (this.setActive(!1), this.ta(!1)), this.n() && this.l.$b(this, a), this.N(1, !a, !0));
};
e.ta = function(a) {
  Rf(this, 2, a) && this.N(2, a);
};
e.setActive = function(a) {
  Rf(this, 4, a) && this.N(4, a);
};
function Sf(a, b) {
  Rf(a, 8, b) && a.N(8, b);
}
function Tf(a, b) {
  Rf(a, 64, b) && a.N(64, b);
}
e.pc = function() {
  return this.F;
};
e.N = function(a, b, c) {
  c || 1 != a ? this.O & a && b != !!(this.F & a) && (this.l.N(this, a, b), this.F = b ? this.F | a : this.F & ~a) : this.la(!b);
};
function Uf(a, b, c) {
  if (a.t && a.F & b && !c) {
    throw Error("Component already rendered");
  }
  !c && a.F & b && a.N(b, !1);
  a.O = c ? a.O | b : a.O & ~b;
}
function $(a, b) {
  return!!(a.Dd & b) && !!(a.O & b);
}
function Rf(a, b, c) {
  return!!(a.O & b) && !!(a.F & b) != c && (!(a.wb & b) || a.dispatchEvent(qe(b, c))) && !a.Db;
}
e.Jb = function(a) {
  (!a.relatedTarget || !P(this.a(), a.relatedTarget)) && this.dispatchEvent("enter") && this.isEnabled() && $(this, 2) && this.ta(!0);
};
e.Wd = function(a) {
  a.relatedTarget && P(this.a(), a.relatedTarget) || !this.dispatchEvent("leave") || ($(this, 4) && this.setActive(!1), $(this, 2) && this.ta(!1));
};
e.rc = r;
e.tc = function(a) {
  this.isEnabled() && ($(this, 2) && this.ta(!0), Ec(a) && ($(this, 4) && this.setActive(!0), this.l.Ka(this) && this.M().focus()));
  !this.Ad && Ec(a) && a.preventDefault();
};
e.Xd = function(a) {
  this.isEnabled() && ($(this, 2) && this.ta(!0), this.F & 4 && this.Cc(a) && $(this, 4) && this.setActive(!1));
};
e.Ne = function(a) {
  this.isEnabled() && this.Cc(a);
};
e.Cc = function(a) {
  if ($(this, 16)) {
    var b = !(this.F & 16);
    Rf(this, 16, b) && this.N(16, b);
  }
  $(this, 8) && Sf(this, !0);
  $(this, 64) && Tf(this, !(this.F & 64));
  b = new I("action", this);
  a && (b.altKey = a.altKey, b.ctrlKey = a.ctrlKey, b.metaKey = a.metaKey, b.shiftKey = a.shiftKey, b.je = a.je);
  return this.dispatchEvent(b);
};
e.Ua = function() {
  $(this, 32) && Rf(this, 32, !0) && this.N(32, !0);
};
e.qc = function() {
  $(this, 4) && this.setActive(!1);
  $(this, 32) && Rf(this, 32, !1) && this.N(32, !1);
};
e.Va = function(a) {
  return this.n() && this.isEnabled() && this.sc(a) ? (a.preventDefault(), a.stopPropagation(), !0) : !1;
};
e.sc = function(a) {
  return 13 == a.keyCode && this.Cc(a);
};
if (!u(Z)) {
  throw Error("Invalid component class " + Z);
}
if (!u(Hf)) {
  throw Error("Invalid renderer class " + Hf);
}
var Vf = ha(Z);
Nf[Vf] = Hf;
Mf("goog-control", function() {
  return new Z(null);
});
function Wf() {
}
w(Wf, Hf);
ba(Wf);
e = Wf.prototype;
e.V = function() {
  return "goog-tab";
};
e.Eb = function() {
  return "tab";
};
e.b = function(a) {
  var b = Wf.c.b.call(this, a);
  (a = a.Gb()) && this.Ma(b, a);
  return b;
};
e.Gb = function(a) {
  return a.title || "";
};
e.Ma = function(a, b) {
  a && (a.title = b || "");
};
function Xf(a, b, c) {
  Z.call(this, a, b || Wf.mb(), c);
  Uf(this, 8, !0);
  this.wb |= 9;
}
w(Xf, Z);
Xf.prototype.Gb = function() {
  return this.Kc;
};
Xf.prototype.Ma = function(a) {
  this.l.Ma(this.a(), a);
  this.wf(a);
};
Xf.prototype.wf = function(a) {
  this.Kc = a;
};
Mf("goog-tab", function() {
  return new Xf(null);
});
function Yf(a) {
  this.ze = a;
}
ba(Yf);
e = Yf.prototype;
e.Eb = function() {
  return this.ze;
};
function Zf(a, b) {
  a && (a.tabIndex = b ? 0 : -1);
}
e.b = function(a) {
  return a.j().b("div", this.Fb(a).join(" "));
};
e.ha = function(a) {
  return a;
};
e.cd = function(a) {
  a = a.a();
  de(a, !0, B);
  A && (a.hideFocus = !0);
  var b = this.Eb();
  b && Be(a, b);
};
e.M = function(a) {
  return a.a();
};
e.V = function() {
  return "goog-container";
};
e.Fb = function(a) {
  var b = this.V(), c = [b, a.Ya == $f ? b + "-horizontal" : b + "-vertical"];
  a.isEnabled() || c.push(b + "-disabled");
  return c;
};
function ag(a, b, c) {
  U.call(this, c);
  this.l = b || Yf.mb();
  this.Ya = a || bg;
}
w(ag, U);
var $f = "horizontal", bg = "vertical";
e = ag.prototype;
e.ae = null;
e.ja = null;
e.l = null;
e.Ya = null;
e.P = !0;
e.ma = !0;
e.Qd = !0;
e.r = -1;
e.K = null;
e.Tb = !1;
e.Of = !1;
e.ah = !0;
e.Ga = null;
e.M = function() {
  return this.ae || this.l.M(this);
};
e.Zc = function() {
  return this.ja || (this.ja = new Bf(this.M()));
};
e.b = function() {
  this.e = this.l.b(this);
};
e.ha = function() {
  return this.l.ha(this.a());
};
e.L = function() {
  ag.c.L.call(this);
  te(this, function(a) {
    a.t && cg(this, a);
  }, this);
  var a = this.a();
  this.l.cd(this);
  this.k(this.P, !0);
  this.W().h(this, "enter", this.jg).h(this, "highlight", this.mg).h(this, "unhighlight", this.vg).h(this, "open", this.qg).h(this, "close", this.hg).h(a, "mousedown", this.tc).h(N(a), "mouseup", this.ig).h(a, ["mousedown", "mouseup", "mouseover", "mouseout", "contextmenu"], this.gg);
  this.Ka() && dg(this, !0);
};
function dg(a, b) {
  var c = a.W(), d = a.M();
  b ? c.h(d, "focus", a.Ua).h(d, "blur", a.qc).h(a.Zc(), "key", a.Va) : c.$(d, "focus", a.Ua).$(d, "blur", a.qc).$(a.Zc(), "key", a.Va);
}
e.ca = function() {
  eg(this, -1);
  this.K && Tf(this.K, !1);
  this.Tb = !1;
  ag.c.ca.call(this);
};
e.g = function() {
  ag.c.g.call(this);
  this.ja && (this.ja.C(), this.ja = null);
  this.l = this.K = this.Ga = this.ae = null;
};
e.jg = function() {
  return!0;
};
e.mg = function(a) {
  var b = we(this, a.target);
  if (-1 < b && b != this.r) {
    var c = W(this, this.r);
    c && c.ta(!1);
    this.r = b;
    c = W(this, this.r);
    this.Tb && c.setActive(!0);
    this.ah && this.K && c != this.K && (c.O & 64 ? Tf(c, !0) : Tf(this.K, !1));
  }
  b = this.a();
  null != a.target.a() && Ce(b, "activedescendant", a.target.a().id);
};
e.vg = function(a) {
  a.target == W(this, this.r) && (this.r = -1);
  this.a().removeAttribute("aria-activedescendant");
};
e.qg = function(a) {
  (a = a.target) && a != this.K && a.getParent() == this && (this.K && Tf(this.K, !1), this.K = a);
};
e.hg = function(a) {
  a.target == this.K && (this.K = null);
};
e.tc = function(a) {
  this.ma && (this.Tb = !0);
  var b = this.M();
  b && Ad(b) && Bd(b) ? b.focus() : a.preventDefault();
};
e.ig = function() {
  this.Tb = !1;
};
e.gg = function(a) {
  var b;
  a: {
    b = a.target;
    if (this.Ga) {
      for (var c = this.a();b && b !== c;) {
        var d = b.id;
        if (d in this.Ga) {
          b = this.Ga[d];
          break a;
        }
        b = b.parentNode;
      }
    }
    b = null;
  }
  if (b) {
    switch(a.type) {
      case "mousedown":
        b.tc(a);
        break;
      case "mouseup":
        b.Xd(a);
        break;
      case "mouseover":
        b.Jb(a);
        break;
      case "mouseout":
        b.Wd(a);
        break;
      case "contextmenu":
        b.rc(a);
    }
  }
};
e.Ua = function() {
};
e.qc = function() {
  eg(this, -1);
  this.Tb = !1;
  this.K && Tf(this.K, !1);
};
e.Va = function(a) {
  return this.isEnabled() && this.n() && (0 != ue(this) || this.ae) && this.sc(a) ? (a.preventDefault(), a.stopPropagation(), !0) : !1;
};
e.sc = function(a) {
  var b = W(this, this.r);
  if (b && "function" == typeof b.Va && b.Va(a) || this.K && this.K != b && "function" == typeof this.K.Va && this.K.Va(a)) {
    return!0;
  }
  if (a.shiftKey || a.ctrlKey || a.metaKey || a.altKey) {
    return!1;
  }
  switch(a.keyCode) {
    case 27:
      if (this.Ka()) {
        this.M().blur();
      } else {
        return!1;
      }
      break;
    case 36:
      fg(this);
      break;
    case 35:
      gg(this);
      break;
    case 38:
      if (this.Ya == bg) {
        hg(this);
      } else {
        return!1;
      }
      break;
    case 37:
      if (this.Ya == $f) {
        ve(this) ? ig(this) : hg(this);
      } else {
        return!1;
      }
      break;
    case 40:
      if (this.Ya == bg) {
        ig(this);
      } else {
        return!1;
      }
      break;
    case 39:
      if (this.Ya == $f) {
        ve(this) ? hg(this) : ig(this);
      } else {
        return!1;
      }
      break;
    default:
      return!1;
  }
  return!0;
};
function cg(a, b) {
  var c = b.a(), c = c.id || (c.id = b.J());
  a.Ga || (a.Ga = {});
  a.Ga[c] = b;
}
e.U = function(a, b) {
  ag.c.U.call(this, a, b);
};
e.Pc = function(a, b, c) {
  a.wb |= 2;
  a.wb |= 64;
  !this.Ka() && this.Of || Uf(a, 32, !1);
  Of(a, !1);
  var d = a.getParent() == this ? we(this, a) : -1;
  ag.c.Pc.call(this, a, b, c);
  a.t && this.t && cg(this, a);
  a = d;
  -1 == a && (a = ue(this));
  a == this.r ? this.r = Math.min(ue(this) - 1, b) : a > this.r && b <= this.r ? this.r++ : a < this.r && b > this.r && this.r--;
};
e.removeChild = function(a, b) {
  if (a = t(a) ? re(this, a) : a) {
    var c = we(this, a);
    -1 != c && (c == this.r ? (a.ta(!1), this.r = -1) : c < this.r && this.r--);
    var d = a.a();
    d && d.id && this.Ga && (c = this.Ga, d = d.id, d in c && delete c[d]);
  }
  a = ag.c.removeChild.call(this, a, b);
  Of(a, !0);
  return a;
};
e.n = function() {
  return this.P;
};
e.k = function(a, b) {
  if (b || this.P != a && this.dispatchEvent(a ? "show" : "hide")) {
    this.P = a;
    var c = this.a();
    c && (S(c, a), this.Ka() && Zf(this.M(), this.ma && this.P), b || this.dispatchEvent(this.P ? "aftershow" : "afterhide"));
    return!0;
  }
  return!1;
};
e.isEnabled = function() {
  return this.ma;
};
e.la = function(a) {
  this.ma != a && this.dispatchEvent(a ? "enable" : "disable") && (a ? (this.ma = !0, te(this, function(a) {
    a.Jf ? delete a.Jf : a.la(!0);
  })) : (te(this, function(a) {
    a.isEnabled() ? a.la(!1) : a.Jf = !0;
  }), this.Tb = this.ma = !1), this.Ka() && Zf(this.M(), a && this.P));
};
e.Ka = function() {
  return this.Qd;
};
e.$b = function(a) {
  a != this.Qd && this.t && dg(this, a);
  this.Qd = a;
  this.ma && this.P && Zf(this.M(), a);
};
function eg(a, b) {
  var c = W(a, b);
  c ? c.ta(!0) : -1 < a.r && W(a, a.r).ta(!1);
}
e.ta = function(a) {
  eg(this, we(this, a));
};
function fg(a) {
  jg(a, function(a, c) {
    return(a + 1) % c;
  }, ue(a) - 1);
}
function gg(a) {
  jg(a, function(a, c) {
    a--;
    return 0 > a ? c - 1 : a;
  }, 0);
}
function ig(a) {
  jg(a, function(a, c) {
    return(a + 1) % c;
  }, a.r);
}
function hg(a) {
  jg(a, function(a, c) {
    a--;
    return 0 > a ? c - 1 : a;
  }, a.r);
}
function jg(a, b, c) {
  c = 0 > c ? we(a, a.K) : c;
  var d = ue(a);
  c = b.call(a, c, d);
  for (var f = 0;f <= d;) {
    var g = W(a, c);
    if (g && g.n() && g.isEnabled() && g.O & 2) {
      a.qe(c);
      break;
    }
    f++;
    c = b.call(a, c, d);
  }
}
e.qe = function(a) {
  eg(this, a);
};
function kg() {
  this.ze = "tablist";
}
w(kg, Yf);
ba(kg);
kg.prototype.V = function() {
  return "goog-tab-bar";
};
kg.prototype.Fb = function(a) {
  var b = kg.c.Fb.call(this, a);
  if (!this.Ce) {
    var c = this.V();
    this.Ce = gb(lg, c + "-top", mg, c + "-bottom", ng, c + "-start", og, c + "-end");
  }
  b.push(this.Ce[a.Hg]);
  return b;
};
function pg(a, b, c) {
  a = a || lg;
  if (this.a()) {
    throw Error("Component already rendered");
  }
  this.Ya = a == ng || a == og ? bg : $f;
  this.Hg = a;
  ag.call(this, this.Ya, b || kg.mb(), c);
  qg(this);
}
w(pg, ag);
var lg = "top", mg = "bottom", ng = "start", og = "end";
e = pg.prototype;
e.Sf = !0;
e.X = null;
e.L = function() {
  pg.c.L.call(this);
  qg(this);
};
e.g = function() {
  pg.c.g.call(this);
  this.X = null;
};
e.removeChild = function(a, b) {
  rg(this, a);
  return pg.c.removeChild.call(this, a, b);
};
e.qe = function(a) {
  pg.c.qe.call(this, a);
  this.Sf && sg(this, W(this, a));
};
function sg(a, b) {
  b ? Sf(b, !0) : a.X && Sf(a.X, !1);
}
function rg(a, b) {
  if (b && b == a.X) {
    for (var c = we(a, b), d = c - 1;b = W(a, d);d--) {
      if (b.n() && b.isEnabled()) {
        sg(a, b);
        return;
      }
    }
    for (c += 1;b = W(a, c);c++) {
      if (b.n() && b.isEnabled()) {
        sg(a, b);
        return;
      }
    }
    sg(a, null);
  }
}
e.tg = function(a) {
  this.X && this.X != a.target && Sf(this.X, !1);
  this.X = a.target;
};
e.ug = function(a) {
  a.target == this.X && (this.X = null);
};
e.rg = function(a) {
  rg(this, a.target);
};
e.sg = function(a) {
  rg(this, a.target);
};
e.Ua = function() {
  W(this, this.r) || this.ta(this.X || W(this, 0));
};
function qg(a) {
  a.W().h(a, "select", a.tg).h(a, "unselect", a.ug).h(a, "disable", a.rg).h(a, "hide", a.sg);
}
Mf("goog-tab-bar", function() {
  return new pg;
});
function tg() {
  U.call(this);
}
w(tg, U);
tg.prototype.hb = null;
tg.prototype.g = function() {
  delete this.hb;
  tg.c.g.call(this);
};
tg.prototype.b = function() {
  this.e = this.j().b("DIV", "control-block");
  this.hb && (z(this.hb, this.addElement, this), this.hb = null);
};
tg.prototype.addElement = function(a) {
  var b = this.a();
  if (b) {
    if (b.childNodes.length) {
      var c = this.j().createTextNode("\u00a0\u00a0|\u00a0\u00a0");
      b.appendChild(c);
    }
    b.appendChild(a);
  } else {
    this.hb || (this.hb = []), this.hb.push(a);
  }
};
function ug(a) {
  X.call(this, void 0, !0);
  lf(this, a);
  K(this, sf, this.Zg, !1, this);
}
w(ug, X);
ug.prototype.b = function() {
  ug.c.b.call(this);
  var a = this.ha(), b = this.Ge();
  a.appendChild(b);
};
ug.prototype.k = function(a) {
  ug.c.k.call(this, a);
  a && this.dispatchEvent("show");
};
ug.prototype.Zg = function(a) {
  "ok" == a.key && this.Re() && this.dispatchEvent("action");
};
function vg(a) {
  ug.call(this, "Create a New Session");
  this.Hd = Ta(a, function(a) {
    return t(a) ? {browserName:a} : a;
  });
  K(this, "show", this.Xa, !1, this);
}
w(vg, ug);
e = vg.prototype;
e.bb = null;
e.g = function() {
  delete this.Hd;
  delete this.bb;
  vg.c.g.call(this);
};
e.Ge = function() {
  function a(a) {
    var d = a.browserName;
    (a = a.version) && (d += " " + a);
    return b.b("OPTION", null, d);
  }
  var b = this.j();
  this.bb = b.b("SELECT", null, a(""));
  z(this.Hd, function(b) {
    b = a(b);
    this.bb.appendChild(b);
  }, this);
  return b.b("LABEL", null, "Browser:\u00a0", this.bb);
};
e.Ud = function() {
  return this.Hd[this.bb.selectedIndex - 1];
};
e.Re = function() {
  return!!this.bb.selectedIndex;
};
e.Xa = function() {
  this.bb.selectedIndex = 0;
};
function wg(a) {
  U.call(this);
  this.Ze = a;
}
w(wg, U);
wg.prototype.g = function() {
  delete this.Ze;
  wg.c.g.call(this);
};
wg.prototype.b = function() {
  var a = this.j();
  this.e = a.b("FIELDSET", null, a.b("LEGEND", null, this.Ze), this.He());
};
wg.prototype.He = function() {
  return null;
};
function xg() {
}
w(xg, Hf);
ba(xg);
e = xg.prototype;
e.Eb = function() {
  return "button";
};
e.Oa = function(a, b, c) {
  switch(b) {
    case 8:
    ;
    case 16:
      Ce(a, "pressed", c);
      break;
    default:
    ;
    case 64:
    ;
    case 1:
      xg.c.Oa.call(this, a, b, c);
  }
};
e.b = function(a) {
  var b = xg.c.b.call(this, a);
  this.Ma(b, a.Gb());
  var c = a.Hb();
  c && this.Gc(b, c);
  a.O & 16 && this.Oa(b, 16, !!(a.F & 16));
  return b;
};
e.Hb = r;
e.Gc = r;
e.Gb = function(a) {
  return a.title;
};
e.Ma = function(a, b) {
  a && (b ? a.title = b : a.removeAttribute("title"));
};
e.V = function() {
  return "goog-button";
};
function yg() {
}
w(yg, xg);
ba(yg);
e = yg.prototype;
e.Eb = function() {
};
e.b = function(a) {
  Of(a, !1);
  a.Dd &= -256;
  Uf(a, 32, !1);
  return a.j().b("button", {"class":this.Fb(a).join(" "), disabled:!a.isEnabled(), title:a.Gb() || "", value:a.Hb() || ""}, Qf(a) || "");
};
e.cd = function(a) {
  a.W().h(a.a(), "click", a.Cc);
};
e.wd = r;
e.ac = r;
e.Ka = function(a) {
  return a.isEnabled();
};
e.$b = r;
e.N = function(a, b, c) {
  yg.c.N.call(this, a, b, c);
  (a = a.a()) && 1 == b && (a.disabled = c);
};
e.Hb = function(a) {
  return a.value;
};
e.Gc = function(a, b) {
  a && (a.value = b);
};
e.Oa = r;
function zg(a, b, c) {
  Z.call(this, a, b || yg.mb(), c);
}
w(zg, Z);
e = zg.prototype;
e.Hb = function() {
  return this.If;
};
e.Gc = function(a) {
  this.If = a;
  this.l.Gc(this.a(), a);
};
e.Gb = function() {
  return this.Kc;
};
e.Ma = function(a) {
  this.Kc = a;
  this.l.Ma(this.a(), a);
};
e.wf = function(a) {
  this.Kc = a;
};
e.g = function() {
  zg.c.g.call(this);
  delete this.If;
  delete this.Kc;
};
e.L = function() {
  zg.c.L.call(this);
  if (this.O & 32) {
    var a = this.M();
    a && this.W().h(a, "keyup", this.sc);
  }
};
e.sc = function(a) {
  return 13 == a.keyCode && "key" == a.type || 32 == a.keyCode && "keyup" == a.type ? this.Cc(a) : 32 == a.keyCode;
};
Mf("goog-button", function() {
  return new zg(null);
});
function Ag(a) {
  a = String(a);
  if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) {
    try {
      return eval("(" + a + ")");
    } catch (b) {
    }
  }
  throw Error("Invalid JSON string: " + a);
}
function Bg(a) {
  this.td = a;
}
function Cg(a, b) {
  var c = [];
  Dg(a, b, c);
  return c.join("");
}
function Dg(a, b, c) {
  switch(typeof b) {
    case "string":
      Eg(b, c);
      break;
    case "number":
      c.push(isFinite(b) && !isNaN(b) ? b : "null");
      break;
    case "boolean":
      c.push(b);
      break;
    case "undefined":
      c.push("null");
      break;
    case "object":
      if (null == b) {
        c.push("null");
        break;
      }
      if (s(b)) {
        var d = b.length;
        c.push("[");
        for (var f = "", g = 0;g < d;g++) {
          c.push(f), f = b[g], Dg(a, a.td ? a.td.call(b, String(g), f) : f, c), f = ",";
        }
        c.push("]");
        break;
      }
      c.push("{");
      d = "";
      for (g in b) {
        Object.prototype.hasOwnProperty.call(b, g) && (f = b[g], "function" != typeof f && (c.push(d), Eg(g, c), c.push(":"), Dg(a, a.td ? a.td.call(b, g, f) : f, c), d = ","));
      }
      c.push("}");
      break;
    case "function":
      break;
    default:
      throw Error("Unknown type: " + typeof b);;
  }
}
var Fg = {'"':'\\"', "\\":"\\\\", "/":"\\/", "\b":"\\b", "\f":"\\f", "\n":"\\n", "\r":"\\r", "\t":"\\t", "\x0B":"\\u000b"}, Gg = /\uffff/.test("\uffff") ? /[\\\"\x00-\x1f\x7f-\uffff]/g : /[\\\"\x00-\x1f\x7f-\xff]/g;
function Eg(a, b) {
  b.push('"', a.replace(Gg, function(a) {
    if (a in Fg) {
      return Fg[a];
    }
    var b = a.charCodeAt(0), f = "\\u";
    16 > b ? f += "000" : 256 > b ? f += "00" : 4096 > b && (f += "0");
    return Fg[a] = f + b.toString(16);
  }), '"');
}
;function Hg(a, b) {
  null != a && this.append.apply(this, arguments);
}
e = Hg.prototype;
e.cb = "";
e.set = function(a) {
  this.cb = "" + a;
};
e.append = function(a, b, c) {
  this.cb += a;
  if (null != b) {
    for (var d = 1;d < arguments.length;d++) {
      this.cb += arguments[d];
    }
  }
  return this;
};
e.clear = function() {
  this.cb = "";
};
e.toString = function() {
  return this.cb;
};
function Ig(a, b) {
  var c = Array.prototype.slice.call(arguments), d = c.shift();
  if ("undefined" == typeof d) {
    throw Error("[goog.string.format] Template required");
  }
  return d.replace(/%([0\-\ \+]*)(\d+)?(\.(\d+))?([%sfdiu])/g, function(a, b, d, k, l, n, q, F) {
    if ("%" == n) {
      return "%";
    }
    var H = c.shift();
    if ("undefined" == typeof H) {
      throw Error("[goog.string.format] Not enough arguments");
    }
    arguments[0] = H;
    return Jg[n].apply(null, arguments);
  });
}
var Jg = {s:function(a, b, c) {
  return isNaN(c) || "" == c || a.length >= c ? a : a = -1 < b.indexOf("-", 0) ? a + Ja(" ", c - a.length) : Ja(" ", c - a.length) + a;
}, f:function(a, b, c, d, f) {
  d = a.toString();
  isNaN(f) || "" == f || (d = a.toFixed(f));
  var g;
  g = 0 > a ? "-" : 0 <= b.indexOf("+") ? "+" : 0 <= b.indexOf(" ") ? " " : "";
  0 <= a && (d = g + d);
  if (isNaN(c) || d.length >= c) {
    return d;
  }
  d = isNaN(f) ? Math.abs(a).toString() : Math.abs(a).toFixed(f);
  a = c - d.length - g.length;
  return d = 0 <= b.indexOf("-", 0) ? g + d + Ja(" ", a) : g + Ja(0 <= b.indexOf("0", 0) ? "0" : " ", a) + d;
}, d:function(a, b, c, d, f, g, h, k) {
  return Jg.f(parseInt(a, 10), b, c, d, 0, g, h, k);
}};
Jg.i = Jg.d;
Jg.u = Jg.d;
function Kg(a) {
  this.p = a || new Lg;
  this.Zd = new Bg;
}
Kg.prototype.format = function(a) {
  if (null == a) {
    return "";
  }
  if (t(a)) {
    if (/^[\s\xa0]*$/.test(a)) {
      return "";
    }
    a = Ag(a);
  }
  var b = new Hg;
  Mg(this, a, b, 0);
  return b.toString();
};
function Mg(a, b, c, d) {
  var f = ca(b);
  switch(f) {
    case "null":
    ;
    case "boolean":
    ;
    case "number":
    ;
    case "string":
      c.append(Ig(a.p.nf, f), Cg(a.Zd, b), Ig(a.p.mf, f));
      break;
    case "array":
      c.append(a.p.Qf);
      for (var g = 0, g = 0;g < b.length;g++) {
        0 < g && c.append(a.p.of), c.append(a.p.kd), c.append(Ja(a.p.Jc, d + a.p.bd)), Mg(a, b[g], c, d + a.p.bd);
      }
      0 < g && (c.append(a.p.kd), c.append(Ja(a.p.Jc, d)));
      c.append(a.p.Pf);
      break;
    case "object":
      c.append(a.p.Mg);
      f = 0;
      for (g in b) {
        if (b.hasOwnProperty(g)) {
          0 < f && c.append(a.p.of);
          c.append(a.p.kd);
          c.append(Ja(a.p.Jc, d + a.p.bd));
          var h = a;
          c.append(h.p.fh, Cg(h.Zd, g), h.p.eh);
          c.append(a.p.Jg, a.p.Jc);
          Mg(a, b[g], c, d + a.p.bd);
          f++;
        }
      }
      0 < f && (c.append(a.p.kd), c.append(Ja(a.p.Jc, d)));
      c.append(a.p.Lg);
      break;
    default:
      c.append(Ig(a.p.nf, "unknown"), Cg(a.Zd, ""), Ig(a.p.mf, "unknown"));
  }
}
function Lg() {
}
e = Lg.prototype;
e.Jc = " ";
e.kd = "\n";
e.Mg = "{";
e.Lg = "}";
e.Qf = "[";
e.Pf = "]";
e.of = ",";
e.Jg = ":";
e.fh = "";
e.eh = "";
e.nf = "";
e.mf = "";
e.bd = 2;
function Ng(a, b, c, d, f, g, h, k) {
  var l, n;
  if (l = c.offsetParent) {
    var q = "HTML" == l.tagName || "BODY" == l.tagName;
    q && "static" == Pd(l) || (n = Wd(l), q || (q = (q = Xd(l)) && B ? -l.scrollLeft : !q || A && E("8") || "visible" == Od(l, "overflowX") ? l.scrollLeft : l.scrollWidth - l.clientWidth - l.scrollLeft, n = hd(n, new L(q, l.scrollTop))));
  }
  l = n || new L;
  n = ae(a);
  (q = Vd(a)) && n.Xe(new Kd(q.left, q.top, q.right - q.left, q.bottom - q.top));
  var q = M(a), F = M(c);
  if (q.o != F.o) {
    var H = q.o.body, F = Gd(F), O = new L(0, 0), V = od(N(H)), Bb = H;
    do {
      var C;
      if (V == F) {
        C = Wd(Bb);
      } else {
        C = Bb;
        var ea = void 0;
        if (C.getBoundingClientRect) {
          ea = Td(C), ea = new L(ea.left, ea.top);
        } else {
          var ea = Hd(M(C)), x = Wd(C), ea = new L(x.x - ea.x, x.y - ea.y)
        }
        x = void 0;
        if (B && !E(12)) {
          x = void 0;
          x = x = void 0;
          b: {
            x = La("transform");
            if (void 0 === C.style[x] && (x = Id() + Ma(x), void 0 !== C.style[x])) {
              x = (D ? "-webkit" : B ? "-moz" : A ? "-ms" : tb ? "-o" : null) + "-transform";
              break b;
            }
            x = "transform";
          }
          x = (x = Od(C, x) || Od(C, "transform")) ? (C = x.match(je)) ? new L(parseFloat(C[1]), parseFloat(C[2])) : new L(0, 0) : new L(0, 0);
          x = new L(ea.x + x.x, ea.y + x.y);
        } else {
          x = ea;
        }
        C = x;
      }
      O.x += C.x;
      O.y += C.y;
    } while (V && V != F && (Bb = V.frameElement) && (V = V.parent));
    H = hd(O, Wd(H));
    !A || zb(9) || Fd(q) || (H = hd(H, Hd(q)));
    n.left += H.x;
    n.top += H.y;
  }
  a = Og(a, b);
  b = new L(a & 2 ? n.left + n.width : n.left, a & 1 ? n.top + n.height : n.top);
  b = hd(b, l);
  f && (b.x += (a & 2 ? -1 : 1) * f.x, b.y += (a & 1 ? -1 : 1) * f.y);
  var na;
  h && (na = Vd(c)) && (na.top -= l.y, na.right -= l.x, na.bottom -= l.y, na.left -= l.x);
  return Pg(b, c, d, g, na, h, k);
}
function Pg(a, b, c, d, f, g, h) {
  a = a.clone();
  var k = Og(b, c);
  c = Zd(b);
  h = h ? h.clone() : c.clone();
  a = a.clone();
  h = h.clone();
  var l = 0;
  if (d || 0 != k) {
    k & 2 ? a.x -= h.width + (d ? d.right : 0) : d && (a.x += d.left), k & 1 ? a.y -= h.height + (d ? d.bottom : 0) : d && (a.y += d.top);
  }
  g && (f ? (d = a, k = h, l = 0, 65 == (g & 65) && (d.x < f.left || d.x >= f.right) && (g &= -2), 132 == (g & 132) && (d.y < f.top || d.y >= f.bottom) && (g &= -5), d.x < f.left && g & 1 && (d.x = f.left, l |= 1), d.x < f.left && d.x + k.width > f.right && g & 16 && (k.width = Math.max(k.width - (d.x + k.width - f.right), 0), l |= 4), d.x + k.width > f.right && g & 1 && (d.x = Math.max(f.right - k.width, f.left), l |= 1), g & 2 && (l = l | (d.x < f.left ? 16 : 0) | (d.x + k.width > f.right ? 32 : 
  0)), d.y < f.top && g & 4 && (d.y = f.top, l |= 2), d.y <= f.top && d.y + k.height < f.bottom && g & 32 && (k.height = Math.max(k.height - (f.top - d.y), 0), d.y = f.top, l |= 8), d.y >= f.top && d.y + k.height > f.bottom && g & 32 && (k.height = Math.max(k.height - (d.y + k.height - f.bottom), 0), l |= 8), d.y + k.height > f.bottom && g & 4 && (d.y = Math.max(f.bottom - k.height, f.top), l |= 2), g & 8 && (l = l | (d.y < f.top ? 64 : 0) | (d.y + k.height > f.bottom ? 128 : 0)), f = l) : f = 256, 
  l = f);
  g = new Kd(0, 0, 0, 0);
  g.left = a.x;
  g.top = a.y;
  g.width = h.width;
  g.height = h.height;
  f = l;
  if (f & 496) {
    return f;
  }
  Qd(b, new L(g.left, g.top));
  h = new id(g.width, g.height);
  c == h || c && h && c.width == h.width && c.height == h.height || (c = h, g = Fd(M(N(b))), !A || E("10") || g && E("8") ? (b = b.style, B ? b.MozBoxSizing = "border-box" : D ? b.WebkitBoxSizing = "border-box" : b.boxSizing = "border-box", b.width = Math.max(c.width, 0) + "px", b.height = Math.max(c.height, 0) + "px") : (h = b.style, g ? (A ? (g = fe(b, "paddingLeft"), a = fe(b, "paddingRight"), d = fe(b, "paddingTop"), k = fe(b, "paddingBottom"), g = new Q(d, a, k, g)) : (g = R(b, "paddingLeft"), 
  a = R(b, "paddingRight"), d = R(b, "paddingTop"), k = R(b, "paddingBottom"), g = new Q(parseFloat(d), parseFloat(a), parseFloat(k), parseFloat(g))), b = ie(b), h.pixelWidth = c.width - b.left - g.left - g.right - b.right, h.pixelHeight = c.height - b.top - g.top - g.bottom - b.bottom) : (h.pixelWidth = c.width, h.pixelHeight = c.height)));
  return f;
}
function Og(a, b) {
  return(b & 4 && Xd(a) ? b ^ 2 : b) & -5;
}
;function Qg() {
}
Qg.prototype.Z = function() {
};
function Rg(a, b, c) {
  this.element = a;
  this.Fe = b;
  this.bh = c;
}
w(Rg, Qg);
Rg.prototype.Z = function(a, b, c) {
  Ng(this.element, this.Fe, a, b, void 0, c, this.bh);
};
function Sg(a, b) {
  this.Jd = a instanceof L ? a : new L(a, b);
}
w(Sg, Qg);
Sg.prototype.Z = function(a, b, c, d) {
  Ng(Sd(a), 0, a, b, this.Jd, c, null, d);
};
function Tg(a, b) {
  this.dh = 4;
  this.ke = b || void 0;
  cf.call(this, a);
}
w(Tg, cf);
Tg.prototype.Z = function() {
  if (this.ke) {
    var a = !this.n() && "move_offscreen" != this.dc, b = this.a();
    a && (b.style.visibility = "hidden", S(b, !0));
    this.ke.Z(b, this.dh, this.Ig);
    a && S(b, !1);
  }
};
function Ug(a, b, c) {
  this.ga = c || (a ? M(t(a) ? document.getElementById(a) : a) : M());
  Tg.call(this, this.ga.b("div", {style:"position:absolute;display:none;"}));
  this.fb = new L(1, 1);
  this.ib = new Vb;
  a && this.ec(a);
  null != b && wd(this.a(), b);
}
w(Ug, Tg);
var Vg = [];
e = Ug.prototype;
e.H = null;
e.className = "goog-tooltip";
e.yf = 500;
e.Se = 0;
e.j = function() {
  return this.ga;
};
e.ec = function(a) {
  a = t(a) ? document.getElementById(a) : a;
  this.ib.add(a);
  K(a, "mouseover", this.Jb, !1, this);
  K(a, "mouseout", this.$c, !1, this);
  K(a, "mousemove", this.Ib, !1, this);
  K(a, "focus", this.Ua, !1, this);
  K(a, "blur", this.$c, !1, this);
};
e.detach = function(a) {
  if (a) {
    a = t(a) ? document.getElementById(a) : a, Wg(this, a), this.ib.remove(a);
  } else {
    for (var b = this.ib.da(), c = 0;a = b[c];c++) {
      Wg(this, a);
    }
    this.ib.clear();
  }
};
function Wg(a, b) {
  Xc(b, "mouseover", a.Jb, !1, a);
  Xc(b, "mouseout", a.$c, !1, a);
  Xc(b, "mousemove", a.Ib, !1, a);
  Xc(b, "focus", a.Ua, !1, a);
  Xc(b, "blur", a.$c, !1, a);
}
e.Td = function() {
  return this.Se;
};
e.pe = function(a) {
  var b = this.a();
  b && vd(b);
  Ug.c.pe.call(this, a);
  a && (b = this.ga.o.body, b.insertBefore(a, b.lastChild));
};
e.pc = function() {
  return this.$a ? this.n() ? 4 : 1 : this.Mb ? 3 : this.n() ? 2 : 0;
};
e.dd = function(a) {
  if (!this.n()) {
    return!1;
  }
  var b = Wd(this.a()), c = Zd(this.a());
  return b.x <= a.x && a.x <= b.x + c.width && b.y <= a.y && a.y <= b.y + c.height;
};
e.ee = function() {
  if (!cf.prototype.ee.call(this)) {
    return!1;
  }
  if (this.anchor) {
    for (var a, b = 0;a = Vg[b];b++) {
      P(a.a(), this.anchor) || a.k(!1);
    }
  }
  Wa(Vg, this) || Vg.push(this);
  a = this.a();
  a.className = this.className;
  Xg(this);
  K(a, "mouseover", this.Yd, !1, this);
  K(a, "mouseout", this.Pe, !1, this);
  Yg(this);
  return!0;
};
e.Ac = function() {
  Xa(Vg, this);
  for (var a = this.a(), b, c = 0;b = Vg[c];c++) {
    b.anchor && P(a, b.anchor) && b.k(!1);
  }
  this.lf && Zg(this.lf);
  Xc(a, "mouseover", this.Yd, !1, this);
  Xc(a, "mouseout", this.Pe, !1, this);
  this.anchor = void 0;
  0 == this.pc() && (this.vd = !1);
  cf.prototype.Ac.call(this);
};
e.ef = function(a, b) {
  this.anchor == a && this.ib.contains(this.anchor) && (this.vd || !this.zh ? (this.k(!1), this.n() || (this.anchor = a, this.ke = b || $g(this, 0) || void 0, this.n() && this.Z(), this.k(!0))) : this.anchor = void 0);
  this.$a = void 0;
};
e.Rd = function() {
  return this.H;
};
e.df = function(a) {
  this.Mb = void 0;
  a == this.anchor && (null != this.H && (this.H == this.a() || this.ib.contains(this.H)) || this.Ab && this.Ab.H || this.k(!1));
};
function ah(a, b) {
  var c = Hd(a.ga);
  a.fb.x = b.clientX + c.x;
  a.fb.y = b.clientY + c.y;
}
e.Jb = function(a) {
  var b = bh(this, a.target);
  this.H = b;
  Xg(this);
  b != this.anchor && (this.anchor = b, this.$a || (this.$a = af(v(this.ef, this, b, void 0), this.yf)), ch(this), ah(this, a));
};
function bh(a, b) {
  try {
    for (;b && !a.ib.contains(b);) {
      b = b.parentNode;
    }
    return b;
  } catch (c) {
    return null;
  }
}
e.Ib = function(a) {
  ah(this, a);
  this.vd = !0;
};
e.Ua = function(a) {
  this.H = a = bh(this, a.target);
  this.vd = !0;
  if (this.anchor != a) {
    this.anchor = a;
    var b = $g(this, 1);
    Xg(this);
    this.$a || (this.$a = af(v(this.ef, this, a, b), this.yf));
    ch(this);
  }
};
function $g(a, b) {
  if (0 == b) {
    var c = a.fb.clone();
    return new dh(c);
  }
  return new eh(a.H);
}
function ch(a) {
  if (a.anchor) {
    for (var b, c = 0;b = Vg[c];c++) {
      P(b.a(), a.anchor) && (b.Ab = a, a.lf = b);
    }
  }
}
e.$c = function(a) {
  var b = bh(this, a.target), c = bh(this, a.relatedTarget);
  b != c && (b == this.H && (this.H = null), Yg(this), this.vd = !1, !this.n() || a.relatedTarget && P(this.a(), a.relatedTarget) ? this.anchor = void 0 : Zg(this));
};
e.Yd = function() {
  var a = this.a();
  this.H != a && (Xg(this), this.H = a);
};
e.Pe = function(a) {
  var b = this.a();
  this.H != b || a.relatedTarget && P(b, a.relatedTarget) || (this.H = null, Zg(this));
};
function Yg(a) {
  a.$a && (m.clearTimeout(a.$a), a.$a = void 0);
}
function Zg(a) {
  2 == a.pc() && (a.Mb = af(v(a.df, a, a.anchor), a.Td()));
}
function Xg(a) {
  a.Mb && (m.clearTimeout(a.Mb), a.Mb = void 0);
}
e.g = function() {
  this.k(!1);
  Yg(this);
  this.detach();
  this.a() && vd(this.a());
  this.H = null;
  delete this.ga;
  Ug.c.g.call(this);
};
function dh(a, b) {
  Sg.call(this, a, b);
}
w(dh, Sg);
dh.prototype.Z = function(a, b, c) {
  b = Sd(a);
  b = Vd(b);
  c = c ? new Q(c.top + 10, c.right, c.bottom, c.left + 10) : new Q(10, 0, 0, 10);
  Pg(this.Jd, a, 4, c, b, 9) & 496 && Pg(this.Jd, a, 4, c, b, 5);
};
function eh(a) {
  Rg.call(this, a, 3);
}
w(eh, Rg);
eh.prototype.Z = function(a, b, c) {
  var d = new L(10, 0);
  Ng(this.element, this.Fe, a, b, d, c, 9) & 496 && Ng(this.element, 2, a, 1, d, c, 5);
};
function fh(a, b, c) {
  Ug.call(this, a, b, c);
}
w(fh, Ug);
e = fh.prototype;
e.Ie = !1;
e.Xf = 100;
e.Lc = !1;
e.Xa = function() {
  fh.c.Xa.call(this);
  this.Qc = Ld(ae(this.a()));
  this.anchor && (this.Cd = Ld(ae(this.anchor)));
  this.Lc = this.Ie;
  K(Ed(this.j()), "mousemove", this.Ib, !1, this);
};
e.Ac = function() {
  Xc(Ed(this.j()), "mousemove", this.Ib, !1, this);
  this.Cd = this.Qc = null;
  this.Lc = !1;
  fh.c.Ac.call(this);
};
e.dd = function(a) {
  if (this.wc) {
    var b = Wd(this.a()), c = Zd(this.a());
    return b.x - this.wc.left <= a.x && a.x <= b.x + c.width + this.wc.right && b.y - this.wc.top <= a.y && a.y <= b.y + c.height + this.wc.bottom;
  }
  return fh.c.dd.call(this, a);
};
function gh(a, b) {
  if (a.Cd && a.Cd.contains(b) || a.dd(b)) {
    return!0;
  }
  var c = a.Ab;
  return!!c && c.dd(b);
}
e.df = function(a) {
  this.Mb = void 0;
  a != this.anchor || gh(this, this.fb) || this.Rd() || this.Ab && this.Ab.H || B && 0 == this.fb.x && 0 == this.fb.y || this.k(!1);
};
e.Ib = function(a) {
  var b = this.n();
  if (this.Qc) {
    var c = Hd(this.j()), c = new L(a.clientX + c.x, a.clientY + c.y);
    gh(this, c) ? b = !1 : this.Lc && (b = Jd(this.Qc, c) >= Jd(this.Qc, this.fb));
  }
  if (b) {
    if (Zg(this), this.H = null, b = this.Ab) {
      b.H = null;
    }
  } else {
    3 == this.pc() && Xg(this);
  }
  fh.c.Ib.call(this, a);
};
e.Yd = function() {
  this.Rd() != this.a() && (this.Lc = !1, this.H = this.a());
};
e.Td = function() {
  return this.Lc ? this.Xf : fh.c.Td.call(this);
};
function hh() {
  Ug.call(this, void 0, void 0, void 0);
  var a = this.j();
  this.Gd = a.createElement("PRE");
  this.Tc = a.b("BUTTON", null, "Close");
  K(this.Tc, "click", v(this.k, this, !1));
  a = a.b("DIV", null, this.Gd, a.createElement("HR"), a.b("DIV", {style:"text-align: center;"}, this.Tc));
  this.a().appendChild(a);
}
w(hh, fh);
hh.prototype.g = function() {
  Zc(this.Tc);
  delete this.Tc;
  delete this.Gd;
  hh.c.g.call(this);
};
hh.prototype.update = function(a) {
  this.Gd.innerHTML = (new Kg(new Lg)).format(a || {});
};
function ih() {
  U.call(this);
  this.R = new tg;
  this.U(this.R);
  this.eb = new X(void 0, !0);
  lf(this.eb, "Delete session?");
  this.eb.vb("Are you sure you want to delete this session?");
  K(this.eb, sf, this.Og, !1, this);
  this.jc = new zg("Delete Session");
  this.U(this.jc);
  K(this.jc, "action", v(this.eb.k, this.eb, !0));
  this.La = new zg("Take Screenshot");
  this.U(this.La);
  K(this.La, "action", this.ge, !1, this);
  this.Pa = new hh;
  this.Pa.wc = new Q(5, 5, 5, 5) || null;
  this.Pa.Ie = !0;
  var a = this.Pa, b = new Q(10, 0, 0, 0);
  a.Ig = null == b || b instanceof Q ? b : new Q(b, void 0, void 0, void 0);
  a.n() && a.Z();
  this.Pa.Se = 250;
}
w(ih, U);
e = ih.prototype;
e.g = function() {
  this.Pa.C();
  this.eb.C();
  delete this.R;
  delete this.Vc;
  delete this.xd;
  delete this.oe;
  delete this.eb;
  delete this.Pa;
  delete this.La;
  delete this.jc;
  delete this.ue;
  ih.c.g.call(this);
};
e.b = function() {
  this.La.b();
  this.jc.b();
  this.R.b();
  var a = this.j();
  this.Vc = a.b("DIV", "goog-tab-content empty-view", "No Sessions");
  this.oe = a.createElement("SPAN");
  this.ue = a.b("DIV", "todo", "\u00a0");
  this.ue.disabled = !0;
  this.R.addElement(this.oe);
  var b;
  this.R.addElement(b = a.b("SPAN", "session-capabilities", "Capabilities"));
  this.R.addElement(this.La.a());
  this.R.addElement(this.jc.a());
  this.xd = a.b("DIV", "goog-tab-content", this.R.a(), this.ue);
  this.e = a.b("DIV", null, this.Vc, this.xd, a.b("DIV", "goog-tab-bar-clear"));
  this.update(null);
  this.Pa.ec(b);
};
e.zd = function(a) {
  this.R.addElement(a);
};
e.update = function(a) {
  var b = !!a;
  S(this.Vc, !b);
  S(this.xd, b);
  a && (wd(this.oe, a.J()), this.Pa.update(a.xa), a.xa.get("takesScreenshot") ? (this.La.la(!0), this.La.Ma("")) : (this.La.la(!1), this.La.Ma("Screenshots not supported")));
};
e.Og = function(a) {
  "ok" == a.key && this.dispatchEvent("delete");
};
e.ge = function() {
  this.dispatchEvent("screenshot");
};
function jh(a) {
  wg.call(this, "Sessions");
  this.B = new pg(ng, null);
  this.Fa = new ih;
  this.Cb = new vg(a);
  this.ic = this.j().b("BUTTON", null, "Create Session");
  this.Dc = this.j().b("BUTTON", null, "Refresh Sessions");
  this.R = new tg;
  this.ka = [];
  this.Hf = setInterval(v(this.sh, this), 300);
  this.U(this.B);
  this.U(this.Fa);
  this.U(this.R);
  this.la(!1);
  this.R.addElement(this.ic);
  this.R.addElement(this.Dc);
  K(this.ic, "click", v(this.Cb.k, this.Cb, !0));
  K(this.Dc, "click", v(this.dispatchEvent, this, "refresh"));
  K(this.B, "select", this.Xg, !1, this);
  K(this.Cb, "action", this.Pg, !1, this);
}
w(jh, wg);
e = jh.prototype;
e.g = function() {
  Zc(this.ic);
  Zc(this.Dc);
  clearInterval(this.Hf);
  this.Cb.C();
  delete this.Cb;
  delete this.B;
  delete this.Fa;
  delete this.R;
  delete this.ka;
  delete this.Hf;
  jh.c.g.call(this);
};
e.He = function() {
  this.B.b();
  this.Fa.b();
  this.R.b();
  return this.j().b("DIV", "session-container", this.R.a(), this.B.a(), this.Fa.a());
};
e.la = function(a) {
  a ? (this.ic.removeAttribute("disabled"), this.Dc.removeAttribute("disabled")) : (this.ic.setAttribute("disabled", "disabled"), this.Dc.setAttribute("disabled", "disabled"));
};
e.zd = function(a) {
  this.Fa.zd(a);
};
function kh(a) {
  return(a = a.B.X) ? a.ub : null;
}
e.sh = function() {
  if (this.ka.length) {
    var a = this.ka[0].nc(), a = 5 === a.length ? "." : a + ".";
    z(this.ka, function(b) {
      b.vb(a);
    });
  }
};
function lh(a) {
  var b = Zd(a.B.a());
  a = a.Fa;
  b = b.height + 20;
  Md(a.Vc, "height", b + "px");
  Md(a.xd, "height", b + "px");
}
e.we = function(a) {
  a = new mh(a);
  var b = this.ka.shift(), c = we(this.B, b);
  0 > c ? this.B.U(a, !0) : (this.B.Pc(a, c, !0), this.B.removeChild(b, !0));
  lh(this);
  sg(this.B, a);
};
function nh(a, b) {
  var c = new kb;
  z(b, function(a) {
    c.set(a.J(), a);
  });
  for (var d = a.B, f = d.X, g = [], h = ue(d) - a.ka.length, k = 0;k < h;++k) {
    g.push(W(d, k));
  }
  z(g, function(a) {
    var b = a.ub.J(), g = c.get(b);
    g ? (c.remove(b), a.ub = g) : (d.removeChild(a, !0), f === a && (f = null));
  }, a);
  z(a.ka, function(a) {
    d.removeChild(a, !0);
  });
  a.ka = [];
  z(c.da(), a.we, a);
  f ? (a.Fa.update(f.ub), sg(d, f)) : ue(d) ? sg(d, W(d, 0)) : a.Fa.update(null);
}
e.Pg = function() {
  var a = ".";
  this.ka.length && (a = this.ka[0].nc());
  a = new Xf(a, null, this.j());
  a.la(!1);
  this.ka.push(a);
  this.B.U(a, !0);
  lh(this);
  a = new ze("create", this, this.Cb.Ud());
  this.dispatchEvent(a);
};
e.Xg = function() {
  var a = this.B.X;
  this.Fa.update(a ? a.ub : null);
};
function mh(a) {
  var b = a.xa.get("browserName") || "unknown browser", b = b.toLowerCase().replace(/(^|\b)[a-z]/g, function(a) {
    return a.toUpperCase();
  });
  Xf.call(this, b);
  this.ub = a;
}
w(mh, Xf);
mh.prototype.g = function() {
  delete this.ub;
  mh.c.g.call(this);
};
function oh(a, b) {
  U.call(this, b);
  this.Rb = a || "";
}
var ph;
w(oh, U);
e = oh.prototype;
e.Aa = null;
e.Eg = 10;
function qh() {
  null != ph || (ph = "placeholder" in document.createElement("input"));
  return ph;
}
e.uc = !1;
e.b = function() {
  this.e = this.j().b("input", {type:"text"});
};
e.L = function() {
  oh.c.L.call(this);
  var a = new ke(this);
  a.h(this.a(), "focus", this.Oe);
  a.h(this.a(), "blur", this.fg);
  qh() ? this.D = a : (B && a.h(this.a(), ["keypress", "keydown", "keyup"], this.kg), a.h(od(N(this.a())), "load", this.wg), this.D = a, rh(this));
  sh(this);
  this.a().Dg = this;
};
e.ca = function() {
  oh.c.ca.call(this);
  this.D && (this.D.C(), this.D = null);
  this.a().Dg = null;
};
function rh(a) {
  !a.dg && a.D && a.a().form && (a.D.h(a.a().form, "submit", a.lg), a.dg = !0);
}
e.g = function() {
  oh.c.g.call(this);
  this.D && (this.D.C(), this.D = null);
};
e.Oc = "label-input-label";
e.Oe = function() {
  this.uc = !0;
  He(this.a(), this.Oc);
  if (!qh() && !th(this) && !this.Ag) {
    var a = this, b = function() {
      a.a() && (a.a().value = "");
    };
    A ? af(b, 10) : b();
  }
};
e.fg = function() {
  qh() || (this.D.$(this.a(), "click", this.Oe), this.Aa = null);
  this.uc = !1;
  sh(this);
};
e.kg = function(a) {
  27 == a.keyCode && ("keydown" == a.type ? this.Aa = this.a().value : "keypress" == a.type ? this.a().value = this.Aa : "keyup" == a.type && (this.Aa = null), a.preventDefault());
};
e.lg = function() {
  th(this) || (this.a().value = "", af(this.eg, 10, this));
};
e.eg = function() {
  th(this) || (this.a().value = this.Rb);
};
e.wg = function() {
  sh(this);
};
e.hasFocus = function() {
  return this.uc;
};
function th(a) {
  return!!a.a() && "" != a.a().value && a.a().value != a.Rb;
}
e.clear = function() {
  this.a().value = "";
  null != this.Aa && (this.Aa = "");
};
e.reset = function() {
  th(this) && (this.clear(), sh(this));
};
e.Gc = function(a) {
  null != this.Aa && (this.Aa = a);
  this.a().value = a;
  sh(this);
};
e.Hb = function() {
  return null != this.Aa ? this.Aa : th(this) ? this.a().value : "";
};
function sh(a) {
  var b = a.a();
  qh() ? a.a().placeholder != a.Rb && (a.a().placeholder = a.Rb) : rh(a);
  Ce(b, "label", a.Rb);
  th(a) ? (b = a.a(), He(b, a.Oc)) : (a.Ag || a.uc || (b = a.a(), Fe(b, a.Oc)), qh() || af(a.hh, a.Eg, a));
}
e.la = function(a) {
  this.a().disabled = !a;
  var b = this.a(), c = this.Oc + "-disabled";
  a ? He(b, c) : Fe(b, c);
};
e.isEnabled = function() {
  return!this.a().disabled;
};
e.hh = function() {
  !this.a() || th(this) || this.uc || (this.a().value = this.Rb);
};
function uh() {
  ug.call(this, "Open WebDriverJS Script");
  K(this, "show", this.Xa, !1, this);
  this.Ba = new oh("Script URL");
  this.U(this.Ba);
}
w(uh, ug);
e = uh.prototype;
e.g = function() {
  delete this.Ba;
  uh.c.g.call(this);
};
e.Ge = function() {
  var a = pd("A", {href:"http://code.google.com/p/selenium/wiki/WebDriverJs", target:"_blank"}, "WebDriverJS");
  this.Ba.b();
  Fe(this.Ba.a(), "url-input");
  var b = this.j();
  return b.b("DIV", null, b.b("P", null, "Open a page that has the ", a, " client. The page will be opened with the query parameters required to communicate with the server."), this.Ba.a());
};
e.Xa = function() {
  this.Ba.clear();
  this.Ba.a().focus();
  this.Ba.a().blur();
};
e.Ud = function() {
  return this.Ba.Hb();
};
e.Re = function() {
  return th(this.Ba);
};
function vh() {
  zg.call(this, "Load Script");
  this.Ub = new uh;
  K(this.Ub, "action", this.Ug, !1, this);
  K(this, "action", v(this.Ub.k, this.Ub, !0));
}
w(vh, zg);
vh.prototype.g = function() {
  this.Ub.C();
  delete this.Ub;
  vh.c.g.call(this);
};
vh.prototype.Ug = function() {
  var a = new ze("loadscript", this, this.Ub.Ud());
  this.dispatchEvent(a);
};
function wh(a) {
  this.qb = a;
  this.ie = {};
}
wh.prototype.getName = function() {
  return this.qb;
};
wh.prototype.setParameter = function(a, b) {
  this.ie[a] = b;
  return this;
};
wh.prototype.getParameter = function(a) {
  return this.ie[a];
};
function xh(a) {
  this.xa = {};
  a && yh(this, a);
}
xh.prototype.toJSON = function() {
  return this.xa;
};
function yh(a, b) {
  var c = b instanceof xh ? b.xa : b, d;
  for (d in c) {
    c.hasOwnProperty(d) && a.set(d, c[d]);
  }
  return a;
}
xh.prototype.set = function(a, b) {
  null != b ? this.xa[a] = b : delete this.xa[a];
  return this;
};
xh.prototype.get = function(a) {
  var b = null;
  this.xa.hasOwnProperty(a) && (b = this.xa[a]);
  return null != b ? b : null;
};
xh.prototype.has = function(a) {
  return!!this.get(a);
};
function zh(a, b) {
  this.Pb = a;
  this.xa = yh(new xh, b);
}
zh.prototype.J = function() {
  return this.Pb;
};
zh.prototype.toJSON = function() {
  return this.J();
};
function Ah() {
  this.jb = {};
}
e = Ah.prototype;
e.Uc = function(a, b) {
  var c = Array.prototype.slice.call(arguments, 1), d = this.jb[a];
  if (d) {
    for (var f = 0;f < d.length;) {
      var g = d[f];
      g.Od.apply(g.scope, c);
      d[f] === g && (d[f].$g ? d.splice(f, 1) : f += 1);
    }
  }
};
e.G = function(a) {
  var b = this.jb[a];
  b || (b = this.jb[a] = []);
  return b;
};
e.addListener = function(a, b, c) {
  a: {
    a = this.G(a);
    for (var d = a.length, f = 0;f < d;++f) {
      if (a[f].Od == b) {
        b = this;
        break a;
      }
    }
    a.push({Od:b, scope:c, $g:!1});
    b = this;
  }
  return b;
};
e.removeListener = function(a, b) {
  var c = this.jb[a];
  if (c) {
    for (var d = c.length, f = 0;f < d;++f) {
      if (c[f].Od == b) {
        c.splice(f, 1);
        break;
      }
    }
  }
  return this;
};
e.sd = function(a) {
  p(a) ? delete this.jb[a] : this.jb = {};
  return this;
};
function Bh(a) {
  this.Ic = a || 0;
  var b;
  if (Ch) {
    b = Error(), Error.captureStackTrace(b, Bh);
  } else {
    this.Ic += 1;
    try {
      null.x();
    } catch (c) {
      b = c;
    }
  }
  this.Af = Dh(b);
}
var Ch = u(Error.captureStackTrace);
if (!Ch) {
  try {
    throw Error();
  } catch (Eh) {
  }
}
Bh.prototype.Bc = null;
function Fh(a, b, c, d) {
  this.Wf = a || "";
  this.qb = b || "";
  this.xe = c || "";
  this.Nc = this.fa = d || "";
  this.$e = -1;
  d && (a = /:(\d+)(?::(\d+))?$/.exec(d)) && (this.$e = Number(a[1]), this.Nc = d.substr(0, a.index));
}
var Gh = new Fh("", "", "", "");
Fh.prototype.getName = function() {
  return this.qb;
};
Fh.prototype.toString = function() {
  var a = this.Wf;
  a && "new " !== a && (a += ".");
  var a = a + this.qb, a = a + (this.xe ? " [as " + this.xe + "]" : ""), b = this.fa || "<anonymous>";
  return "    at " + (a ? a + " (" + b + ")" : b);
};
var Hh = /^\s+at(?! (?:Anonymous function|Global code|eval code) )(?: (?:(?:((?:new )?(?:\[object Object\]|[a-zA-Z_$][\w$]*(?:\.[a-zA-Z_$][\w$]*)*))\.|(new )))?((?:[a-zA-Z_$][\w$]*|<anonymous>))(?: \[as ([a-zA-Z_$][\w$]*)\])?)? (?:\((.*)\)|(.*))$/, Ih = /^([a-zA-Z_$][\w$]*[\w./<$]*)?(?:\(.*\))?@(?::0|((?:http|https|file):\/\/[^\s]+|javascript:.*))$/, Jh = /^(?:(?:([a-zA-Z_$][\w$]*)|<anonymous function(?:\: (?:([a-zA-Z_$][\w$]*(?:\.[a-zA-Z_$][\w$]*)*)\.)?([a-zA-Z_$][\w$]*))?>)(?:\(.*\)))?@((?:http|https|file):\/\/[^\s]+|javascript:.*)?$/, 
Kh = /^   at (?:([a-zA-Z_$][\w$]*(?:\.[a-zA-Z_$][\w$]*)*)\.)?([a-zA-Z_$][\w$]*(?:\s+\w+)*)\s*(?:\((.*)\))$/, Lh = /^> (?:(?:([a-zA-Z_$][\w$]*(?:\.[a-zA-Z_$][\w$]*)*)\.)?([a-zA-Z_$][\w$]*)(?:\(.*\))?(?: \[as ([a-zA-Z_$][\w$]*)\])?(?: at )?)?(?:(.*:\d+:\d+)|((?:http|https|file):\/\/[^\s]+|javascript:.*))?$/;
function Mh(a) {
  var b = a.match(Hh);
  if (b) {
    return new Fh(b[1] || b[2], b[3], b[4], b[5] || b[6]);
  }
  if (5E5 < a.length) {
    var c = a.indexOf("("), b = a.lastIndexOf("@"), d = a.lastIndexOf(":"), f = "";
    0 <= c && c < b && (f = a.substring(0, c));
    c = "";
    0 <= b && b + 1 < d && (c = a.substring(b + 1));
    return new Fh("", f, "", c);
  }
  return(b = a.match(Ih)) ? new Fh("", b[1], "", b[2]) : (b = a.match(Jh)) ? new Fh(b[2], b[1] || b[3], "", b[4]) : (b = a.match(Kh)) ? new Fh(b[1], b[2], "", b[3]) : "> (unknown)" == a || "> anonymous" == a ? Gh : (b = a.match(Lh)) ? new Fh(b[1], b[2], b[3], b[4] || b[5]) : null;
}
function Dh(a) {
  if (!a) {
    return "";
  }
  var b = a.stack || a.Ah || "";
  a += "\n";
  0 == b.lastIndexOf(a, 0) && (b = b.substring(a.length));
  return b;
}
function Nh(a) {
  function b(a) {
    return "    at <anonymous>" === a.toString();
  }
  var c = Oh(Dh(a));
  if (c.length && Va(c, b)) {
    return a;
  }
  var d = "", d = a.message ? (a.name ? a.name + ": " : "") + a.message : a.toString();
  a.stack = d + "\n" + c.join("\n");
  return a;
}
function Oh(a) {
  if (!a) {
    return[];
  }
  a = a.replace(/\s*$/, "").split("\n");
  for (var b = [], c = 0;c < a.length;c++) {
    var d = Mh(a[c]);
    tb && 2 == c && 0 == d.$e || b.push(d || Gh);
  }
  return b;
}
;/*
 Portions of this code are from the Dojo toolkit, received under the
 BSD License:
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice,
     this list of conditions and the following disclaimer in the documentation
     and/or other materials provided with the distribution.
 Neither the name of the Dojo Foundation nor the names of its contributors
     may be used to endorse or promote products derived from this software
     without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.
*/
function Ph(a) {
  xa.call(this, a);
  this.name = "CancellationError";
}
w(Ph, xa);
function Qh() {
}
Qh.prototype.then = Qh.prototype.then;
try {
  Object.defineProperty(Qh.prototype, "$webdriver_Thenable", {value:!0, enumerable:!1});
} catch (Rh) {
  Qh.prototype.$webdriver_Thenable = !0;
}
Qh.prototype.cancel = function() {
  throw new TypeError('Unimplemented function: "cancel"');
};
Qh.prototype.fd = function() {
  throw new TypeError('Unimplemented function: "isPending"');
};
Qh.prototype.then = function() {
  throw new TypeError('Unimplemented function: "then"');
};
Qh.prototype.xb = function(a) {
  return this.then(null, a);
};
function Sh(a) {
  function b() {
    return O == Th;
  }
  function c() {
    q = [];
  }
  function d(a, b) {
    if (Th === O) {
      if (b === C) {
        throw TypeError("A promise may not resolve to itself");
      }
      O = Uh;
      if (Vh(b)) {
        var c = ma(f, a), d = ma(f, Wh);
        b instanceof Sh ? b.then(c, d) : Xh(b, c, d);
      } else {
        f(a, b);
      }
    }
  }
  function f(a, b) {
    a === Wh && ga(b) && t(b.message) && (b = Yh(n, b));
    O = a;
    for (V = b;q.length;) {
      g(q.shift());
    }
    F || O != Wh || V instanceof Ph || (n.qa += 1, H = n.Ea.setTimeout(function() {
      H = null;
      n.qa -= 1;
      Zh(n, V);
    }, 0));
  }
  function g(a) {
    var b = O == $h ? a.Uf : a.Ke;
    b ? ai(n, ma(b, V), a.Sa, a.reject) : O == Wh ? a.reject(V) : a.Sa(V);
  }
  function h(a) {
    d($h, a);
  }
  function k(a) {
    d(Wh, a);
  }
  function l(a) {
    b() && (C.A ? C.A.cancel(a) : k(new Ph(a)));
  }
  var n = a || Pa() || bi;
  this.A = null;
  var q = [], F = !1, H = null, O = Th, V, Bb = new Qh, C = this;
  this.ra = Bb;
  this.ra.then = this.then = function(a, b) {
    if (!a && !b) {
      return Bb;
    }
    F = !0;
    null !== H && (n.qa -= 1, n.Ea.clearTimeout(H), H = null);
    var c = new Sh(n);
    c.A = C;
    var d = {Uf:a, Ke:b, Sa:c.Sa, reject:c.reject};
    O == Th || O == Uh ? q.push(d) : g(d);
    return c.ra;
  };
  this.ra.cancel = this.cancel = l;
  this.ra.fd = this.fd = b;
  this.Sa = h;
  this.reject = this.Ke = k;
  this instanceof ci && (this.Ca = c);
  this.then = this.then;
  this.cancel = l;
  this.fulfill = h;
  this.reject = k;
  this.isPending = b;
  this.promise = this.ra;
  this.ra.then = this.then;
  this.ra.cancel = l;
  this.ra.isPending = b;
}
w(Sh, Qh);
var Wh = -1, Th = 0, Uh = 1, $h = 2;
function di(a) {
  return a instanceof Error || ga(a) && ("[object Error]" === Object.prototype.toString.call(a) || a.xh);
}
function Vh(a) {
  return!!a && ga(a) && u(a.then);
}
function ei(a) {
  var b = (Pa() || bi).Ea, c = new Sh, d = b.setTimeout(c.Sa, a);
  return c.xb(function(a) {
    b.clearTimeout(d);
    throw a;
  });
}
function fi(a, b) {
  var c = new Sh;
  try {
    var d = ab(arguments, 1);
    d.push(function(a, b) {
      a ? c.reject(a) : c.Sa(b);
    });
    a.apply(null, d);
  } catch (f) {
    c.reject(f);
  }
  return c.ra;
}
function Xh(a, b, c) {
  Vh(a) ? a.then(b, c) : a && ga(a) && u(a.Mf) ? a.Mf(b, c) : b && b(a);
}
function gi(a) {
  this.jb = {};
  this.Ea = a || hi;
  this.Ob = [];
  this.lc = this.bc = this.ne = this.q = null;
  this.yc = this.qa = 0;
}
w(gi, Ah);
var hi = function() {
  function a(a) {
    return function(c, d) {
      return a(c, d);
    };
  }
  return{clearInterval:a(clearInterval), clearTimeout:a(clearTimeout), setInterval:a(setInterval), setTimeout:a(setTimeout)};
}();
gi.prototype.reset = function() {
  this.q = null;
  this.Ob = [];
  this.Uc("reset");
  this.sd();
  ii(this);
  ji(this);
};
function ki(a) {
  for (var b = [], c = a.q;c;) {
    var d = c.pd;
    d && b.push(d);
    c = c.getParent();
  }
  return Ta(Ya(a.Ob, b), function(a) {
    return a.toString();
  });
}
function li(a) {
  a.yc && ($a(a.Ob, a.Ob.length - a.yc, a.yc), a.yc = 0);
  a.Ob.pop();
}
function Yh(a, b) {
  if (b.webdriver_promise_error_) {
    return b;
  }
  var c = ki(a);
  c.length && (b = Nh(b), b.stack += ["\n==== async task ====\n", c.join("\n==== async task ====\n")].join(""), b.webdriver_promise_error_ = !0);
  return b;
}
gi.prototype.mc = function(a, b) {
  "GeneratorFunction" === a.constructor.name && (a = ma(mi, a));
  ii(this);
  this.q || (this.q = new ni(this));
  var c = new Bh(1), c = new ci(this, a, b || "", c);
  (this.ne || this.q).U(c);
  this.Uc("scheduleTask", b);
  this.lc || (this.lc = this.Ea.setInterval(v(this.ih, this), 10));
  return c.ra;
};
gi.prototype.timeout = function(a, b) {
  return this.mc(function() {
    return ei(a);
  }, b);
};
function ji(a) {
  a.lc && (a.Ea.clearInterval(a.lc), a.lc = null);
}
gi.prototype.ih = function() {
  if (!this.qa) {
    if (this.q) {
      var a;
      if (!this.q.pd && (a = oi(this))) {
        var b = this.q;
        b.pd = a;
        var c = v(function() {
          this.Ob.push(a);
          b.pd = null;
        }, this);
        li(this);
        var d = this;
        ai(this, a.mc, function(b) {
          c();
          a.Sa(b);
        }, function(b) {
          c();
          di(b) || Vh(b) || (b = Error(b));
          a.reject(Yh(d, b));
        }, !0);
      }
    } else {
      pi(this);
    }
  }
};
function oi(a) {
  var b = a.q, c;
  b.ed = !0;
  b.oa = null;
  c = b.m[0];
  if (!c) {
    return b.Cg || (a.q === b && (a.q = b.getParent()), b.getParent() && b.getParent().removeChild(b), li(a), b.close(), a.q || pi(a)), null;
  }
  if (c instanceof ni) {
    return a.q = c, oi(a);
  }
  b.removeChild(c);
  return c;
}
function Zh(a, b) {
  di(b) && Yh(a, b);
  a.yc++;
  if (a.q) {
    var c = a.q.getParent();
    c && c.removeChild(a.q);
    var d = a.q;
    a.q = c;
    d.abort(b);
  } else {
    qi(a, b);
  }
}
function ai(a, b, c, d, f) {
  function g(a) {
    var b = h.getParent();
    b && b.removeChild(h);
    a && ri(h, "Tasks cancelled due to uncaught error: " + a);
    k.q = l;
  }
  var h = new ni(a), k = a, l = a.q;
  try {
    a.q ? a.q.U(h) : a.q = h;
    f && (a.q = h);
    try {
      a.ne = h;
      Qa.push(a);
      var n = b();
    } finally {
      Qa.pop(), a.ne = null;
    }
    h.ed = !0;
    h.m.length ? (h.ld = function() {
      Xh(n, c, d);
    }, h.zc = function(a) {
      var b;
      if (n) {
        try {
          b = !!n.$webdriver_Thenable;
        } catch (c) {
          b = !1;
        }
      } else {
        b = !1;
      }
      b && n.fd() && (n.cancel(a), a = n);
      d(a);
    }) : (g(), Xh(n, c, d));
  } catch (q) {
    g(q), d(q);
  }
}
function pi(a) {
  a.bc || (ji(a), a.bc = a.Ea.setTimeout(function() {
    a.bc = null;
    a.Uc("idle");
  }, 0));
}
function ii(a) {
  a.bc && (a.Ea.clearTimeout(a.bc), a.bc = null);
}
function qi(a, b) {
  a.q = null;
  ii(a);
  ji(a);
  a.G("uncaughtException").length ? a.Uc("uncaughtException", b) : a.Ea.setTimeout(function() {
    throw b;
  }, 0);
}
function ni(a) {
  this.kb = a;
  this.A = null;
  this.m = [];
  this.pd = this.oa = null;
  this.Cg = this.ed = !1;
  this.zc = this.ld = null;
}
e = ni.prototype;
e.getParent = function() {
  return this.A;
};
e.Fc = function(a) {
  this.A = a;
};
e.abort = function(a) {
  ri(this, "Task discarded due to a previous task failure: " + a);
  var b = this;
  b.kb.qa += 1;
  this.kb.Ea.setTimeout(function() {
    b.kb.qa -= 1;
    if (b.zc) {
      var c = b.zc;
      b.zc = b.ld = null;
      c && c(a);
    } else {
      Zh(b.kb, a);
    }
  }, 0);
};
e.close = function() {
  var a = this;
  this.kb.Ea.setTimeout(function() {
    var b = a.ld;
    a.zc = a.ld = null;
    b && b(void 0);
  }, 0);
};
function ri(a, b) {
  z(a.m, function(a) {
    a instanceof ni ? ri(a, b) : (a.Ca(), a.xb(r), a.cancel(b));
  });
}
e.U = function(a) {
  if (this.oa && this.oa instanceof ni && !this.oa.ed) {
    this.oa.U(a);
  } else {
    if (a instanceof ni && a.Fc(this), this.ed && a instanceof ni) {
      var b = 0;
      this.oa instanceof ni && (b = Ra(this.m, this.oa) + 1);
      $a(this.m, b, 0, a);
      this.oa = a;
    } else {
      this.oa = a, this.m.push(a);
    }
  }
};
e.removeChild = function(a) {
  var b = Ra(this.m, a);
  a instanceof ni && a.Fc(null);
  y.splice.call(this.m, b, 1);
  this.oa === a && (this.oa = null);
};
e.toString = function() {
  return "[" + Ta(this.m, function(a) {
    return a.toString();
  }).join(", ") + "]";
};
function ci(a, b, c, d) {
  Sh.call(this, a);
  this.mc = b;
  this.Je = c;
  this.qh = d;
}
w(ci, Sh);
ci.prototype.toString = function() {
  var a;
  a = this.qh;
  null === a.Bc && (a.Bc = Oh(a.Af), a.Ic && (a.Bc = ab(a.Bc, a.Ic)), delete a.Ic, delete a.Af);
  a = a.Bc;
  var b = this.Je;
  a.length && (this.Je && (b += "\n"), b += a.join("\n"));
  return b;
};
var bi = new gi, Qa = [];
function mi(a, b, c) {
  function d(a) {
    g(k.next, a);
  }
  function f(a) {
    g(k["throw"], a);
  }
  function g(a, b) {
    if (h.fd()) {
      try {
        var c = a.call(k, b);
      } catch (g) {
        h.reject(g);
        return;
      }
      c.wh ? h.Sa(c.value) : Xh(c.value, d, f);
    }
  }
  if ("GeneratorFunction" !== a.constructor.name) {
    throw TypeError("Input is not a GeneratorFunction: " + a.constructor.name);
  }
  var h = new Sh, k = a.apply(b, ab(arguments, 2));
  d();
  return h.ra;
}
;function si(a, b) {
  ta.call(this);
  this.pa = nc("remote.ui.Client");
  this.ce = new uc;
  vc(this.ce, !0);
  this.Nc = a;
  this.Nd = b;
  this.ab = new xe;
  this.tf = new zf;
  this.T = new jh(ti);
  this.Zb = new xf;
  this.Ec = new vh;
  K(this.T, "create", this.Qg, !1, this);
  K(this.T, "delete", this.Rg, !1, this);
  K(this.T, "refresh", this.kf, !1, this);
  K(this.T, "screenshot", this.ge, !1, this);
  K(this.Ec, "loadscript", this.Vg, !1, this);
}
w(si, ta);
var ti = "android;chrome;firefox;internet explorer;iphone;opera".split(";");
e = si.prototype;
e.g = function() {
  this.ab.C();
  this.T.C();
  this.Zb.C();
  this.Ec.C();
  vc(this.ce, !1);
  delete this.pa;
  delete this.Nd;
  delete this.ce;
  delete this.T;
  delete this.ab;
  delete this.Zb;
  delete this.Ec;
  si.c.g.call(this);
};
e.xc = function(a) {
  this.ab.Da();
  this.ab.k(!1);
  this.T.Da(a);
  this.tf.Da(a);
  this.Ec.Da();
  this.T.zd(this.Ec.a());
  return ui(this).then(v(function() {
    this.T.la(!0);
    this.kf();
  }, this));
};
function vi(a, b) {
  a.ab.k(!1);
  var c = v(a.Nd.mc, a.Nd, b);
  return fi(c).then(sa);
}
function wi(a, b, c) {
  var d = a.pa;
  d && d.log(fc, b + "\n" + c, void 0);
  a.ab.vf(b);
  a.ab.k(!0);
}
function ui(a) {
  dd(a.pa, "Retrieving server status...");
  return vi(a, new wh("getStatus")).then(v(function(a) {
    var c = a.value || {};
    (a = c.os) && a.name && (a = a.name + (a.version ? " " + a.version : ""));
    c = c.build;
    Af(this.tf, a, c && c.version, c && c.revision);
  }, a));
}
e.kf = function() {
  dd(this.pa, "Refreshing sessions...");
  var a = this;
  vi(this, new wh("getSessions")).then(function(b) {
    b = b.value;
    b = Ta(b, function(a) {
      return new zh(a.id, a.capabilities);
    });
    nh(a.T, b);
  }).xb(function(b) {
    wi(a, "Unable to refresh session list.", b);
  });
};
e.Qg = function(a) {
  dd(this.pa, "Creating new session for " + a.data.browserName);
  a = (new wh("newSession")).setParameter("desiredCapabilities", a.data);
  var b = this;
  vi(this, a).then(function(a) {
    a = new zh(a.sessionId, a.value);
    b.T.we(a);
  }).xb(function(a) {
    wi(b, "Unable to create new session.", a);
    a = b.T;
    var d = a.ka.shift();
    d && (a.B.removeChild(d, !0), lh(a));
  });
};
e.Rg = function() {
  var a = kh(this.T);
  if (a) {
    dd(this.pa, "Deleting session: " + a.J());
    var b = (new wh("quit")).setParameter("sessionId", a.J()), c = this;
    vi(this, b).then(function() {
      for (var b = c.T, f = b.B.X, g, h = ue(b.B), k = 0;k < h;++k) {
        var l = W(b.B, k);
        if (l.ub.J() == a.J()) {
          g = l;
          break;
        }
      }
      g && (b.B.removeChild(g, !0), g.C(), f == g && ue(b.B) ? (b = b.B, sg(b, W(b, 0))) : b.Fa.update(null));
    }).xb(function(a) {
      wi(c, "Unable to delete session.", a);
    });
  } else {
    cd(this.pa, "Cannot delete session; no session selected!");
  }
};
e.Vg = function(a) {
  var b = kh(this.T);
  if (b) {
    a = new Gb(a.data);
    a.sa.add("wdsid", b.J());
    a.sa.add("wdurl", this.Nc);
    var c = (new wh("get")).setParameter("sessionId", b.J()).setParameter("url", a.toString());
    dd(this.pa, "In session(" + b.J() + "), loading " + a);
    vi(this, c).xb(v(function(a) {
      wi(this, "Unable to load URL", a);
    }, this));
  } else {
    cd(this.pa, "Cannot load url: " + a.data + "; no session selected!");
  }
};
e.ge = function() {
  var a = kh(this.T);
  if (a) {
    dd(this.pa, "Taking screenshot: " + a.J());
    a = (new wh("screenshot")).setParameter("sessionId", a.J());
    this.Zb.N(yf);
    this.Zb.k(!0);
    var b = this;
    vi(this, a).then(function(a) {
      var d = b.Zb;
      a = a.value;
      if (d.n()) {
        d.N(1);
        a = "data:image/png;base64," + a;
        var f = d.j();
        a = f.b("A", {href:a, target:"_blank"}, f.b("IMG", {src:a}));
        d.vb("");
        d.ha().appendChild(a);
        d.Z();
      }
    }).xb(function(a) {
      b.Zb.k(!1);
      wi(b, "Unable to take screenshot.", a);
    });
  } else {
    cd(this.pa, "Cannot take screenshot; no session selected!");
  }
};
function xi(a) {
  this.Vf = a;
}
xi.prototype.mc = function(a, b) {
  var c = yi[a.getName()];
  if (!c) {
    throw Error("Unrecognized command: " + a.getName());
  }
  var d = a.ie, f = zi(c.path, d);
  this.Vf.send(new Ai(c.method, f, d), function(a, c) {
    var d;
    if (!a) {
      try {
        a: {
          try {
            d = Ag(c.body);
            break a;
          } catch (f) {
          }
          var n = {status:0, value:c.body.replace(/\r\n/g, "\n")};
          199 < c.status && 300 > c.status || (n.status = 404 == c.status ? 9 : 13);
          d = n;
        }
      } catch (q) {
        a = q;
      }
    }
    b(a, d);
  });
};
function zi(a, b) {
  var c = a.match(/\/:(\w+)\b/g);
  if (c) {
    for (var d = 0;d < c.length;++d) {
      var f = c[d].substring(2);
      if (f in b) {
        var g = b[f];
        g && g.ELEMENT && (g = g.ELEMENT);
        a = a.replace(c[d], "/" + g);
        delete b[f];
      } else {
        throw Error("Missing required parameter: " + f);
      }
    }
  }
  return a;
}
var yi = function() {
  function a(a) {
    return c("POST", a);
  }
  function b(a) {
    return c("GET", a);
  }
  function c(a, b) {
    return{method:a, path:b};
  }
  return(new function() {
    var a = {};
    this.put = function(b, c) {
      a[b] = c;
      return this;
    };
    this.Tf = function() {
      return a;
    };
  }).put("getStatus", b("/status")).put("newSession", a("/session")).put("getSessions", b("/sessions")).put("getSessionCapabilities", b("/session/:sessionId")).put("quit", c("DELETE", "/session/:sessionId")).put("close", c("DELETE", "/session/:sessionId/window")).put("getCurrentWindowHandle", b("/session/:sessionId/window_handle")).put("getWindowHandles", b("/session/:sessionId/window_handles")).put("getCurrentUrl", b("/session/:sessionId/url")).put("get", a("/session/:sessionId/url")).put("goBack", 
  a("/session/:sessionId/back")).put("goForward", a("/session/:sessionId/forward")).put("refresh", a("/session/:sessionId/refresh")).put("addCookie", a("/session/:sessionId/cookie")).put("getCookies", b("/session/:sessionId/cookie")).put("deleteAllCookies", c("DELETE", "/session/:sessionId/cookie")).put("deleteCookie", c("DELETE", "/session/:sessionId/cookie/:name")).put("findElement", a("/session/:sessionId/element")).put("findElements", a("/session/:sessionId/elements")).put("getActiveElement", 
  a("/session/:sessionId/element/active")).put("findChildElement", a("/session/:sessionId/element/:id/element")).put("findChildElements", a("/session/:sessionId/element/:id/elements")).put("clearElement", a("/session/:sessionId/element/:id/clear")).put("clickElement", a("/session/:sessionId/element/:id/click")).put("sendKeysToElement", a("/session/:sessionId/element/:id/value")).put("submitElement", a("/session/:sessionId/element/:id/submit")).put("getElementText", b("/session/:sessionId/element/:id/text")).put("getElementTagName", 
  b("/session/:sessionId/element/:id/name")).put("isElementSelected", b("/session/:sessionId/element/:id/selected")).put("isElementEnabled", b("/session/:sessionId/element/:id/enabled")).put("isElementDisplayed", b("/session/:sessionId/element/:id/displayed")).put("getElementLocation", b("/session/:sessionId/element/:id/location")).put("getElementSize", b("/session/:sessionId/element/:id/size")).put("getElementAttribute", b("/session/:sessionId/element/:id/attribute/:name")).put("getElementValueOfCssProperty", 
  b("/session/:sessionId/element/:id/css/:propertyName")).put("elementEquals", b("/session/:sessionId/element/:id/equals/:other")).put("switchToWindow", a("/session/:sessionId/window")).put("maximizeWindow", a("/session/:sessionId/window/:windowHandle/maximize")).put("getWindowPosition", b("/session/:sessionId/window/:windowHandle/position")).put("setWindowPosition", a("/session/:sessionId/window/:windowHandle/position")).put("getWindowSize", b("/session/:sessionId/window/:windowHandle/size")).put("setWindowSize", 
  a("/session/:sessionId/window/:windowHandle/size")).put("switchToFrame", a("/session/:sessionId/frame")).put("getPageSource", b("/session/:sessionId/source")).put("getTitle", b("/session/:sessionId/title")).put("executeScript", a("/session/:sessionId/execute")).put("executeAsyncScript", a("/session/:sessionId/execute_async")).put("screenshot", b("/session/:sessionId/screenshot")).put("setTimeout", a("/session/:sessionId/timeouts")).put("setScriptTimeout", a("/session/:sessionId/timeouts/async_script")).put("implicitlyWait", 
  a("/session/:sessionId/timeouts/implicit_wait")).put("mouseMoveTo", a("/session/:sessionId/moveto")).put("mouseClick", a("/session/:sessionId/click")).put("mouseDoubleClick", a("/session/:sessionId/doubleclick")).put("mouseButtonDown", a("/session/:sessionId/buttondown")).put("mouseButtonUp", a("/session/:sessionId/buttonup")).put("mouseMoveTo", a("/session/:sessionId/moveto")).put("sendKeysToActiveElement", a("/session/:sessionId/keys")).put("acceptAlert", a("/session/:sessionId/accept_alert")).put("dismissAlert", 
  a("/session/:sessionId/dismiss_alert")).put("getAlertText", b("/session/:sessionId/alert_text")).put("setAlertValue", a("/session/:sessionId/alert_text")).put("getLog", a("/session/:sessionId/log")).put("getAvailableLogTypes", b("/session/:sessionId/log/types")).put("getSessionLogs", a("/logs")).Tf();
}();
function Bi(a) {
  var b = [], c;
  for (c in a) {
    b.push(c + ": " + a[c]);
  }
  return b.join("\n");
}
function Ai(a, b, c) {
  this.method = a;
  this.path = b;
  this.data = c || {};
  this.headers = {Accept:"application/json; charset=utf-8"};
}
Ai.prototype.toString = function() {
  return[this.method + " " + this.path + " HTTP/1.1", Bi(this.headers), "", Cg(new Bg(void 0), this.data)].join("\n");
};
function Ci(a, b, c) {
  this.status = a;
  this.body = c;
  this.headers = {};
  for (var d in b) {
    this.headers[d.toLowerCase()] = b[d];
  }
}
function Di(a) {
  var b = {};
  if (a.getAllResponseHeaders) {
    var c = a.getAllResponseHeaders();
    c && (c = c.replace(/\r\n/g, "\n").split("\n"), z(c, function(a) {
      a = a.split(/\s*:\s*/, 2);
      a[0] && (b[a[0]] = a[1] || "");
    }));
  }
  return new Ci(a.status || 200, b, a.responseText.replace(/\0/g, ""));
}
Ci.prototype.toString = function() {
  var a = Bi(this.headers), b = ["HTTP/1.1 " + this.status, a];
  a && b.push("");
  this.body && b.push(this.body);
  return b.join("\n");
};
function Ei() {
}
;var Fi;
function Gi() {
}
w(Gi, Ei);
function Hi() {
  var a;
  a: {
    var b = Fi;
    if (!b.Ve && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
      for (var c = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], d = 0;d < c.length;d++) {
        var f = c[d];
        try {
          new ActiveXObject(f);
          a = b.Ve = f;
          break a;
        } catch (g) {
        }
      }
      throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
    }
    a = b.Ve;
  }
  return a ? new ActiveXObject(a) : new XMLHttpRequest;
}
Fi = new Gi;
function Ii(a) {
  this.Nc = a;
}
Ii.prototype.send = function(a, b) {
  try {
    var c = Hi(), d = this.Nc + a.path;
    c.open(a.method, d, !0);
    c.onload = function() {
      b(null, Di(c));
    };
    c.onerror = function() {
      b(Error(["Unable to send request: ", a.method, " ", d, "\nOriginal request:\n", a].join("")));
    };
    for (var f in a.headers) {
      c.setRequestHeader(f, a.headers[f] + "");
    }
    c.send(Cg(new Bg(void 0), a.data));
  } catch (g) {
    b(g);
  }
};
function Ji() {
  var a = window.location, a = [a.protocol, "//", a.host, a.pathname.replace(/\/static\/resource(?:\/[^\/]*)?$/, "")].join("");
  (new si(a, new xi(new Ii(a)))).xc();
}
var Ki = ["init"], Li = m;
Ki[0] in Li || !Li.execScript || Li.execScript("var " + Ki[0]);
for (var Mi;Ki.length && (Mi = Ki.shift());) {
  !Ki.length && p(Ji) ? Li[Mi] = Ji : Li = Li[Mi] ? Li[Mi] : Li[Mi] = {};
}
;
